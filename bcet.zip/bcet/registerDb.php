<?php
session_start();
extract($_REQUEST);
include('dbconfig.php');
$get_email    = "SELECT * FROM customers WHERE customer_email ='$email'";
$email_result = $conn->query($get_email);
$emailcount   = $email_result->num_rows;
if ($emailcount > 0) {
    echo "<script>window.location.assign('index.php?exists=true')</script>";
} 
//User Info Updated 
elseif($submit) {   
$verification = md5($email . time());
 $uinfo = "INSERT INTO `customers`(`customer_id`,`customer_name`, `customer_email`, `customer_mobile`, `customer_password`, 
    `customer_area`, `created_at`, `c_verify`, `status`) values (NULL,'$name','$email','$phone','$pass','$pin',now(),'$verification',0)";
        $uresult = $conn->query($uinfo);
         $last_id = $conn->insert_id;
    if ($uresult) {
                $path = "production/users/".$last_id;
                mkdir("$path"); 
            $to           = $email;
                $subject      = "SGJ Build Mitra .";
                $imgTitle     = "Logo";
                $subjectPara1 = "Dear $name";
                //$subjectPara2 = "$content";
                $subjectPara3 = "Visit us today at";
                $site         = "www.buildmitra.com";
                $another      = " and kindly activate your account.. to enjoy our range of services.";
                $subjectPara4 = "Please be sure to save this message in a safe spot for future reference. ";
                $subjectPara5 = "Registration Details";
                $message      = '<!DOCTYPE HTML>' . '<head>' . '<meta http-equiv="content-type" content="text/html">' . '<title>Email notification</title>' . '</head>' . '<body>' . '<div id="header" style="width: 65%;height: auto;margin: auto;padding: 10px;color: #fff;text-align: center;background-color: #5f5c5c;font-family: Open Sans,Arial,sans-serif;">'. '<div id="outer" style="width: 80%;margin: 0 auto;margin-top: 10px;">' . '<div id="inner" style="width: 78%;margin: 0 auto;background-color: #fff;font-family: Open Sans,Arial,sans-serif;font-size: 13px;font-weight: normal;line-height: 1.4em;color: #444;margin-top: 10px;">' . '<center><h1>Buildmitra</h1></center>' . '<p>' . $subjectPara1 . '</p>' . '</p>' . '<p>' . $subjectPara3 . ' <a href="http://buildmitra.com">' . $site . '</a>' . $another . '</p>' . '<p style="color:red;">' . $subjectPara4 . '</p>' . '<p>' . $subjectPara5 . '</p>' . '<table>
                <tr>
                <td><i>Email:</i></td>
                <th>' . $email . '</th>' . '</tr>
                <tr>
                <td><i>Verification link:</i></td>
                <th>' . '<a href=' . 'http://buildmitra.com/bmnew/user_act.php?verify=' . $verification . '>' . 'Click here to verify your account</a>' . '</th>' . '</tr>
                </table>' . '</div>' . '</div>' . '<div id="footer" style="width: 80%;height: auto;margin: 3% auto;text-align: center;padding: 10px;font-family: Verdena;background-color: #5f5c5c;color: #fff;">' . 'DISCLAIMER: This email may contain material that is confidential, for the sole use of the intended recipient. Any review, reliance or distribution by others or forwarding without express permission is strictly prohibited. If you are not the intended recipient, please contact the sender and delete all copies.<br>' . 'All rights reserved @ SGJ Buildmitra .' . '</div>' . '</body>';
                // Always set content-type when sending HTML email
                $headers      = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                
                // More headers
                $headers .= 'From: <www.buildmitra.com>' . "\r\n";
                //echo $message; exit;
                mail($to, $subject, $message, $headers);
                echo "<script>window.location.assign('index.php?reg=true')</script>";
            } else {
                echo "<script>window.location.assign('register.php?regfail=false')</script>";
            }
        
        echo "<script>window.location.assign('index.php?success=sucess')</script>";
        
    } else {
        
        //echo "<script>window.location.assign('myaccount.php?upderr=error')</script>";
        echo $conn->error;
        
    }
    	       
?>