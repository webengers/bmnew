<?php
session_start(); //Starting session here.
extract($_REQUEST); // Extracting the Request.
include("dbconfig.php");

 $sql    = "SELECT * FROM customers WHERE customer_email = '$email'";
$result = $conn->query($sql);
if ($result->num_rows > 0)
{
	   $row = $result->fetch_assoc();
            $admin_password = $row['customer_password'];
            $to = $email;
                 $subject = "Password Request";
                 $subhead = "Password Details";
                   $message = "<html>
                               <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css' integrity='sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7' crossorigin='anonymous'>
                               <!-- Optional theme -->
                               <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css' integrity='sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r' crossorigin='anonymous'>
                               <!-- Latest compiled and minified JavaScript -->
                               <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js' integrity='sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS' crossorigin='anonymous'></script>
                               <style>
                                   a:hover{  
                                       color: #FFF;
                                       text-decoration: none;
                                       background-color: #039d03;
                                   }
                               </style>
                               <body style='background:#fcfcfc;border:1px solid #23bfff'>
                                  <div class='col-md-12' style='background:#23bfff;padding-top:30px;padding-bottom:15px' >
                                     <center>
                                        <img src='' style='background: #FFF;border-radius: 50px;padding: 10px;'>
                                        <h1 style='color: #FFF;font-weight: bold;'>Welcome to SGJ Build Mitra Pvt Ltd </h1>
                                     </center>
                                  </div>
                                  <div class='col-md-12' style='margin:15px;'>
                                     <center><br>
                                        <h2 style='color:#00c100;'>Login Details</h2>
                                     </center>
                                  </div>
                                  <div style='padding-bottom:50px;'>
                                     <center> 
                                         <table>
                                            <tr>
                                                <th style='color: #23bfff;font-size: 18px;padding: 10px;'>Password</th>
                                                <td style='color: #000;font-size: 18px;padding: 10px;text-decoration: none;'>$admin_password</td>
                                            </tr>
                                      </table>
                                     <center> <br><a href='#' style='margin: 20px;padding:10px;color: #FFF;background-color: #00c100;font-size: 14px;font-weight: bold;border-radius: 5px;text-decoration: none;'> Login your account</a></center>
                                  </div>

                               </body>
                            </html>";
                                   // Always set content-type when sending HTML email
                                   $headers = "MIME-Version: 1.0" . "\r\n";
                                   $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

                                   // More headers
                                   $headers .= 'From: <info@buildmitra.com>' . "\r\n";
                                   $mail = mail($to,$subject,$message,$headers);
                                    if($mail === TRUE)
                                    {
                                        echo "<script>window.location.assign('index.php?suc=success')</script>";
                                    }
                                    else
                                    {
                                        //echo "<script>window.location.assign('login.php?error=error')</script>";
                                    }
                                   
        }
    else
{
	//echo "Error: " . $sql . "<br>" . $conn->error;
	//echo "<script>window.location.assign('login.php?email=error#')</script>";
}
?>