<?php 
   include 'dbconfig.php';
   session_start();
   extract($_REQUEST);
   if (isset($_SESSION['customer_id'])) 
   {
      $act_uid = $_SESSION['customer_id'];
   }
   ?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Buildmitra</title>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="description" content="Buy Construction &amp; Finishing Materials Online | A-Z Building Materials | Procurement Tools | Estimation &amp; Budget Control | Top Brands | Best Deals | Experience Centers | Virtual Reality | Smart Logistics | Delivery across Kerala | Product Categories: Cement, Sand, Flooring, Roofing, Electrical, Plumbing, Sanitary, Kitchen fittings and many more.">
      <meta name="keywords" content="Buildmitra, construction,Basic Building Materials,Cement,Steel,Sand,Fine Aggregates,Coarse Aggregates,Bricks, Mud, Hollow, Fly Ash,Construction Stones,Dry Mix Concrete, Mortars,Flooring materials,Tiles,VitrifiedTiles,CeramicTiles,OutdoorPavers,White Cements,PuttyExterior Paints,Distempers,Wall Tiles,Wallpapers,Other Surface Coatings,Cladding Materials,Cladding Tiles,Electrical Switches,Sockets,Plugs,Electrical Wires,Cables,Switchgear,Electrical Consumables,Cover Plates,Boxes,Earthing,Electrical Conduits,Electrical Conduit Fittings,Pipes,Pipe Fittings,Valves,Water Tanks,Storage,Pumps,Accessories,Lamps,Fans,Chandeliers, Designer Lights,Wash BasinsFaucetsWCs, Flushing,Showers,Urinals,Bathtubs,Jacuzzi,Pools,Shower Cabins,Cabinets,Bathroom Fittings,Faucet,Shower Trims,Kitchen Sinks,Kitchen Taps,Chimney,Hob,Plywood,Multi-Wood,Veneers,Laminates,Mirrors,Roofing Sheets,Roofing Tiles,Shingles,Chemicals,Adhesives,Wall,Roofing Finishings,wood,wood replacements,electrical fitings,electrical,networking,plumbing,pvc,bath,sanitary fitings,kitchen fitings,glass,roofing">
      <meta name="robots" content="INDEX,FOLLOW">
      <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
      <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />
      <link href="css/style.css" rel="stylesheet"/>
      <div id="wrapper"></div>
      <div class="left">
         <h2 class="menulink hamburger"><a href="#">Menu</a></h2>
         <section>
            <h1 class="logo"><a href="#"><img src="images/logo.png" alt="Subscribe" /></a></h1>
            <h3> Manage Your Construction Site, Order Materials from  ONE PLACE  </h3>
         </section>
      </div>
      <div class="right">
         <section>
            <div class="narrow">
               <div class="form-box align-center">
                  <?php extract($_REQUEST);
                     if(isset($reg)&&($reg==true))
                                  {?>
                  <strong>
                     <p style="color:green">
                        Registration successful! A registration confirmation email has been sent to your email address (check your spam folder if you've not received any emails in the inbox). Please login now to enjoy our range of services.
                  </strong>
                  <?php }
                     if(isset($ac_not_actvd))
                                    {?>
                  <strong><p style="color:red">Please activate your account first, follow the link we have already sent it to your email address.</strong> 
                  <?php }
                     if(isset($ac_not_found))
                                    {?>
                  <strong><p style="color:red" >Username password were wrong (Or) You're not registered yet. Please register first.</strong> 
                  <?php }
                     if(isset($act_succ)){ ?> 
                  <strong><p style="color:green" >Your Account Is now Activated </strong> 
                  <?php } ?>
                  <div id="success">
                     <div class="green align-center">
                        <p>Your message was sent successfully!</p>
                     </div>
                  </div>
                  <div id="error">
                     <div>
                        <p>Something went wrong. Please refresh and try again.</p>
                     </div>
                  </div>
                  <form id="signup" name="signup" method="post" novalidate="novalidate" action="login_db.php">
                     <h2> Login Here </h2>
                     <br>             
                     <div class="form-row">                                       
                        <input type="text" name="email" id="email" size="30" value="" required="" class="text login_input align-center"  placeholder="Email Address">
                     </div>
                     <div class="form-row">   
                        <input type="password" name="pass" id="pass" size="30" value="" required="" class="text login_input align-center"  placeholder="Password">
                     </div>
                     <div class="form-row">                                      
                        <input id="submit" type="submit" name="login" value="Login" class="btn btn-wide">
                     </div>
                     We Don't Share Your Credinitials
                  </form>
                  Forgot Password <a href="forgotpass.php"> Click Here </a>
               </div>
               <div class="shadow"></div>
               <div class="meta align-center">
                  Not A Member With Us !! <a href="register.php"> Join Now </a>
               </div>
            </div>
         </section>
      </div>
      </div>
      <script src="js/jquery.min.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/scripts.js"></script>  
      <script src="js/jquery.form.js"></script>
      <script src="js/jquery.validate.min.js"></script>
      <script src="js/contact.js"></script>