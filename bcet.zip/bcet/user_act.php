<?php 
	session_start();
	extract($_REQUEST);
	include('dbconfig.php');
	if(isset($verify)) 
	{
		$c="SELECT * FROM customers WHERE c_verify='$verify'";
		$result = $conn->query($c);
		$verifycount = $result->num_rows;
		$row = $result->fetch_assoc();
		$id = $row['customer_id'];
		$c2="UPDATE customers SET status=1 WHERE customer_id='$id'";
		$result2 = $conn->query($c2);
	}

	else
	{
		echo "<script>window.location.assign('register.php')</script>";
	}
	if($result2 == TRUE)
	{
		$_SESSION["customer_id"] =  $row['customer_id'];
        $_SESSION["customer_email"] = $row['customer_email'];
		echo "<script>window.location.assign('index.php?act_succ=succ')</script>";
	}

?>