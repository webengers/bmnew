<?php 
   session_start();
   include("dbconfig.php");
   extract($_REQUEST);
  // print_r($_REQUEST);
        $sql = "SELECT * FROM customers WHERE customer_email ='$email' and customer_password ='$pass'";
        $result = $conn->query($sql);
		 $login_result = $result->num_rows;
		if($login_result > 0)
		{
			// User found. Login success.
			// Store his/her record info in an array
			$row = mysqli_fetch_assoc($result);
			//print_r($row);
			if ($row['status'] == 1) 
			{
				   $_SESSION['start_time'] = time();
                   $_SESSION["email"] = $row['customer_email'];
                   $_SESSION["aid"] = $row['customer_id'];
                   $_SESSION["username"] = $row['customer_name'];
			}
			
		if ($row['status'] == 0 ) 
			{   echo "<script>window.location.assign('index.php?ac_not_actvd=true')</script>";  } }
			
		else{
		        echo "<script>window.location.assign('index.php?ac_not_found=true')</script>";  }   

	
	    if(isset($_SESSION["email"])) {
                    echo "<script>window.location.assign('production/index.php?login=true')</script>"; 
                 }
		
?>