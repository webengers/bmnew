<?php
date_default_timezone_set("Asia/Kolkata");
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bbcapp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//include "production/functions.php";
    class DBController
    {
        private $host = "localhost";
        private $user = "root";
        private $password = "";
        private $database = "bbcapp";
        private $conn;

        function __construct()
        {
            $this->conn = $this->connectDB();
            if (!empty($conn)) {
                $this->selectDB($conn);
            }
        }

        function connectDB()
        {
            $conn = mysqli_connect($this->host, $this->user, $this->password, $this->database);
            return $conn;
        }

        function runQuery($query)
        {
            $result = mysqli_query($this->conn, $query);
            while ($row = mysqli_fetch_assoc($result)) {
                $resultset[] = $row;
            }
            if (!empty($resultset))
                return $resultset;
            return false;
        }

        function numRows($query)
        {
            $result   = mysqli_query($this->conn, $query);
            $rowcount = mysqli_num_rows($this->conn, $result);
            return $rowcount;
        }
    }
?>