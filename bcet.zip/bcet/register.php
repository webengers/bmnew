<?php include 'dbconfig.php';
   session_start();
   extract($_REQUEST);
   if (isset($_SESSION['customer_id'])) 
   {
      $act_uid = $_SESSION['customer_id'];
   }
   ?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Buildmitra</title>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="description" content="Buy Construction &amp; Finishing Materials Online | A-Z Building Materials | Procurement Tools | Estimation &amp; Budget Control | Top Brands | Best Deals | Experience Centers | Virtual Reality | Smart Logistics | Delivery across Kerala | Product Categories: Cement, Sand, Flooring, Roofing, Electrical, Plumbing, Sanitary, Kitchen fittings and many more.">
      <meta name="keywords" content="Buildmitra, construction,Basic Building Materials,Cement,Steel,Sand,Fine Aggregates,Coarse Aggregates,Bricks, Mud, Hollow, Fly Ash,Construction Stones,Dry Mix Concrete, Mortars,Flooring materials,Tiles,VitrifiedTiles,CeramicTiles,OutdoorPavers,White Cements,PuttyExterior Paints,Distempers,Wall Tiles,Wallpapers,Other Surface Coatings,Cladding Materials,Cladding Tiles,Electrical Switches,Sockets,Plugs,Electrical Wires,Cables,Switchgear,Electrical Consumables,Cover Plates,Boxes,Earthing,Electrical Conduits,Electrical Conduit Fittings,Pipes,Pipe Fittings,Valves,Water Tanks,Storage,Pumps,Accessories,Lamps,Fans,Chandeliers, Designer Lights,Wash BasinsFaucetsWCs, Flushing,Showers,Urinals,Bathtubs,Jacuzzi,Pools,Shower Cabins,Cabinets,Bathroom Fittings,Faucet,Shower Trims,Kitchen Sinks,Kitchen Taps,Chimney,Hob,Plywood,Multi-Wood,Veneers,Laminates,Mirrors,Roofing Sheets,Roofing Tiles,Shingles,Chemicals,Adhesives,Wall,Roofing Finishings,wood,wood replacements,electrical fitings,electrical,networking,plumbing,pvc,bath,sanitary fitings,kitchen fitings,glass,roofing">
      <meta name="robots" content="INDEX,FOLLOW">
      <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
      <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />
      <link href="css/style.css" rel="stylesheet"/>
      <div id="wrapper"></div>
      <div class="left">
         <h2 class="menulink hamburger"><a href="#">Menu</a></h2>
         <section>
            <h1 class="logo"><a href="#"><img src="images/logo.png" alt="Subscribe" /></a></h1>
            <h3>Manage Your Construction Site, Order Materials from  ONE PLACE </h3>
         </section>
      </div>
      <div class="right">
         <?php extract($_REQUEST);
            if(isset($regfail)){?>
         <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>Oops!! Signup process failed. Try again..</strong> 
         </div>
         <?php }
            if(isset($exists))
            {?>
         <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>Email already used for signup. Please try to register with another email..</strong> 
         </div>
         <?php }
            ?>
         <section>
            <div class="title align-center">
               <h2>Join Us !!</h2>
               <div class="meta align-center">
                  <a href="index.php"><span style="color:red">Alredy Account With Us</span></a>
               </div>
            </div>
            <div class="wide">
               <div class="form-box">
                  <div id="success">
                     <div class="green align-center">
                        <p>Your message was sent successfully!</p>
                     </div>
                  </div>
                  <div id="error">
                     <div>
                        <p>Something went wrong. Please refresh and try again.</p>
                     </div>
                  </div>
                  <form id="trial" name="trial" method="post" novalidate="novalidate" action="registerDb.php" >
                     <div class="form-row">	 
                        <label>Name <span class="required">*</span></label>
                        <input type="text" name="name" id="name" size="30" value="" required="" class="text login_input">
                     </div>
                     <div class="form-row">		
                        <label>Email Address <span class="required">*</span></label>							     
                        <input type="text" name="email" id="email" size="30" value="" required="" class="text login_input">
                     </div>
                     <div class="form-row">		
                        <label>Password <span class="required">*</span></label>							     
                        <input type="password" name="pass" id="pass" size="30" value="" required="" class="text login_input">
                     </div>
                     <div class="form-row">	
                        <label>Phone Number <span class="required">*</span> </label>								     
                        <input type="text" name="phone" id="phone" size="30" pattern="^\d{10}$" required class="text login_input">
                     </div>
                     <div class="form-row">	
                        <label>Pin Code <span class="required">*</span> </label>								     
                        <input type="text" id="pin" name="pin" pattern="[0-9]{4}" maxlength="6" required="" class="text login_input">
                     </div>
                     <!-- <div class="form-row">	
                        <label>Message</label>								     
                           <textarea name="message" id="message"></textarea>
                        </div> -->
                     <div class="form-row">									    
                        <input id="submit" type="submit" name="submit" value="Signup" class="btn btn-wide">
                     </div>
                     <div class="align-center">We Don't Share Your Credinitials</div>
                  </form>
               </div>
               <div class="shadow"></div>
            </div>
         </section>
      </div>
      </div>
      <script src="js/jquery.min.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/scripts.js"></script>  
      <script src="js/jquery.form.js"></script>
      <script src="js/jquery.validate.min.js"></script>
      <script src="js/contact.js"></script>
      </body>
</html>