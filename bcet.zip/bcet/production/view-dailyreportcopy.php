<?php include 'headerpage.php';
if(isset($proid))
{  include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>
<!-- Project Name -->
<?php $pr_sql = $conn->query("SELECT * FROM `projects_data` where project_id ='$proid' ");
if($pr_row = $pr_sql->fetch_object()){ $prname = $pr_row->project_title;  } ?>
      <!-- Custom box css -->
<link href="plugins/custombox/css/custombox.min.css" rel="stylesheet">
<!-- Plugins css-->
<link href="plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" />
<link href="plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="plugins/switchery/switchery.min.css">
<link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">
    <!-- DataTables -->
        <link href="plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <!-- Responsive datatable examples -->
        <link href="plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">View Daily Report <b><?=$prname;?></b> </h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                     <li class="breadcrumb-item"><a href="#"> Daily Reports </a></li>
                     <li class="breadcrumb-item active">View Daily Reports</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->
         <!-- Main Content Start-->
         <div class="form-group">
            <label>Select Date </label>
            <div>
               <div class="input-group">
                  <input type="text" class="form-control" placeholder="mm/dd/yyyy" id="datepicker-autoclose">
                  <span class="input-group-addon bg-custom b-0"><i class="mdi mdi-calendar text-white"></i></span>
               </div>
               <!-- input-group -->
            </div>
         </div><!--Form-group-->

         <div class="row">
            <div class="col-lg-12">
               <div class="card-box table-responsive">
                  <h4 class="m-t-0 header-title" id="div"><b>View Daily report</b></h4>
                    <table id="datatable" class="table table-bordered">
                     <thead>
                        <tr>
                           <th>Date</th>
                           <!-- <th>Pics</th> -->
                           <th>Operations</th>
                        </tr>
                     </thead>
               
                        <?php echo $sql1 = "SELECT * FROM `purchase_data` WHERE `project_id` = '$proid'";
                           $result1 = $conn->query($sql1);
                           while ($row1 = $result1->fetch_object()) {
                              $pur_id = $row1->pur_id;
                              $date = $row1->pur_date; 
                              /* $primagesq = $row1->quo_pic;
                               $primagesp = $row1->pur_pic;
                               $primagesw = $row1->wipho_invpic;
                               $primages = $row1->upload_images;
                               $primagespay = $row1->payment_image;
                               $protitle = $row1->project_title;
                               $imgq = explode(",", $primagesq);
                               $imgp = explode(",", $primagesp);
                               $imgw = explode(",", $primagesw);
                               $imgpay = explode(",", $primagespay);
                               $img = explode(",", $primages);
                               $realPath = 'users/'.$aid.'/projects/'.$protitle.'/images';*/
                            ?>

                     <tbody>
                        <tr>
                           <td>View Daily Report <a> <?=$date;?></a> </td>
                           <!-- <td>
                              <?php 
                              foreach($imgp as $imagep)
                              {
                              echo '<img src="'.$realPath.'/'.$imagep.'" height="310" width="215" alt="Slider Imagesp" class="img-fluid">';
                              } ?>

                              <?php 
                              foreach($imgq as $imageq)
                              {
                              echo '<img src="'.$realPath.'/'.$imageq.'" height="310" width="215" alt="Slider Imagesq" class="img-fluid">';
                              } ?>

                              <?php 
                              foreach($imgw as $imagew)
                              {
                              echo '<img src="'.$realPath.'/'.$imagew.'" height="310" width="215" alt="Slider Imagesw" class="img-fluid">';
                              } ?>

                              <?php 
                              foreach($imgpay as $imagepay)
                              {
                              echo '<img src="'.$realPath.'/'.$imagepay.'" height="310" width="215" alt="Slider Imagespay" class="img-fluid">';
                              } ?>

                              <?php 
                              foreach($img as $image)
                              {
                              echo '<img src="'.$realPath.'/'.$image.'" height="310" width="215" alt="Slider Images" class="img-fluid">';
                              } ?>
                           </td> -->
                           <td>
                           <a href="edit-Daily-reportcopy.php?proid=<?=$proid;?>&pur_id=<?=$pur_id;?>" class="btn btn-sm btn-primary" title="View/Edit"><i class="fa fa-edit"></i></a>
                           <a href="delete-Daily-report.php" class="btn btn-sm btn-danger" title="delete"><i class="fi-trash"></i></a>
                           </td>
                        </tr>
                      <?php  } ?>
                     </tbody>
                  </table>
               </div><!-- Close card-box -->
            </div><!--col-lg-12-->
      </div><!-- Main Content row-->
   </div><!-- container -->
   <!-- content -->
</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
<!--plugins-->
<script src="plugins/moment/moment.js"></script>
<script src="plugins/timepicker/bootstrap-timepicker.js"></script>
<script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="plugins/select2/js/select2.min.js" type="text/javascript"></script>
<script src="plugins/bootstrap-select/js/bootstrap-select.js" type="text/javascript"></script>
<script src="plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js" type="text/javascript"></script>
<script src="assets/pages/jquery.form-pickers.init.js"></script>
 <!-- Required datatable js -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Responsive examples -->
<script src="plugins/datatables/dataTables.responsive.min.js"></script>
<script src="plugins/datatables/responsive.bootstrap4.min.js"></script>

<script type="text/javascript">
   $(document).ready(function() {
       $('#datatable').DataTable();
   } );
   



</script>