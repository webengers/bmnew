<?php include 'headerpage.php';
if(isset($proid))
{  include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>

<!-- Project Name -->
<?php $pr_sql = $conn->query("SELECT * FROM `projects_data` where project_id ='$proid' ");
if($pr_row = $pr_sql->fetch_object()){ $prname = $pr_row->project_title;  } ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">Material Estimation Project <p><?=$prname;?></h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                     
                     <li class="breadcrumb-item active">Material Estimation</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->
         <div class="row">
            <div class="col-lg-12">
               <div class="card-box">
                  <style type="text/css">
                     table {table-layout: fixed;width: 100%;*margin-left: -100px; }
                     td, th { vertical-align: top;border-top: 1px solid #ccc;padding: 10px;width: 100px; }
                     th { /*  position:absolute; *position: relative; /*ie7*/ /*  left:0; */ width: 100px; }
                     .hard_left { width:200px; }
                     .outer { position: relative; }
                     .inner { overflow-x: scroll;overflow-y: visible; margin-left: 200px; }
                     .pm { width:260px!important; }
                     .frmSearch { margin: 2px 0px;}
                     #country-list{ float:left;list-style:none;margin-top:-3px;padding:0;width:190px;position: absolute;}
                     #country-list li{ padding: 10px; background: #f0f0f0; border-bottom: #bbb9b9 1px solid;}
                     #country-list li:hover{ background:#ece3d2;cursor: pointer;}
                     #search-box{ padding: 10px;border: #a8d4b1 1px solid;border-radius:4px;}
                  </style>
                  <form method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                     <table class="table table-hover small-text" id="tb">
                        <tr class="tr-header">
                           <th class="hard_left">Category</th>
                           <th class="pm"> Product Name </th>
                           <th> Qty </th>
                           <!-- <th> Brand </th> -->
                           <th> Unit Price </th>
                           <th> Amount </th>
                           <th> Remarks </th>
                        </tr>
                        <tr>
                          <?php $material_est = $conn->query("SELECT * FROM `estimation_data` where est_project_id ='$proid' ");
                              while($material_row = $material_est->fetch_assoc()) 
                              { 
                                $esti_id = $material_row['estimation_id'];
                                $category = $material_row['est_category_name'];
                                $categories = explode(',',$category);
                                $lenght = sizeof($categories);

                                $product = $material_row['est_product_name'];
                                $products = explode(',',$product);
                              
                                $brand = $material_row['est_brand'];
                                $brands = explode(',',$brand);

                                $unitprice = $material_row['est_unitprice'];
                                $unitprices = explode(',',$unitprice);

                                $qty = $material_row['est_qty'];
                                $quantity = explode(',',$qty);

                                $remarks = $material_row['est_remarks'];
                                $remark = explode(',',$remarks);

                                $est_amou = $material_row['est_amount']; 
                                  } ?>
                                <?php for($i=0;$i < $lenght;$i++)
                                {  ?>
                           <td class="hard_left select">
                              <input type="text" id="product_name<?=$i;?>" name="category[]" placeholder="Category Name" value="<?=$categories[$i];?>" class="form-control" readonly>
                           </td>
                           <td>
                              <div class="frmSearch">
                                 <input list="search-list<?=$i;?>" id="search-box<?=$i;?>" placeholder="Product Name" class="form-control search-box<?=$i;?>" name="productname[]" value="<?=$products[$i];?>"/>
                                 <datalist id="search-list<?=$i;?>"></datalist>
                              </div>
                           </td>
                           <td>
                              <input type="number" class="form-control quantity" id="quantity<?=$i;?>" name="quantitys[]" value ="<?=$quantity[$i];?>">
                           </td>
                           <!--<td>
                              <input list="brand-list<?=$i;?>" name="br[]" id="br<?=$i;?>" placeholder="brand" class="form-control br<?=$i;?>">
                              <datalist id="brand-list<?=$i;?>" value="<?=$measurements[$i];?>"></datalist>
                           </td>-->
                           <td>
                              <input type="number" value="<?=$unitprices[$i];?>" id="unit_pricea<?=$i;?>" name="unit_pricea[]" class="form-control unit_pricea">
                           </td>
                           <td>
                              <input type="text" id="amounta<?=$i;?>" value="<?=$unitprices[$i];?>"name="amounta[]" class="form-control amounta" readonly>
                           </td>
                           <td>
                            <input type="text" value="<?=$remark[$i];?>" name="remarks[]" id="remarks<?=$i;?>" placeholder="Remarks" class="form-control remarks">
                              
                           </td>

                        </tr>
                         <?php  }   ?>
                     </table>
               </div>
            </div>
            <div class="col-md-5 col-sm-5 col-xs-5">
            Total Project Cost : 
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
            @ Total Amount <input type='text' id="amount4" class="form-control" name="Total Amount" value="<?=$est_amou;?>"  readonly/>
            <br>
            <button type="submit" formaction="material-quote.php?edit=<?=$esti_id;?>" class="btn btn-primary btn-sm pull-right">Update</button>
            </div>
          
            <br><br>
            <input type="hidden" value="<?=$aid;?>" name="user_id">
            <input type="hidden" value="<?=$esti_id;?>" name="edit">
            <input type="hidden" value="<?=$proid;?>" name="project_id">
            <input type="hidden" name="brand_valup" value="" id="brand_valup"/>
         </div>
         <!--Panel Group-->
      </div>
   </div>
   </form>
</div>
<!--Card-box-->
</div><!--col-lg-12-->
</div><!--main content row-->
</div>
<!-- container -->
</div>
<!-- content -->
</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
<script type='text/javascript'>
   <?php for ($x=0;$x < $lenght;$x++) 
      { ?>
          $("#search-box<?=$x;?>").keyup(function(){
             // console.log($(this).val());
              $.ajax({
              type: "POST",
              url: "searchlist.php",
              data:'keyword='+$(this).val(),
              success: (data) => {
                $("#search-list<?=$x;?>").html(data);
             }
              });
          });
          $('#search-box<?=$x;?>').blur(function() {
             var val = $("#search-list<?=$x;?>").val();
             $.ajax({
                 type: "POST",
                 url: "searchlist.php",
                 data:'amount='+$(this).val(),
                 success: (data) => {
                   console.log(data);
                 var number = $('#quantity<?=$x;?>').val();
                 //$("#unit_pricea<?=$i;?>").val(data); 
                 $("#unit_pricea<?=$x;?>").val(data.replace(',',''));
                 var o_val = $("#unit_pricea<?=$x;?>").val(); 
                 //console.log(o_val); 
                 var op_val = number * o_val;
                 //console.log(op_val);
                 $("#amounta<?=$x;?>").val(op_val);
                 var amount4_total = 0;
                 for (var i = 1; i <= 13; i++) {
                   amount4_total += Number($(`#amounta${i}`).val());
                   
                    console.log($(`#amounta${i}`).val());
                 }
                  //console.log(amount4_total);
              $('#amount4').val(amount4_total);
            // console.log($("#brand_val").val($('#amount4').val(amount4_total)));
             $("#brand_valup").val(amount4_total);
                 }
              });
               });

            /* Quantity Change*/ 
            $('#quantity<?=$x;?>').change(function () {
             var number = $(this).val();
               //console.log(number);
                var o_val = $("#unit_pricea<?=$x;?>").val();
                var op_val = number * o_val;
               $("#amounta<?=$x;?>").val(op_val);
                 var amount4_total = 0;
                
                 for (var i = 1; i <= 13; i++) {
                   amount4_total += Number($(`#amounta${i}`).val());
                   //console.log($(`#amounta${i}`).val());
                 }
                 // console.log(amount4_total);
              $('#amount4').val(amount4_total);
            // console.log($("#brand_val").val($('#amount4').val(amount4_total)));
             $("#brand_valup").val(amount4_total);
             });
   
            /* Unit Price Change */
            $('#unit_pricea<?=$x;?>').change(function () {
             var number = $(this).val();
               //console.log(number);
                var o_val = $("#quantity<?=$x;?>").val();
                var op_val = number * o_val;
               $("#amounta<?=$x;?>").val(op_val);
               var amount4_total = 0;
               for (var i = 1; i <= 13; i++) {
                 amount4_total += Number($(`#amounta${i}`).val());
                 console.log($(`#amounta${i}`).val());
               }
              // console.log(amount4_total);
             $('#amount4').val(amount4_total);
             $("#brand_valup").val(amount4_total);
             });
            /* Brand1 Close */
            
   <?php } ?>  
    
</script>