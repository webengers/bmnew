<?php
session_start();
include "../dbconfig.php";
$aid= $_SESSION["aid"];
extract($_REQUEST);
//print_r($_REQUEST);

  $folder="users/$aid/projects/";
  $path = mkdir("$folder/$prname", 0777, true);
  $upload = "users/$aid/projects/$prname/";

if(isset($addquote))
{          
           $upquote="";
           $upload_path = "$upload";
           $dcount = 0;
           $valid_formats = array("jpg", "jpeg","JPG", "png","PNG","GIF","gif", "bmp","BMP");
           $max_file_size = 1000000; //1mb
           $dimgname="";
            // Loop $_FILES to execute all files
            foreach ($_FILES['upquote']['name'] as $f => $name) 
            {    
                if ($_FILES['upquote']['error'][$f] == 4)
                {
                    continue; // Skip file if any error found
                }        
                if ($_FILES['upquote']['error'][$f] == 0)
                {            
                    if ($_FILES['upquote']['size'][$f] > $max_file_size) 
                    {
                        $message[] = "$name is too large!.";
                        continue; // Skip large files
                    }
                    elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) )
                    {
                        $message[] = "$name is not a valid format";
                        continue; // Skip invalid file formats
                    }
                    else
                    { // No error found! Move uploaded files 
                        if(move_uploaded_file($_FILES["upquote"]["tmp_name"][$f], $upload_path.$name))
                        {
                            $dcount++; // Number of successfully uploaded files
                            $dimgname .= "$name,";
                        }
                    }
                }
            }
          if( $dimgname!="")
          {    
              $upquotes = rtrim($dimgname,",");
              $sql = "INSERT INTO `projects_data`(`project_id`, `customer_id`, `project_title`, `project_location`, `project_start_date`, `project_end_date`, `project_area`, `project_dimensions`, `project_others`, `project_stage`, `project_images`, `project_status`) VALUES (NULL, '$aid', '$prname', '$prlocation','$prstart','$edate','$area','$dimensions','$others','$prstage','$upquotes',1)";
              $result = $conn->query($sql);
              $proid = $conn->insert_id;
              if($result == TRUE){
                        //echo "Error: " . $sql . "<br>" . $conn->error;
                        echo "<script>window.location.assign('dashboard.php?proid=$proid')</script>";
                    } 
          }
  }


/* Edit Page  */

if(isset($editquote))
{
           $upquote="";
           $valid_formats = array("jpg", "jpeg","JPG", "png","PNG","GIF","gif", "bmp","BMP");
           $max_file_size = 1000000; //1mb
           $dimgname="";
           $upload_path = "$upload";
           $dcount = 0;
            // Loop $_FILES to execute all files
            foreach ($_FILES['upquote']['name'] as $f => $name) 
            {    
                if ($_FILES['upquote']['error'][$f] == 4)
                {
                    continue; // Skip file if any error found
                }        
                if ($_FILES['upquote']['error'][$f] == 0)
                {            
                    if ($_FILES['upquote']['size'][$f] > $max_file_size) 
                    {
                        $message[] = "$name is too large!.";
                        continue; // Skip large files
                    }
                    elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) )
                    {
                        $message[] = "$name is not a valid format";
                        continue; // Skip invalid file formats
                    }
                    else
                    { // No error found! Move uploaded files 
                        if(move_uploaded_file($_FILES["upquote"]["tmp_name"][$f], $upload_path.$name))
                        {
                            $dcount++; // Number of successfully uploaded files
                            $dimgname .= "$name,";
                        }
                    }
                }
            }
          if( $dimgname!="")
          {    
           $upquotes = rtrim($dimgname,",");
             $sql1 = "UPDATE `projects_data` SET `customer_id`='$aid',`project_title`='$prname',`project_location`='$prlocation',`project_start_date`='$prstart',`project_end_date`='$edate',`project_area`='$area',`project_dimensions`='$dimensions',`project_others`='$others',`project_stage`='$prstage',`project_images`='$upquotes' WHERE `project_id`='$predit'";
          }
          else
          {
             $sql1 = "UPDATE `projects_data` SET `customer_id`='$aid',`project_title`='$prname',`project_location`='$prlocation',`project_start_date`='$prstart',`project_end_date`='$edate',`project_area`='$area',`project_dimensions`='$dimensions',`project_others`='$others',`project_stage`='$prstage' WHERE `project_id`='$predit'";
          }
          if ($conn->query($sql1) == TRUE) {
          echo "<script>window.location.assign('edit-Project.php?proid=$predit&&sucess=success')</script>";
      
          } else {
           //echo "Error: " . $sql1 . "<br>" . $conn->error; exit;
           echo "<script>window.location.assign('edit-Project.php?proid=$predit&&error=error')</script>";
  
            }
}

?>