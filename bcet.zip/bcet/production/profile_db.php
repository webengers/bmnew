<?php
session_start();
include("../dbconfig.php");
extract($_REQUEST);
//print_r($_REQUEST);
$email=$_SESSION["email"];
$aid= $_SESSION["aid"];

$slogo = $_FILES['slogo']['name'];
$slogo_type = $_FILES['slogo']['type'];
$slogo_size = $_FILES['slogo']['size'];

if($slogo!="")
{
    $move = move_uploaded_file($_FILES['slogo']['tmp_name'],'users/'.$aid.'/'.$slogo);
	$sql ="UPDATE `customers` SET `customer_profile_pic` = '$slogo' WHERE `customer_id` = $aid";
} 

if(isset($profile_update))
{
	$cuaddress = htmlspecialchars($address);
    $sql ="UPDATE `customers` SET `customer_name` = '$name', `customer_email` = '$email',`customer_mobile` = '$mobile', `customer_area` = '$cuaddress',`customer_name`='$uname' WHERE `customer_id` = $aid" ;
}

if ($conn->query($sql) === TRUE) {
echo "<script>window.location.assign('profile.php?proid=$aid&edit=updated')</script>";
} else {
echo  $conn->error;
}