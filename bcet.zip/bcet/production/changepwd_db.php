<?php
session_start();
$id = $_SESSION["aid"];
extract($_REQUEST); 
include("../dbconfig.php");
$get_pwd = "SELECT * FROM customers where customer_id = '$id'";
  $result = $conn->query($get_pwd);
  $pwd = $result->num_rows;
if($row = $result->fetch_assoc())
            { 
                $pwd=$row['customer_password'];
                 
            }

 if($pwd!=$oldpwd)
     {
       echo "<script>window.location.assign('profile.php?pwderr=error')</script>";
        }
else{
if($newpwd==$cnfpwd)
      {
   $sql = "UPDATE `customers` set customer_password='$cnfpwd' where customer_id=$id" or die(mysqli_error());
  
    if ($conn->query($sql) === TRUE) 
    {
    
    echo "<script>window.location.assign('profile.php?pwdsucc=succ')</script>";
} 
 else {
     echo "<script>window.location.assign('profile.php?pwderror=error')</script>";
        // echo  $con->error;

 }
}
    else
{
 echo "<script>window.location.assign('profile.php?pwderr=password not match')</script>";   
}
}

?>

