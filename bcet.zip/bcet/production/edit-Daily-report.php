<?php include 'headerpage.php';
   if(isset($proid))
   {  include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>
<!-- Project Name -->
<?php $pr_sql = $conn->query("SELECT * FROM `projects_data` where project_id ='$proid' ");
   if($pr_row = $pr_sql->fetch_object()){ $prname = $pr_row->project_title;  } ?>
<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
<script src='assets/js/jquery.min.js'></script>
<!-- Custom box css -->
<link href="plugins/custombox/css/custombox.min.css" rel="stylesheet">
<!-- Plugins css-->
<link href="plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" />
<link href="plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="plugins/switchery/switchery.min.css">
<link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">
<!-- Jquery filer css -->
<link href="plugins/jquery.filer/css/jquery.filer.css" rel="stylesheet" />
<link href="plugins/jquery.filer/css/themes/jquery.filer-dragdropbox-theme.css" rel="stylesheet" />
<!-- Bootstrap fileupload css -->
<link href="plugins/bootstrap-fileupload/bootstrap-fileupload.css" rel="stylesheet" />
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">Daily Report Management <b><?=$prname;?></b> </h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                     <li class="breadcrumb-item"><a href="#"> Daily Reports </a></li>
                     <li class="breadcrumb-item active">Edit Daily Reports</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->
         <!-- Main Content Start-->
         <form  method="post" enctype="multipart/form-data" id="myForm" role="form">
            <?php if(isset($edit))
               { ?>
                  <?php echo $sql1 = "SELECT  `projects_data`.`project_title`,`quotes_data`.`quo_pic`,`purchase_data`.`pur_pic`,
                  `workinprogress_inhouse`.`wipho_invpic`, `payments_data`.`payment_image`,`upload_photos`.`upload_images`FROM `projects_data`INNER JOIN `quotes_data`ON (`projects_data`.`project_id` = `quotes_data`.`project_id`)INNER JOIN `purchase_data`ON (`projects_data`.`project_id` = `purchase_data`.`project_id`)INNER JOIN `usage_data`ON (`projects_data`.`project_id` = `usage_data`.`project_id`)INNER JOIN `labor_data` ON (`projects_data`.`project_id` = `labor_data`.`project_id`)INNER JOIN `workinprogress_inhouse` ON (`projects_data`.project_id = `workinprogress_inhouse`.`project_id`)INNER JOIN `payments_data` ON (`projects_data`.`project_id` = `payments_data`.`project_id`) INNER JOIN `other_information` ON (`projects_data`.`project_id` = `other_information`.`project_id`) INNER JOIN `upload_photos` ON (`projects_data`.`project_id` = `upload_photos`.`project_id`) WHERE `projects_data`.`project_id` = '$edit'";
               $result1 = $conn->query($sql1);
               while ($row1 = $result1->fetch_object()) {
               $date = $row1->quo_date; 
               $upid = $row1->upload_id;
               $primagesq = $row1->quo_pic;
               $primagesp = $row1->pur_pic;
               $primagesw = $row1->wipho_invpic;
               $primages = $row1->upload_images;
               $primagespay = $row1->payment_image; 
               $protitle = $row1->project_title;
               $imgp = explode(",", $primagesp);
               $imgq = explode(",", $primagesq);
               $imgw = explode(",", $primagesw);
               $imgpay = explode(",", $primagespay);
               $img = explode(",", $primages);
               $realPath = 'users/'.$aid.'/projects/'.$protitle.'/images/';
               } ?>
            <?php } ?> <!--if condition close-->
         </form>
         <!-- form Close-->
      </div>
      <!-- container fluid-->
   </div>
   <!-- content-->
</div>
<!-- contnt page-->
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
<script src="plugins/moment/moment.js"></script>
<script src="plugins/timepicker/bootstrap-timepicker.js"></script>
<script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="plugins/select2/js/select2.min.js" type="text/javascript"></script>
<script src="plugins/bootstrap-select/js/bootstrap-select.js" type="text/javascript"></script>
<script src="plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js" type="text/javascript"></script>
<script src="assets/pages/jquery.form-pickers.init.js"></script>
<!-- Jquery filer js -->
<script src="plugins/jquery.filer/js/jquery.filer.min.js"></script>
<!-- Bootstrap fileupload js -->
<script src="plugins/bootstrap-fileupload/bootstrap-fileupload.js"></script>
<!-- page specific js -->
<script src="assets/pages/jquery.fileuploads.init.js"></script>