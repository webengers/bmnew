
      <!-- ========== Left Sidebar Start ========== -->
<div class="left side-menu">
   <div class="slimscroll-menu" id="remove-scroll">
      <!--- Sidemenu -->
      <div id="sidebar-menu">
         <!-- Left Menu Start -->
         <ul class="metismenu" id="side-menu">
            <li class="menu-title">Navigation</li>
            <li><a href="index.php"><i class="fi-air-play"></i><span> Dashboard </span> </a>
            </li>
            <li>
               <a href="javascript: void(0);"><i class="fi-archive"></i> <span> Projects </span> <span class="menu-arrow"></span></a>
               <ul class="nav-second-level" aria-expanded="false">
                  <li><a href="add-Newproject.php">Add New Project </a></li>
                  <li><a href="view-Projects.php?proid=<?=$proid;?>"> View Projects </a></li>
               </ul>
            </li>
            <li>
               <a href="material-estimation.php?proid=<?=$proid;?>"><i class="fi-paper"></i><span> Estimation </span> </a>
            </li>

            
            <li>
               <a href="work-in-progress.php?proid=<?=$proid;?>"><i class="fi-target"></i> <span> Work In Progress </span></a>
            </li>
            <li>
               <a href="javascript: void(0);"><i class="fi-briefcase"></i> <span> Procurement </span> <span class="menu-arrow"></span></a>
               <ul class="nav-second-level" aria-expanded="false">
                  <li><a href="quotes.php?proid=<?=$proid;?>">Quotes</a></li>
                  <li><a href="orders.php?proid=<?=$proid;?>">Orders</a></li>
               </ul>
            </li>
            <li>
               <a href="stock.php?proid=<?=$proid;?>"><i class="fi-help"></i> <span> Stock </span></a>
            </li>
            <li>
               <a href="javascript: void(0);"><i class="fi-box"></i><span> Daily Reports </span> <span class="menu-arrow"></span></a>
               <ul class="nav-second-level" aria-expanded="false">
                  <li><a href="addaily-report.php?proid=<?=$proid;?>"> Add Daily Report </a></li>
                  <li><a href="view-dailyreport.php?proid=<?=$proid;?>"> View Daily Report </a></li>
               </ul>
            </li>
       
            <li>
               <a href="javascript: void(0);"><i class="fi-bar-graph-2"></i><span> Todo List </span> <span class="menu-arrow"></span></a>
               <ul class="nav-second-level" aria-expanded="false">
                  <li><a href="to-do-list.php?proid=<?=$proid;?>"> Add Todo List </a></li>
                  <li><a href="view-todo.php?proid=<?=$proid;?>"> View Todo List </a></li>
               </ul>
            </li>
            <li>
               <a href="javascript: void(0);"><i class="fi-mail"></i><span> Help / Contact Us </span> <span class="menu-arrow"></span></a>
               <ul class="nav-second-level" aria-expanded="false">
                  <li><a href="faq.php"> FAQ </a></li>
                  <li><a href="youtubelink"> Videos </a></li>
                  <li><a href="conatct-us.php"> Contact Us </a></li>
               </ul>
            </li>
         </ul>
      </div>
      <!-- Sidebar -->
      <div class="clearfix"></div>
   </div>
   <!-- Sidebar -left -->
</div>
<!-- Left Sidebar End -->