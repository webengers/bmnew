<?php include 'headerpage.php';?>
<!-- Custom box css -->
      <link href="plugins/custombox/css/custombox.min.css" rel="stylesheet">
      <!-- Plugins css-->
      <link href="plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" />
      <link href="plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
      <link rel="stylesheet" href="plugins/switchery/switchery.min.css">
      <link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">
<?php include 'leftmenu.php';?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">Add New Project</h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                     <li class="breadcrumb-item"><a href="#">Projects</a></li>
                     <li class="breadcrumb-item active">Add New Project</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->
         
         <!-- Main Contetbt Start-->
         <div class="row">
            <div class="col-lg-12">
               <div class="card-box">
                  <form action="addNewProjects.php" id="addnewprojects" method="POST" enctype="multipart/form-data">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">
                              <label for="field-4" class="control-label"> Project Name </label>
                              <input type="text" name="prname" class="form-control" id="field-4" placeholder=" Project Name ">
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <label for="field-4" class="control-label"> Project Location (Area) </label>
                              <input type="text" name="prlocation" class="form-control" id="field-4" placeholder="Project Location">
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">
                              <label>Project Start Date</label>
                              <div>
                                 <div class="input-group">
                                    <input type="text" name="prstart" class="form-control" placeholder="dd/mm/yyyy" id="datepicker-autoclose">
                                    <span class="input-group-addon bg-custom b-0"><i class="mdi mdi-calendar text-white"></i></span>
                                 </div>
                                 <!-- input-group -->
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <label>Estimate Project End Date</label>
                              <div>
                                 <div class="input-group">
                                    <input type="text" name="edate" class="form-control" placeholder="dd/mm/yyyy" id="datepicker-autoclose">
                                    <span class="input-group-addon bg-custom b-0"><i class="mdi mdi-calendar text-white"></i></span>
                                 </div>
                                 <!-- input-group -->
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">
                              <label for="field-4" class="control-label">Area(Only Numbers)</label>
                              <input type="number" name="area" class="form-control" id="field-4" placeholder="Total Area">
                           </div>
                        </div>
                        <div class="col-md-4">
                           <div class="form-group">
                              <label for="field-5" class="control-label">Dimensions</label>
                              <select class="selectpicker" name="dimensions" data-style="btn-secondary btn-rounded" id="selectpicker">
                                 <option value="">Please Select Option </option>
                                 <option value="SquareFeet">Square Feet </option>
                                 <option value="SquareMeter">Square Meter</option>
                                 <option value="SquareYard">Square Yard</option>
                                 <option value="Acre">Acre</option>
                                 <option value="Other">Other</option>
                              </select>
                           </div>
                        </div>
                        <div class="col-md-2">
                           <div class="form-group others" id="others">
                              <label for="field-5" class="control-label">Only Others</label>
                              <input type="text" name= "others" class="form-control" id="field-4" placeholder="Fill Others">
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">
                              <label for="password">Stage Of Project : </label>
                              <select class="selectpicker" name="prstage" data-style="btn-secondary btn-rounded">
                                 <option value="">Please Select Option </option>
                                 <option value="Yettostart">Yet to start</option>
                                 <option value="Structure">Structure</option>
                                 <option value="Plastering">Plastering</option>
                                 <option value="Flooring">Flooring</option>
                                 <option value="Finishing">Finishing</option>
                                 <option value="Interiors">Interiors</option>
                                 <option value="Other">Other</option>
                              </select>
                           </div>
                        </div>
                        <div class="col-md-6">
                          
                              <p>Image Upload</p>
                              <input type="file" name="upquote[]" multiple="multiple" accept="image/*">
                        
                        </div>
                     </div>
                     <div class="form-group account-btn text-center m-t-10">
                        <div class="col-xs-12">
                           
                           <button class="btn w-lg btn-rounded btn-lg btn-primary waves-effect waves-light" name="addquote" type="submit">Submit</button>
                        </div>
                     </div>
                  </form>
               </div>
               <!-- Close card-box -->
            </div>
            <!--col-lg-12-->
         </div>
         <!-- Main Content row-->
      </div>
      <!-- container -->
   </div>
   <!-- content -->
</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
<script>
   $(document).ready(function(){
     var date_input=$('input[name="edate"]'); //our date input has the name "date"
     var container=$('#addnewprojects form').length>0 ? $('#addnewprojects form').parent() : "body";
     var options={
       format: 'dd/mm/yyyy',
       container: container,
       todayHighlight: true,
       autoclose: true,
     };
     date_input.datepicker(options);
   });
   
   $(function() {
      $('#others').hide();
      $('#selectpicker').change(function(){
      if($('#selectpicker').val() == 'Other') {
            $('#others').show(); 
        } else {
            $('#others').hide(); 
        } 
   });
   });
   
</script>

<script src="plugins/moment/moment.js"></script>
<script src="plugins/timepicker/bootstrap-timepicker.js"></script>
<script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="plugins/select2/js/select2.min.js" type="text/javascript"></script>
<script src="plugins/bootstrap-select/js/bootstrap-select.js" type="text/javascript"></script>
<script src="plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js" type="text/javascript"></script>
<script src="assets/pages/jquery.form-pickers.init.js"></script>
