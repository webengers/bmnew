<?php include 'headerpage.php';
if(isset($proid))
{  include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>
<!-- DataTables -->
<link href="plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<!-- Responsive datatable examples -->
<link href="plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">View Project List </h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                     <li class="breadcrumb-item"><a href="#">Projects</a></li>
                     <li class="breadcrumb-item active">View Projects</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->
         <?php
            if(isset($added)){ ?>
         <div class="alert alert-success alert-dismissible fade show" role="alert">
               <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
               </button>
             <strong>Well done!</strong> You successfully Added Your Project Details.
         </div>
         <?php }
            ?>
         <?php
            if(isset($adfail)){ ?>
         <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            Your Project details not Added yet please try again later.
         </div>
         <?php }
            ?>
         <!-- Main Contetbt Start-->
         <div class="row">
            <div class="col-lg-12">
               <div class="card-box table-responsive">
                  <h4 class="m-t-0 header-title"><b>View Projects List Out</b></h4>
                  <table id="datatable" class="table table-bordered">
                     <thead>
                        <tr>
                           <th>Sl.No</th>
                           <th>Project Name</th>
                           <th>Project Location</th>
                           <th>Project Start Date</th>
                           <th>Stage of Project</th>
                           <th>Operations</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php
                        require_once("../dbconfig.php");
                        extract($_REQUEST);
                        $aid= $_SESSION["aid"];
                        $sql="SELECT * FROM `projects_data`";
                        $result = $conn->query($sql);
                        $count=$result->num_rows;
                        if ($count > 0) {
                        $x=1;
                        while ($row = $result->fetch_object()) {
                               $proid =$row->project_id;  ?>
                        <tr>
                           <td><?=$x;?></td>
                           <td><?=$row->project_title;?></td>
                           <td><?=$row->project_location;?></td>
                           <td><?=$row->project_start_date;?></td>
                           <td><?=$row->project_stage;?></td>
                           <td>
                              <a href="edit-Project.php?proid=<?=$proid;?>" class="btn btn-sm btn-primary" title="Edit"><i class="fa fa-edit"></i></a>
                              <a href="addNewProjects.php?proid=<?=$proid;?>" class="btn btn-sm btn-danger" title="delete" onclick="return confirm('Are You Sure the delete this Item')" ><i class="fi-trash"></i></a>
                           </td>
                        </tr>
                       <?php $x++;  }  }   ?>
                     </tbody>
                  </table>
               </div>
            </div>
            <!--col-lg-12-->
         </div>
         <!-- Main Content row-->
      </div>
      <!-- container -->
   </div>
   <!-- content -->
</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap4.min.js"></script>
<!-- Buttons examples -->
<script src="plugins/datatables/dataTables.buttons.min.js"></script>
<script src="plugins/datatables/buttons.bootstrap4.min.js"></script>
<script src="plugins/datatables/jszip.min.js"></script>
<script src="plugins/datatables/pdfmake.min.js"></script>
<script src="plugins/datatables/vfs_fonts.js"></script>
<script src="plugins/datatables/buttons.html5.min.js"></script>
<script src="plugins/datatables/buttons.print.min.js"></script>
<script src="plugins/datatables/buttons.colVis.min.js"></script>
<!-- Responsive examples -->
<script src="plugins/datatables/dataTables.responsive.min.js"></script>
<script src="plugins/datatables/responsive.bootstrap4.min.js"></script>
<script type="text/javascript">
   $(document).ready(function() {
       $('#datatable').DataTable();
   
       //Buttons examples
       var table = $('#datatable-buttons').DataTable({
           lengthChange: false,
           buttons: ['copy', 'excel', 'pdf', 'colvis']
       });
   
       table.buttons().container()
               .appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');
   } );
   
</script>