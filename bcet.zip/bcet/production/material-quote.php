<?php
session_start();
include ("../dbconfig.php");
extract($_REQUEST);
$aid = $user_id;
$proid= $project_id;
//print_r($_REQUEST);
if(isset($_POST['brand_val']))
{
	$categoriesa = implode(",",$category);
	$prnamea = implode(",", $productname);
	//$brands = implode(",", $brand);
	$quantitys =implode(",",$quantity);
	$unit_pricea = implode(",", $unit_pricea);
	$remark = implode(",",$remarks);
	//$proprices = implode(",", $rowprice);
    $sql = "INSERT INTO `estimation_data`(`estimation_id`, `est_customer_id`, `est_project_id`, `est_category_name`, `est_product_name`, `est_qty`, `est_brand`, `est_unitprice`, `est_amount`, `est_remarks`) VALUES (NULL, '$aid', '$proid','$categoriesa', '$prnamea', '$quantitys', '', '$unit_pricea','$brand_val','$remark')";
    $result = $conn->query($sql);
	if($result === TRUE){
		echo "<script>window.location.assign('material-details.php?proid=".$proid."');</script>";
	       }
	else{
		//echo "<script>window.location.assign('quote-invoice.php');</script>";
	    }
 } 

//Edit Page 

if(isset($_POST['brand_valup']) && $_POST['edit'])
{
	//print_r($_REQUEST);
	$categoriesa = implode(",",$category);
	$prnamea = implode(",",$productname);
	//$brand = implode(",",$br);
	$quantity1 = implode(",",$quantitys);
	$unit_pricea = implode(",",$unit_pricea);
	$remark = implode(",",$remarks);
	//$proprices = implode(",", $rowprice);
    $sql1 = "UPDATE `estimation_data` SET `est_customer_id`='$aid',`est_project_id`='$proid',`est_category_name`='$categoriesa',`est_product_name`='$prnamea',`est_qty`='$quantity1',`est_brand`='',`est_unitprice`='$unit_pricea',`est_amount`='$brand_valup',`est_remarks`='$remark' WHERE `estimation_id`='$edit'";
	$result1 = $conn->query($sql1);
	if($result1 == TRUE){
		echo "<script>window.location.assign('material-details.php?proid=".$proid."');</script>";
	       }
	else{
		echo "<script>window.location.assign('quote-invoice.php');</script>";
	    }
	 } 









 ?>
