<?php include 'headerpage.php';
if(isset($proid))
{  include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>

<!-- Project Name -->
<?php $pr_sql = $conn->query("SELECT * FROM `projects_data` where project_id ='$proid' ");
if($pr_row = $pr_sql->fetch_object()){ $prname = $pr_row->project_title;  } ?>


<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">Material Estimation Project <p><?=$prname;?></h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                     
                     <li class="breadcrumb-item active">Material Estimation</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
          <a href="material-details.php?proid=<?=$proid;?>"><input type="button" class="btn btn-sm btn-success float-left" value="Edit Material Details"></a>
          <br><br>
         <!-- end row -->
         <div class="row">
            <div class="col-lg-12">
               <div class="card-box">
                  <style type="text/css">
                     table {table-layout: fixed;width: 100%;*margin-left: -100px; }
                     td, th { vertical-align: top;border-top: 1px solid #ccc;padding: 10px;width: 100px; }
                     th { /*  position:absolute; *position: relative; /*ie7*/ /*  left:0; */ width: 100px; }
                     .hard_left { width:200px; }
                     .outer { position: relative; }
                     .inner { overflow-x: scroll;overflow-y: visible; margin-left: 200px; }
                     .pm { width:260px!important; }
                     .frmSearch { margin: 2px 0px;}
                     #country-list{ float:left;list-style:none;margin-top:-3px;padding:0;width:190px;position: absolute;}
                     #country-list li{ padding: 10px; background: #f0f0f0; border-bottom: #bbb9b9 1px solid;}
                     #country-list li:hover{ background:#ece3d2;cursor: pointer;}
                     #search-box{ padding: 10px;border: #a8d4b1 1px solid;border-radius:4px;}
                  </style>
                  <form method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                     <table class="table table-hover small-text" id="tb">
                        <tr class="tr-header">
                           <th class="hard_left">Category</th>
                           <th class="pm"> Product Name </th>
                           <th> Qty </th>
                           <!--<th> Brand </th>-->
                           <th> Unit Price </th>
                           <th> Amount </th>
                           <th> Remarks </th>
                        </tr>
                        <tr>
                          <?php for ($y = 1; $y <= 14; $y++) { ?>
                                          <?php $cat_sql = $conn->query("SELECT * FROM `category` where category_id ='$y' ");
                                             while($cat_row = $cat_sql->fetch_object()) 
                                             { 
                                               $cat_id = $cat_row->category_id; 
                                               $cat_name = $cat_row->category_name; } ?>
                           <td class="hard_left select">
                              <input type="text" id="product_name<?=$y;?>" name="category[]" placeholder="Category Name" value="<?=$cat_name;?>" class="form-control" readonly>
                           </td>
                           <td>
                              <div class="frmSearch">
                                 <input list="search-list<?=$y;?>" id="search-box<?=$y;?>" placeholder="Product Name" class="form-control search-box<?=$y;?>" name="productname[]"/>
                                 <datalist id="search-list<?=$y;?>"></datalist>
                              </div>
                           </td>
                           <td>
                              <input type="number" class="form-control quantity" id="quantity<?=$y;?>" name="quantity[]" value ="1">
                           </td>
                           <!--<td>
                              <input list="brand-list<?=$y;?>" name="brand[]" id="brand<?=$y;?>" placeholder="brand" class="form-control brand<?=$y;?>">
                              <datalist id="brand-list<?=$y;?>"></datalist>
                           </td>-->
                           <td>
                              <input type="number" id="unit_pricea<?=$y;?>" name="unit_pricea[]" class="form-control unit_pricea<?=$y;?>">
                           </td>
                           <td>
                              <input type="text" id="amounta<?=$y;?>" name="amounta[]" class="form-control amounta" readonly>
                           </td>
                           <td>
                            <input type="text" name="remarks[]" id="remarks<?=$y;?>" placeholder="Remarks" class="form-control remarks<?=$y;?>">
                              
                           </td>

                        </tr>
                         <?php  } ?>
                     </table>
               </div>
            </div>
            <div class="col-md-5 col-sm-5 col-xs-5">
            Total Project Cost : 
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
            @ Total Amount <input type='text' id="amount4" class="form-control" name="Total Amount"  readonly/>
            <br>
            <button type="submit" formaction="material-quote.php" class="btn btn-primary btn-sm pull-right">Submit</button>
            </div>
          
            <br><br>
            <input type="hidden" value="<?=$aid;?>" name="user_id">
             <input type="hidden" value="<?=$proid;?>" name="project_id">
            <input type="hidden" name="brand_val" value="" id="brand_val"/>
         </div>
         <!--Panel Group-->
      </div>
   </div>
   </form>
</div>
<!--Card-box-->
</div><!--col-lg-12-->
</div><!--main content row-->
</div>
<!-- container -->
</div>
<!-- content -->
</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
<script type='text/javascript'>
   <?php for ($x = 1; $x <= 14; $x++) 
      { ?>
          $("#search-box<?=$x;?>").keyup(function(){
             // console.log($(this).val());
              $.ajax({
              type: "POST",
              url: "searchlist.php",
              data:'keyword='+$(this).val(),
              success: (data) => {
                $("#search-list<?=$x;?>").html(data);
             }
              });
          });
          $('#search-box<?=$x;?>').blur(function() {
             var val = $("#search-list<?=$x;?>").val();
             $.ajax({
                 type: "POST",
                 url: "searchlist.php",
                 data:'amount='+$(this).val(),
                 success: (data) => {
                   console.log(data);
                 var number = $('#quantity<?=$x;?>').val();
                 //$("#unit_pricea<?=$x;?>").val(data); 
                 $("#unit_pricea<?=$x;?>").val(data.replace(',',''));
                 var o_val = $("#unit_pricea<?=$x;?>").val(); 
                 //console.log(o_val); 
                 var op_val = number * o_val;
                 //console.log(op_val);
                 $("#amounta<?=$x;?>").val(op_val);
                 var amount4_total = 0;
                 for (var i = 1; i <= 14; i++) {
                   amount4_total += Number($(`#amounta${i}`).val());
                   
                   // console.log($(`#amounta${i}`).val());
                 }
                  //console.log(amount4_total);
              $('#amount4').val(amount4_total);
            // console.log($("#brand_val").val($('#amount4').val(amount4_total)));
             $("#brand_val").val(amount4_total);
                 }
              });
               });
    
     /* Brand 1
       $("#brand<?=$x;?>").keyup(function() {
          //console.log($(this).val());
          $.ajax({
             type: "POST",
             url: "ajax1.php",
             data:'bname='+$(this).val(),
             success: (data) => {
               console.log(data);
               $("#brand-list<?=$x;?>").html(data);
             }
          });
       }); */
            /* Quantity Change*/ 
            $('#quantity<?=$x;?>').change(function () {
             var number = $(this).val();
               //console.log(number);
                var o_val = $("#unit_pricea<?=$x;?>").val();
                var op_val = number * o_val;
               $("#amounta<?=$x;?>").val(op_val);
                 var amount4_total = 0;
                
                 for (var i = 1; i <= 14; i++) {
                   amount4_total += Number($(`#amounta${i}`).val());
                   // console.log($(`#amounta${i}`).val());
                 }
                 // console.log(amount4_total);
              $('#amount4').val(amount4_total);
            // console.log($("#brand_val").val($('#amount4').val(amount4_total)));
             $("#brand_val").val(amount4_total);
             });
   
            /* Unit Price Change */
            $('#unit_pricea<?=$x;?>').change(function () {
             var number = $(this).val();
               //console.log(number);
                var o_val = $("#quantity<?=$x;?>").val();
                var op_val = number * o_val;
               $("#amounta<?=$x;?>").val(op_val);
               var amount4_total = 0;
               for (var i = 1; i <= 14; i++) {
                 amount4_total += Number($(`#amounta${i}`).val());
                 console.log($(`#amounta${i}`).val());
               }
              // console.log(amount4_total);
             $('#amount4').val(amount4_total);
             $("#brand_val").val(amount4_total);
             });
            /* Brand1 Close */
            
   <?php } ?>  
    
</script>