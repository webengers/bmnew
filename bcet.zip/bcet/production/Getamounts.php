<?PHP
    extract($_REQUEST);
    include('../dbconfig.php');
    $tot=0;
    $tot=$unitslm*$unitpricelm;
?>
<div class="9">
<input type='number' class='form-control rowpricelm<?=$x; ?> amount' id='rowpricelm<?=$x; ?>' name='rowpricelm[]' value='<?php echo $tot; ?>' readonly></div>