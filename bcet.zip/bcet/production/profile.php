<?php include 'headerpage.php';?>
<?php include 'leftside.php';?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
<!-- Start content -->
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="page-title-box">
               <h4 class="page-title float-left">Profile</h4>
               <ol class="breadcrumb float-right">
                  <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                  <li class="breadcrumb-item active">Profie Page</li>
               </ol>
               <div class="clearfix"></div>
            </div>
         </div>
      </div>
      <!-- end row -->
      <?php
                     if(isset($pwdsucc)){?>
                  <div class="alert alert-success" role="alert">
                     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                     <strong>Password Changed sucessfully</strong> 
                  </div>
                  <?php }
                     ?>
                  <?php
                     if(isset($pwderr)){?>
                  <div class="alert alert-warning" role="alert">
                     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                     <strong>Dear User, the old Password is not correct. Plz enter correct old password.</strong>&nbsp;Try again 
                  </div>
                  <?php }
                     if(isset($pwderror)){?>
                  <div class="alert alert-warning" role="alert">
                     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                     <strong>Dear User, New Password and Confirm Password not match.</strong>&nbsp;Try again 
                  </div>
                  <?php } if(isset($add)){?>
                  <div class="alert alert-success alert-dismissible" role="alert">
                     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                     <b>Your Profile is Successfully Added !!!</b> 
                  </div>
                  <?php } 
                     if(isset($edit)){?>
                  <div class="alert alert-success alert-dismissible" role="alert">
                     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                     <b>Your Profile is Successfully Updated !!!</b> 
                  </div>
                  <?php } ?>

      <!-- Main Contetbt Start-->
      <div class="row">
         <div class="col-lg-12">
            <div class="card-box">
                  <?php
                     $aid=$_SESSION['aid'];
                     $email=$_SESSION['email'];
                     $sql ="SELECT  * from customers where customer_id = $aid";
                      $result = $conn->query($sql);
                      if($row = $result->fetch_assoc())
                      { 
                       $pic = $row['customer_profile_pic']; ?>
                  <div class="row">
                     <div class="col-md-3">
                        <!-- Profile Image -->
                        <div class="box box-primary">
                           <div class="box-body box-profile">
                              <div class="text-center">
                                 <form class="form-horizontal" method="post" action="profile_db.php" enctype="multipart/form-data">
                                    <?php if(!empty($pic)) { ?>
                                    <img src="users/<?=$aid;?>/<?=$pic;?>" class="avatar img-rounded" alt="avatar"  height="144px" width="176px">
                                    <?php } else { ?>
                                    <img src="assets/images/user.png" class="avatar img-rounded" alt="avatar"  height="144px" width="176px">
                                    <?php } ?>
                                    <h6>Upload a different photo...</h6>
                                    <input type="file" class="text-center center-block well well-sm" name="slogo" style="width:210px;" required = "true">
                                    <br>
                                    <br>
                                    <div class="col-sm-offset-2 col-sm-10">
                                       <button type="submit" class="btn btn-danger">Update</button>
                                    </div>
                              </div>
                              </form>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-9">
                        <div class="nav-tabs-custom">
                           <ul class="nav nav-tabs">
                              <li class="nav-item">
                                 <a href="#settings" data-toggle="tab" aria-expanded="true" class="nav-link active">Settings</a>
                              </li>
                              <li class="nav-item">
                                 <a href="#password" data-toggle="tab" aria-expanded="false" class="nav-link"> Passwords</a>
                              </li>
                           </ul>
                           <div class="tab-content">
                              <div class="active tab-pane" id="settings">
                                 <form class="form-horizontal" role="form" method="post" action="profile_db.php" enctype="multipart/form-data">
                                    <input type="hidden" value="dummy" name="profile_update">
                                    <div class="form-group">
                                       <label for="inputName" class="col-sm-2 control-label">Username</label>
                                       <div class="col-sm-10">
                                          <input type="text" class="form-control" placeholder="Username"  name="uname" 
                                             value="<?=$row['customer_name'];?>" readonly>
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <label for="inputEmail" class="col-sm-2 control-label">Email</label>
                                       <div class="col-sm-10">
                                          <input type="email" class="form-control" id="inputEmail" placeholder="Email" name="email" value="<?=$row['customer_email'];?>" readonly>
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <label for="inputName" class="col-sm-2 control-label">Name</label>
                                       <div class="col-sm-10">
                                          <input type="text" class="form-control" id="inputName" placeholder="Name" name="name"
                                             value="<?=$row['customer_name'];?>" >
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <label for="inputName" class="col-sm-2 control-label">Mobile</label>
                                       <div class="col-sm-10">
                                          <input type="text" class="form-control" id="inputName" placeholder="Mobile" name="mobile"
                                             value="<?=$row['customer_mobile'];?>">
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <label for="inputExperience" class="col-sm-2 control-label">Address</label>
                                       <div class="col-sm-10">
                                          <textarea class="form-control" id="inputExperience" placeholder="Address" name="address"><?=$row['customer_area'];?></textarea>
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <div class="col-sm-offset-2 col-sm-10">
                                          <button type="submit" class="btn btn-danger">Update</button>
                                       </div>
                                    </div>
                                 </form>
                                 <?php } else{ ?>
                                 <form class="form-horizontal" role="form" method="post" action="profile_db.php" enctype="multipart/form-data">
                                    <div class="form-group">
                                       <label for="inputName" class="col-sm-2 control-label">Username</label>
                                       <div class="col-sm-10">
                                          <input type="text" class="form-control" placeholder="Username"  name="uname" >
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <label for="inputEmail" class="col-sm-2 control-label">Email</label>
                                       <div class="col-sm-10">
                                          <input type="email" class="form-control" id="inputEmail" placeholder="Email" name="email">
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <label for="inputName" class="col-sm-2 control-label">Name</label>
                                       <div class="col-sm-10">
                                          <input type="text" class="form-control" id="inputName" placeholder="Name" name="name">
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <label for="inputName" class="col-sm-2 control-label">Mobile</label>
                                       <div class="col-sm-10">
                                          <input type="text" class="form-control" id="inputName" placeholder="Mobile" name="mobile">
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <label for="inputExperience" class="col-sm-2 control-label">Address</label>
                                       <div class="col-sm-10">
                                          <textarea class="form-control" id="inputExperience" placeholder="Address" name="address"></textarea>
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <div class="col-sm-offset-2 col-sm-10">
                                          <button type="submit" class="btn btn-danger">Submit</button>
                                       </div>
                                    </div>
                                 </form>
                                 <?php } ?>
                              </div>
                              <!--settings tabs closee-->
                              <div class="tab-pane" id="password">
                                 <form class="form-horizontal" role="form" method="post" action="changepwd_db.php" enctype="multipart/form-data">
                                    <div class="form-group">
                                       <label for="inputName" class="col-sm-2 control-label"> Old Password </label>
                                       <div class="col-sm-10">
                                          <input type="password" class="form-control" name="oldpwd" required>
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <label for="inputEmail" class="col-sm-2 control-label">New Password </label>
                                       <div class="col-sm-10">
                                          <input type="password" class="form-control" name="newpwd" required>
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <label for="inputName" class="col-sm-4 control-label">Confirm Password </label>
                                       <div class="col-sm-10">
                                          <input type="password" class="form-control" name="cnfpwd" required>
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <div class="col-sm-offset-2 col-sm-10">
                                          <input id="submit" name="submit" type="submit" value="Update" class="btn btn-success">
                                       </div>
                                    </div>
                                 </form>
                              </div>
                              <!--tab-pane for password-->
                           </div>
                           <!-- tab content Close-->
                        </div>
                        <!--nav-custom-->
                     </div>
                     <!--col-md-9-->
                  </div>
                  <!--Card-box-->
               </div>
               <!--col-lg-12-->
            </div>
            <!-- Main Content Row Close -->
         </div>
         <!-- container -->
      </div>
      <!-- content -->
   </div>
   <!--content Page-->
   <!-- ============================================================== -->
   <!-- End Right content here -->
   <!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>