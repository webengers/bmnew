<?php include 'headerpage.php';?>
<?php include 'leftside.php';?>
<link href="assets/css/styles.css" rel="stylesheet">
<script src='assets/js/jquery.min.js'></script>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">Material Estimation Page </h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#"> Dashboard </a></li>
                     <li class="breadcrumb-item"><a href="#">Pages</a></li>
                     <li class="breadcrumb-item active">Material Estimation</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->
         <div class="row">
            <div class="col-lg-12">
               <div class="card-box">
                  <style>
    .bill .finput1{ height: 37px; text-align: center }
    .bill { margin-left: 1%; }
   .nav-md .container.body .right_col {
   padding: 10px 20px 0;
   margin-left: 230px;
   margin-bottom: -15px;
   }
    .buttomtab label{ float: left; margin-left: 10%; }
    .frow-box1 {
    margin: 0px 1.5px;
}
    .modal-title{ text-align: center; }
    .modal-body{ font-size: 16px; }
    .modal-body b{ color: #0C9CCE}
    .batchlist{ margin: 5px 0px; }
    .batchlistg{
        background: #aae8aa;
        height: 30px;
        padding-top: 5px;
    }
    .batchlistg a{
        color: #000;
        font-weight: bold;
    }
      .batchlistr{
        background: #fa5d5d;
        height: 30px;
        padding-top: 5px;
        color: #fff;
    }
    .batchlisty{
        background: #fbb7b7;
        height: 30px;
        padding-top: 5px;
    }
</style>
                    <div class="right_col" role="main">
      <form method="POST" action="invoice_db.php" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
         <div class="clearfix"></div>
         <div class="row">
                     <div class="col-md-6 pull-left">   <br/>
                         <h2>&nbsp;<a onclick="addMoreRows(this.form);"  class="btn btn-success">Add Another Item<img src="assets/images/add-items-icon.png"/></a></h2><br><br>
                    </div>
                     <div class="obox-row clearfix bill">
                        <div class="fcol-box1 fcol-box1">S.No</div>
                        <div class="fcol-box2 fcol-box1">Category</div>
                        <div class="fcol-box2 fcol-box1">Product Name</div>
                        <div class="fcol-box1 fcol-box1">Qty</div>
                        <div class="fcol-box1 fcol-box1">Brand</div>
                        <div class="fcol-box1 fcol-box1">Unit Price</div>
                        <div class="fcol-box2 fcol-box1">Amount</div>
                        <div class="fcol-box2 fcol-box1">Remarks</div>
                        <div class="fcol-box1 fcol-box1">Delete</div>
                     </div>
                     <div class="bill"  id="rowCount1">
                         <div class="obox-row clearfix">
                            <div class="frow-box1 frow-box1"><label class="finput1">1</label></div>
                            <div class="frow-box2 frow-box1">
                               <select class="select1_single finput1 product1" tabindex="-1" id="product1" name="product[]">
                                 <option value='' Selected>Select</option>
                                  <?php 
                                        $cat_sql = $conn->query("SELECT * FROM `category`");
                                        while($cat_row = $cat_sql->fetch_object()) 
                                        { ?>
                                           <option value="<?=$cat_row->category_id;?>"> <?=$cat_row->category_name;?> </option>
                                    <?php } ?>
                               </select>
                            </div>

                            <div class="frow-box2 frow-box1 products">
                               <input type="text" class="finput1 products" id="products" name="productname[]" >
                            </div>

                           <div class="frow-box1 frow-box1 units_ajax1">
                               <input type="number" class="finput1 units1" id="units1" name="units[]" value="1" min="1" onchange="changeunits1()" oninput="changeunits1()">
                            </div>

                            <div class="frow-box1 frow-box1 batch_ajax1">
                               <input type="text" class="finput1 batch" name="brand[]" readonly>
                            </div>
                            
                            <div class="frow-box1 frow-box1 unitprice_ajax1">
                               <input type="number"  class="finput1 unitprice1" id="unitprice1" min="1" name="unitprice[]" onchange="changeunitprice1()" oninput="changeunitprice1()">
                            </div>
                            <div class="frow-box2 frow-box1 rowprice_ajax1">
                               <input type="number" class="finput1 rowprice1 amount" id="rowprice1" name="rowprice[]">
                            </div>
                            <div class="frow-box2 frow-box1">
                               <input type="number" class="finput1 rowprice1 remarks" id="remarks1" name="remarks[]">
                            </div>
                            <div class="frow-box1 frow-box1">
                               <a class="action finput1"><img src="assets/images/delete.png" alt=""/></a>
                            </div>
                        </div>
                     </div>
                      <div id="addedRows" class="bill"></div>
                     <script type="text/javascript">
                        var rowCount = 1;
                        function addMoreRows(frm) 
                        {
                            rowCount ++;
                            var recRow = '<div class="obox-row clearfix" id="rowCount'+rowCount+'"><div class="frow-box1 frow-box1"><label class="finput1" id='+rowCount+'>'+rowCount+'</label></div><div class="frow-box2 frow-box1"><select class="select'+rowCount+'_single finput1 product'+rowCount+'" tabindex="-1" id="product'+rowCount+'" name="product[]" onchange="changeproduct'+rowCount+'()"></select></div><div class="frow-box2 frow-box1 products'+rowCount+'"><input type="text" class="finput1 products" name="productname[]"></div><div class="frow-box1 frow-box1 units_ajax1"><input type="number" class="finput1 units'+rowCount+'" id="units'+rowCount+'" name="units[]" value="1" min="1" onchange="changeunits'+rowCount+'()" oninput="changeunits'+rowCount+'()"></div><div class="frow-box1 frow-box1 batch_ajax'+rowCount+'"><input type="text" class="finput1 batch" name="brand[]" readonly></div><div class="frow-box1 frow-box1 unitprice_ajax'+rowCount+'"><input type="number"  class="finput1 unitprice'+rowCount+'" id="unitprice'+rowCount+'" min="1" name="unitprice[]" onchange="changeunitprice'+rowCount+'()" oninput="changeunitprice'+rowCount+'()"></div><div class="frow-box2 frow-box1 rowprice_ajax'+rowCount+'"><input type="number" class="finput1 rowprice'+rowCount+' amount" id="rowprice'+rowCount+'" name="rowprice[]"></div><div class="frow-box2 frow-box1 rowprice_ajax'+rowCount+'"><input type="number" class="finput1 remarks'+rowCount+' remarks" id="remarks'+rowCount+'" name="remarks[]" ></div><div class="frow-box1 frow-box1"><a  class="action finput1" href="javascript:void(0);" onclick="removeRow('+rowCount+');"><img src="assets/images/delete.png" alt=""/></a></div></div> '; 
                            jQuery('#addedRows').append(recRow);
                            var dataString =  'rowCount='+ rowCount;
                                $.ajax({
                                url: "Getproduct.php",
                                data: dataString,
                                cache: false,
                                success: function(html){
                                $('#products'+rowCount+'').html(html);
                                } 
                            });
                        }
                        function removeRow(removeNum) {
                            jQuery('#rowCount'+removeNum).remove();
                            rowCount --;
                        }          
                     </script>
                     <div class="obox-row clearfix buttomtab">
                        <br><br>
                        <div class="frow-box2 frow-box1"><label>Grass Amount</label></div>
                        <div class="frow-box2 frow-box1"><input type="text" class="finput1" name="grosstotal" id="grosstotal" readonly></div>
                        <div class="frow-box2 frow-box1"><label>Discount (%)</label></div>
                        <div class="frow-box2 frow-box1">
                           <input type="number" class="finput1 discount" id="discount" name="discount" value="0" min="0" onchange="changediscounttax()" oninput="changediscounttax()">
                        </div>
                         <div class="frow-box2 frow-box1"><label>Tax (%)</label></div>
                         <div class="frow-box2 frow-box1">
                             <input type="number" class="finput1 tax tax_ajax"  id="tax" name='tax' value="0" min=0 onchange="changediscounttax()" required oninput="changediscounttax()">
                         </div>
                        <div class="frow-box2 frow-box1"><label>Net Amount</label></div>
                        <div class="frow-box2 frow-box1"><input type="text" class="finput1" name="nettotal" id="nettotal" readonly></div>
                        <br><br>
                        <div class="frow-box2 frow-box1 baltype_ajax"><label>Credit Balance</label></div>
                        <div class="frow-box2 frow-box1 balance_ajax"><input type="text" class="finput1 dueamount" name="dueamount" id="dueamount" readonly></div>
                        <div class="frow-box2 frow-box1"><label>Pay Mode</label></div>
                        <div class="frow-box2 frow-box1">
                           <select class="finput1 paymode" id="paymode" name='paymode' onchange="changepaymode()" required>
                              <option value='Cash' Selected>Cash</option>
                              <option value='Debit'>Debit</option>
                           </select>
                        </div>
                        <div class="frow-box2 frow-box1" id="payamountname"><label>Pay Amount</label></div>
                        <div class="frow-box2 frow-box1"><input type="number" class="finput1 payamount" name="payamount" id="payamount"  oninput="changepayamount()" min="0" value="0"></div>
                        <div class="frow-box2 frow-box1"><label id="dueamounttype">Debit Amount</label></div>
                        <div class="frow-box2 frow-box1"><input type="text" class="finput1" name="duetotal" id="duetotal" readonly><input type="hidden" name="duetype" id="duetype"> </div>
                        <center><br><br><br><input type="submit" name="existbill" onclick="" class="btn btn-success"></center>
                     </div>
                  
           
            </div>
      </form> 
</div>