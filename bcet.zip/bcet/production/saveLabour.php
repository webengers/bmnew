<?php session_start();
      extract($_REQUEST);
      print_r($_REQUEST); ?>
