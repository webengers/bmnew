<?php include 'headerpage.php';
if(isset($proid))
{  include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>
<!-- Project Name -->
<?php $pr_sql = $conn->query("SELECT * FROM `projects_data` where project_id ='$proid' ");
if($pr_row = $pr_sql->fetch_object()){ $prname = $pr_row->project_title;  } ?>
<link href="plugins/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
<link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">
<link href="plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" />
<link href="plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />

<!-- DataTables -->
<link href="plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<!-- Responsive datatable examples -->
<link href="plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">Orders for <b><?=$prname;?></b></h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Procurements</a></li>
                  
                     <li class="breadcrumb-item active">Orders</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->
         <!-- Main Contetbt Start-->
         <div class="row">
            <div class="col-sm-12">
               <div class="card-box">
                  <div class="row">
                     <div class="col-sm-8">
                        <div class="form-group">
                           <label>Date Range</label>
                           <div>
                              <div class="input-daterange input-group" id="date-range">
                                 <input type="text" class="form-control" name="start" />
                                 <span class="input-group-addon bg-custom text-white b-0">to</span>
                                 <input type="text" class="form-control" name="end" />
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="form-group">
                           <label>Categories</label>
                           <select class="selectpicker" data-style="btn-secondary btn-rounded">
                              <option>Cement</option>
                              <option>Steel</option>
                              <option>Sand</option>
                           </select>
                        </div>
                        <!-- form group-->
                     </div>
                     <!--col-sm-4-->
                  </div>
                  <div class="row">
                     <div class="col-sm-12">
                        <div class="card-box">
                           <h4 class="m-t-0 header-title">Orders Table</h4>
                           <div class="table-responsive">
                           <table id="datatable" class="table table-bordered">
                              <thead>
                                 <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Item Name</th>
                                    <th>Qty</th>
                                    <th>Invoice Amount</th>
                                    <th>Invoice Pic</th>
                                    
                                 </tr>
                              </thead>
                              <tbody>
                               <?php  $sql1 = "SELECT `projects_data`.`project_title` , `purchase_data`.`pur_itemname` , `purchase_data`.`pur_category` , `purchase_data`.`pur_brand` , `purchase_data`.`pur_qty` , `purchase_data`.`pur_rate` , `purchase_data`.`pur_amount` , `purchase_data`.`pur_pic` , `purchase_data`.`pur_others` , `purchase_data`.`pur_date` FROM `purchase_data` INNER JOIN `projects_data` ON (`purchase_data`.`project_id` = `projects_data`.`project_id`) WHERE `purchase_data`.`project_id` = '$proid' ";
                                    $result1 = $conn->query($sql1);
                                    $count=$result1->num_rows;
                                     if ($count > 0) {
                                     $x=1;
                                    while ($row1 = $result1->fetch_object()) {
                                        $date = $row1->pur_date; 
                                        $pur_qty = $row1->pur_qty;
                                        $itemname = $row1->pur_itemname;
                                        $category = $row1->pur_category;
                                        $invoice_amount = $row1->pur_amount;
                                        $primagesp = $row1->pur_pic;
                                        $protitle = $row1->project_title;
                                        $imgp = explode(",", $primagesp);
                                        $realPath = 'users/'.$aid.'/projects/'.$protitle.'/images';
                                     ?>

                                 <tr>
                                    <th scope="row">1</th>
                                    <th><?=$date;?></th>
                                    <td><?=$itemname;?></td>
                                     <td><?=$pur_qty;?></td>
                                    <td><?=$invoice_amount;?></td>
                                    <td><?php 
                                       foreach($imgp as $img)
                                       {
                                       echo '<img src="'.$realPath.'/'.$img.'" height="310" width="215" alt="Slider Imagesp" class="img-fluid">';
                                       } ?></td>
                                   
                                 </tr>
                               <?php $x++; } }  ?>
                              </tbody>
                           </table>
                         </div>
                        </div>
                     </div>
                  </div>
                  <!-- end row -->
               </div>
               <!-- row close-->
            </div>
            <!--Card-box-->
         </div>
         <!--col-lg-12-->
      </div>
      <!-- Main Content Row Close -->
   </div>
   <!-- container -->
</div>
<!-- content -->
</div><!--content Page-->
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
<!-- plugin js -->
<script src="plugins/moment/moment.js"></script>
<script src="plugins/timepicker/bootstrap-timepicker.js"></script>
<script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="plugins/clockpicker/js/bootstrap-clockpicker.min.js"></script>
<script src="plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="plugins/select2/js/select2.min.js" type="text/javascript"></script>
<script src="plugins/bootstrap-select/js/bootstrap-select.js" type="text/javascript"></script>
<!-- Init js -->
<script src="assets/pages/jquery.form-pickers.init.js"></script>

<!--datatables-->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Responsive examples -->
<script src="plugins/datatables/dataTables.responsive.min.js"></script>
<script src="plugins/datatables/responsive.bootstrap4.min.js"></script>
<script type="text/javascript">
   $(document).ready(function() {
       $('#datatable').DataTable();
   } );
   </script>