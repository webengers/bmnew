<?php include 'headerpage.php';
if(isset($proid))
{  include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>

<!-- Project Name -->
<?php $pr_sql = $conn->query("SELECT * FROM `projects_data` where project_id ='$proid' ");
if($pr_row = $pr_sql->fetch_object()){ $prname = $pr_row->project_title;  } ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">View To Do Page <b><?=$prname;?></b> </h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                     <li class="breadcrumb-item active">To Do List View Page </li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->

         <?php
            if(isset($update)){ ?>
         <div class="alert alert-success alert-dismissible fade show" role="alert">
               <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
               </button>
             <strong>Well done!</strong> You successfully Update Your Todo List.
         </div>
         <?php }
            ?>
         <?php
            if(isset($upfail)){ ?>
         <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            To-do Details not updated yet please try again later.
         </div>
         <?php }
            ?>

             <?php
            if(isset($deleted)){ ?>
         <div class="alert alert-success alert-dismissible fade show" role="alert">
               <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
               </button>
             <strong>Well done!</strong> You successfully Deleted Your Todo List.
         </div>
         <?php }
            ?>
         <?php
            if(isset($delete)){ ?>
         <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            To-do Details not Deleted yet please try again later.
         </div>
         <?php }
            ?>

         <!-- Main Contetbt Start-->
         <div class="row">
            <div class="col-sm-12">
               <div class="card-box">
                  <h4 class="m-t-0 header-title">View To Do </h4>
                  <table class="table table-bordered">
                  <thead>
                     <tr>
                        <th>#</th>
                        <th>Project</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Subject</th>
                        <th>Description</th>
                        <th>Due Date</th>
                        <th>Due Time</th>
                        <th>Operations</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php
                        require_once("../dbconfig.php");
                        extract($_REQUEST);
                        $aid= $_SESSION["aid"];
                        $sql="SELECT * FROM `todolist_data` where project_id = '$proid'";
                        $result = $conn->query($sql);
                        $count=$result->num_rows;
                        if ($count > 0) {
                        $x=1;
                        while ($row = $result->fetch_object()) {
                               $toid =$row->todo_id; ?>
                     <tr>
                        <td><?=$x;?></td>
                        <td>
                           <?=$row->project_id;?>
                        </td>
                        <td>
                           <?=$row->todo_date;?>
                        </td>
                        <td>
                           <?=$row->todo_time;?>
                        </td>
                        <td>
                           <?=$row->todo_subject;?>
                        </td>
                        <td>
                           <?=$row->todo_description;?>
                        </td>
                        <td>
                           <?=$row->due_todo_date;?>
                        </td>
                         <td>
                           <?=$row->due_todo_time;?>
                        </td>
                        <td>
                              <a href="edit_todolist.php?todoid=<?=$toid;?>&proid=<?=$proid;?>" title="View/Edit" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                              <a href="add-Todolist.php?del=<?=$toid;?>&proid=<?=$proid;?>" title="Delete" class="btn btn-sm btn-danger" onclick="return confirm('Are You Sure the delete this Item')" ><i class="fi-trash"></i></a>
                              <?php 
                                 if($row->todo_status == 1)
                                 {
                                     ?> 
                              <a href="add-Todolist.php?todoid=<?=$toid;?>&proid=<?=$proid;?>&todostatus=<?=$row->todo_status;?>" id="active" ><input type="checkbox" class="js-switch" checked /></a>
                              <?php }
                                 else
                                 { ?>
                              <a href="add-Todolist.php?todoid=<?=$toid;?>&proid=<?=$proid;?>&todostatus=<?=$row->todo_status;?>"><input type="checkbox" class="js-switch" /></a>
                              <?php } ?>
                        </td>
                     </tr>
                     <?php $x++;  }  }   ?>
                  </tbody>
                </table>
               </div>
               <!--Card-box-->
            </div>
            <!--col-lg-12-->
         </div>
         <!-- Main Content Row Close -->
      </div>
      <!-- container -->
   </div>
   <!-- content -->
</div>
<!--content Page-->
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>