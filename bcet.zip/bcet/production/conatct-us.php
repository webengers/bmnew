<?php include 'headerpage.php';
$projectid = $_SESSION["proid"];
$prname = $_SESSION["prname"];
if( $projectid == $proid)
{ include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">Contact Us</h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                     <li class="breadcrumb-item"><a href="#">Help/Contact Us</a></li>
                     <li class="breadcrumb-item active">Contact Us</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->
         <!-- Main Contetbt Start-->
         <div class="row">
            <div class="col-lg-12">
               <div class="card-box">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="contact-map">
                                                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15303.3918821826!2d80.6180206!3d16.483234!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xfc9dfc297617edf8!2sBuild+Mitra!5e0!3m2!1sen!2sin!4v1548932827556"
                                                        frameborder="0" scrolling="no" marginheight="0" marginwidth="0"
                                                        style="width: 100%; height: 360px;"></iframe>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row m-t-50 m-b-30">
                                        <div class="col-md-10 offset-1">
                                            <div class="row m-b-20">
                                                <div class="col-sm-12">
                                                    <h3 class="title">Send us a Message</h3>
                                                    <p class="text-muted sub-title">The clean and well commented code allows easy customization of the theme.It's <br> designed for describing your app, agency or business.</p>
                                                </div>
                                            </div>

                                            <div class="row">

                                                <!-- Contact form -->
                                                <div class="col-sm-6">
                                                    <form role="form" name="ajax-form" action="#" method="post" class="contact-form" data-parsley-validate="" novalidate="">

                                                        <div class="form-group">
                                                            <input class="form-control" id="name2" name="name" placeholder="Your name" type="text" value="" required="">
                                                        </div>
                                                        <!-- /Form-name -->

                                                        <div class="form-group">
                                                            <input class="form-control" id="email2" name="email" type="email" placeholder="Your email" value="" required="">
                                                        </div>
                                                        <!-- /Form-email -->

                                                        <div class="form-group">
                                                            <textarea class="form-control" id="message2" name="message" rows="5" placeholder="Message" required=""></textarea>
                                                        </div>
                                                        <!-- /Form Msg -->

                                                        <div class="row">
                                                            <div class="col-xs-12">
                                                                <div class="">
                                                                    <button type="submit" class="btn btn-primary waves-effect waves-light" id="send">Submit</button>
                                                                </div>
                                                            </div> <!-- /col -->
                                                        </div> <!-- /row -->

                                                    </form> <!-- /form -->
                                                </div> <!-- end col -->

                                                <div class="col-sm-4 offset-1">
                                                    <div class="contact-box">

                                                        <div class="contact-detail">
                                                            <i class="mdi mdi-account-location"></i>
                                                            <address>
                                                                 Flat No. 503, SP River View , Near Manipal Hospital, <br> 
                                                                 Tadepalle, Guntur-522501, Andhra Pradesh, India
                                                            </address>
                                                        </div>

                                                        <div class="contact-detail">
                                                            <i class=" mdi mdi-cellphone-iphone"></i>
                                                            <p>
                                                                +91 9133908800
                                                            </p>
                                                        </div>

                                                        <div class="contact-detail">
                                                            <i class="mdi mdi-email"></i>
                                                            <p>
                                                                <a href="">info@buildmitra.com</a>
                                                            </p>
                                                        </div>

                                                    </div>
                                                </div> <!-- end col -->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end row -->
                  </div>
               <!-- Close card-box -->
            </div>
            <!--col-lg-12-->
         </div>
         <!-- Main Content row-->
      </div>
      <!-- container -->
   </div>
   <!-- content -->
</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>