<?php include 'headerpage.php';
if(isset($proid))
{  include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>
<!-- Project Name -->
<?php $pr_sql = $conn->query("SELECT * FROM `projects_data` where project_id ='$proid' ");
if($pr_row = $pr_sql->fetch_object()){ $prname = $pr_row->project_title;  } ?>

<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
<script src='assets/js/jquery.min.js'></script>
<!-- Custom box css -->
<link href="plugins/custombox/css/custombox.min.css" rel="stylesheet">
<!-- Plugins css-->
<link href="plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" />
<link href="plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="plugins/switchery/switchery.min.css">
<link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">
<!-- Jquery filer css -->
<link href="plugins/jquery.filer/css/jquery.filer.css" rel="stylesheet" />
<link href="plugins/jquery.filer/css/themes/jquery.filer-dragdropbox-theme.css" rel="stylesheet" />
<!-- Bootstrap fileupload css -->
<link href="plugins/bootstrap-fileupload/bootstrap-fileupload.css" rel="stylesheet" />

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
        
            <div class="row">
               <div class="col-12">
                  <div class="page-title-box">
                     <h4 class="page-title float-left">Daily Report Management <b><?=$prname;?></b> </h4>
                     <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="#"> Daily Reports </a></li>
                        <li class="breadcrumb-item active">Edit Daily Reports</li>
                     </ol>
                     <div class="clearfix"></div>
                  </div>
               </div>
            </div>
            <!-- end row -->
            <!-- Main Content Start-->
            <form  method="post" enctype="multipart/form-data" id="myForm" role="form">
               
            <!-- <div class="form-group">
               <label>Select Date </label>
               <div>
                  <div class="input-group">
                     <input type="text" class="form-control" name="date" value="<?=$date;?>" placeholder="dd/mm/yyyy" id="datepicker-autoclose">
                     <span class="input-group-addon bg-custom b-0"><i class="mdi mdi-calendar text-white"></i></span>
                  </div>
                  <!-input-group 
               </div>
            </div> -->

             <?php  $sql1 = "SELECT `projects_data`.`project_id`,`quotes_data`.`quo_pic`, `purchase_data`.`pur_pic`, `workinprogress_inhouse`.`wipho_invpic`, `payments_data`.`payment_image`, `upload_photos`.`upload_images`, `quotes_data`.`quo_date`,`purchase_data`.`pur_date`,`projects_data`.`project_title`,`upload_photos`.`upload_id` FROM `quotes_data`,`purchase_data`,`workinprogress_inhouse`,`payments_data`, `upload_photos`,`projects_data` WHERE `projects_data`.`project_id` = '$proid'";
                           $result1 = $conn->query($sql1);
                           if ($row1 = $result1->fetch_object()) {
                               $date = $row1->quo_date; 
                               $upid = $row1->upload_id;
                               $primagesq = $row1->quo_pic;
                               $primagesp = $row1->pur_pic;
                               $primagesw = $row1->wipho_invpic;
                               $primages = $row1->upload_images;
                               $primagespay = $row1->payment_image; 
                               $protitle = $row1->project_title;
                               $imgp = explode(",", $primagesp);
                               $imgq = explode(",", $primagesq);
                               $imgw = explode(",", $primagesw);
                               $imgpay = explode(",", $primagespay);
                               $img = explode(",", $primages);
                               $realPath = 'users/'.$aid.'/projects/'.$protitle.'/images/';
                            } ?>

            <!-- Material Purchase Div-->        
            <div class="row">
               <div class="col-lg-12">
                  <div class="card-box">
                     <h4 class="header-title m-t-0 m-b-30">Material Management</h4>
                     <ul class="nav nav-tabs">
                        <!-- <li class="nav-item">
                           <a href="#quote" data-toggle="tab" aria-expanded="true" class="nav-link active">
                           Quotes
                           </a>
                        </li> -->
                        <li class="nav-item">
                           <a href="#purchase" data-toggle="tab" aria-expanded="false" class="nav-link active">
                           Purchases
                           </a>
                        </li>
                        <li class="nav-item">
                           <a href="#usage" data-toggle="tab" aria-expanded="false" class="nav-link">
                           Usage
                           </a>
                        </li>
                     </ul>
                     

                     <div class="tab-content">
                        <div class="tab-pane fade show active" id="purchase">
                            <div class="row">
                              <div class="card-box">

                             <?php $pur_data = $conn->query("SELECT * FROM `purchase_data` where project_id ='$proid' ");
                              while($pur_row = $pur_data->fetch_assoc()) 
                              { 
                                $pmid = $pur_row['pur_id'];
                                $category = $pur_row['pur_category'];
                                $categories = explode(',',$category);
                                $lenght = sizeof($categories);

                                $product = $pur_row['pur_itemname'];
                                $products = explode(',',$product);
                              
                                $brand = $pur_row['pur_brand'];
                                $brands = explode(',',$brand);

                                $unitprice = $pur_row['pur_rate'];
                                $unitprices = explode(',',$unitprice);

                                $qty = $pur_row['pur_qty'];
                                $quantity = explode(',',$qty);

                                $remarks = $pur_row['pur_others'];
                                $remark = explode(',',$remarks);

                                $est_amou = $pur_row['pur_amount'];
                                $est_amount = explode(',',$est_amou);

                                $edr_others = $pur_row['pur_others'];
                                $edr_other = explode(',',$edr_others); } ?>

                              <?php for($i=0; $i<$lenght; $i++)
                                {  ?>
                                 <div class="bill" id="rowCounte1">
                                        
                                        <div class="form-group row qtyp">
                                            <label for="qty" class="col-3 col-form-label qtyp"> Qty </label>
                                            <div class="col-9">
                                                 <input type="number" class="form-control unitsp1" id="unitsp1" name="unitsp[]" value="<?=$quantity[$i];?>" min="1" onchange="changeunitsp<?=$i;?>()" oninput="changeunitsp<?=$i;?>()">
                                            </div>
                                        </div>

                                        <div class="form-group row unitpricep_ajax1">
                                            <label for="unitrpice" class="col-3 col-form-label unitpricep"> Unit Price </label>
                                            <div class="col-9">
                                                <input type="number" class="form-control unitprice1" id="unitpricep1" min="1" name="unitpricep[]" value="<?=$unitprices[$i];?>" onchange="changeunitpricep1()" oninput="changeunitpricep1()"> 
                                            </div>
                                        </div>

                                        <div class="form-group row rowpricep_ajax1">
                                            <label for="amount" class="col-3 col-form-label amountp"> Amount </label>
                                            <div class="col-9">
                                                <input type="number" class="form-control rowpricep1 amount" id="rowpricep1" name="rowpricep[]" value="<?=$est_amount[$i];?>" readonly>
                                            </div>
                                        </div>

                                        
                                         <div class="frow-box1 frow-box1">
                                           <a class="action finput1 removesp"><img src="assets/images/delete.png" alt=""/></a>
                                        </div>
                                        <a onclick="addMoreRowsp(this.form);"  class="btn btn-success"> Add Another Item <img src="assets/images/add-items-icon.png"/></a>
                                      </div>
                                  <?php }  ?>
                                   
                                 <div id="addedRowsp" class="bill"></div>
                                <script type="text/javascript">
                                    var rowCounte = 1;
                                    function addMoreRowsp(frm) 
                                    {
                                        rowCounte ++;
                                        var recRow = '<div class="obox-row clearfix" id="rowCount'+rowCounte+'"><div class="form-group row itemnamep'+rowCounte+'"><label for="itemname" class="col-3 col-form-label itemnamep">Item Name</label><div class="col-9"><input type="text" class="form-control itemname" name="itemnamep[]" id="itemnamep" placeholder="Item Name"></div></div><div class="form-group row categoriesp'+rowCounte+'"><label for="categories" class="col-3 col-form-label categoriesp">Categories</label><div class="col-9"><input type="text" class="form-control categoriesp" name="categoriesp[]" id="categoriesp" placeholder="categories"></div></div><div class="form-group row brandp'+rowCounte+'"><label for="brand" class="col-3 col-form-label brandp"> Brand </label><div class="col-9"><input type="text" class="form-control brandp" id="brandp" name="brandp[]" placeholder="Brand"></div></div><div class="form-group row qtyp'+rowCounte+'"><label for="qty" class="col-3 col-form-label qtyp"> Qty </label><div class="col-9"><input type="number" class="form-control unitsp'+rowCounte+'" id="unitsp'+rowCounte+'" name="unitsp[]" value="1" min="1" onchange="changeunitsp'+rowCounte+'()" oninput="changeunitsp'+rowCounte+'()"></div></div> <div class="form-group row unitpricep_ajax'+rowCounte+'"><label for="unitrpice" class="col-3 col-form-label unitpricep"> Unit Price </label><div class="col-9"><input type="number"  class="form-control unitpricep'+rowCounte+'" id="unitpricep'+rowCounte+'" min="1" name="unitpricep[]" onchange="changeunitpricep'+rowCounte+'()" oninput="changeunitpricep'+rowCounte+'()"></div></div><div class="form-group row rowpricep_ajax'+rowCounte+'"><label for="amount" class="col-3 col-form-label amountp"> Amount </label><div class="col-9"><input type="number" class="form-control rowpricep'+rowCounte+' amount" id="rowpricep'+rowCounte+'" name="rowpricep[]" readonly></div></div><div class="form-group row qpicp'+rowCounte+'"><label for="qpic" class="col-3 col-form-label qpicp"> Quopic </label><div class="col-9"><input type="file" class="form-control qpicp" id="qpicp" placeholder="Quotation Pic" name="qpicp[]"></div></div><div class="form-group row othersp'+rowCounte+'" ><label for="others" class="col-3 col-form-label othersp"> Others </label><div class="col-9"><input type="text" name="othersp" class="form-control othersp" id="othersp" placeholder="Others"></div></div><div class="frow-box1 frow-box1"><a class="action finput1 removesp" href="javascript:void(0);" onclick="removeRowsp('+rowCounte+');"><img src="assets/images/delete.png" alt=""/></a></div></div>'; 
                                        jQuery('#addedRowsp').append(recRow);
                                        var dataString =  'rowCounte='+ rowCounte;
                                            $.ajax({
                                            data: dataString,
                                            cache: false,
                                            success: function(html){
                                            $(rowCount+'').html(html);
                                            } 
                                        });
                                    }
                                    function removeRowsp(removeNum) {
                                        jQuery('#rowCounte'+removeNum).remove();
                                        rowCount --;
                                    }          
                                 </script>
                  
                            </div><!--card box close-->
                        </div><!--row-->  
                        </div>
            <!-- Main Content row-->
            <input type="hidden" value="<?=$qmid;?>" name="mmqu">
             <input type="hidden" value="<?=$pmid;?>" name="mmpu">
              <input type="hidden" value="<?=$umid;?>" name="mmusage">
               <input type="hidden" value="<?=$lmid;?>" name="lmin">
                <input type="hidden" value="<?=$wiiphid;?>" name="wrkin">
                <input type="hidden" value="<?=$payid;?>" name="pmp">
                <input type="hidden" value="<?=$otherid;?>" name="oino">
                <input type="hidden" value="<?=$upid;?>" name="uplpo">
                

                   <input type="hidden" value="<?=$aid;?>" name="user_id">
                   <input type="hidden" value="<?=$proid;?>" name="project_id">
                   <input type="hidden" name="editdaily" value="editdaily">


            <button type="submit" formaction="editdaily-Db.php?proid=<?=$proid;?>&pur_id=<?=$pur_id;?>" name='edit' value='submit' class="btn btn-purple waves-effect waves-light pull-right">Update</button>
            <br>
         </form>
          <br>
      </div>
      <!-- container -->
   </div>
   <!-- content -->
</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
<script src="plugins/moment/moment.js"></script>
<script src="plugins/timepicker/bootstrap-timepicker.js"></script>
<script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="plugins/select2/js/select2.min.js" type="text/javascript"></script>
<script src="plugins/bootstrap-select/js/bootstrap-select.js" type="text/javascript"></script>
<script src="plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js" type="text/javascript"></script>
<script src="assets/pages/jquery.form-pickers.init.js"></script>
<!-- Jquery filer js -->
<script src="plugins/jquery.filer/js/jquery.filer.min.js"></script>
<!-- Bootstrap fileupload js -->
<script src="plugins/bootstrap-fileupload/bootstrap-fileupload.js"></script>
<!-- page specific js -->
<script src="assets/pages/jquery.fileuploads.init.js"></script>
<script>
 
   <?php for ($x = 1; $x <= 30; $x++) 
    { ?>
      function changeunitprice<?=$x;?>()
        {  
            var x = <?=$x; ?> ;
            var units=document.getElementById("units<?=$x;?>").value;
            var unitprice=document.getElementById("unitprice<?=$x;?>").value;
            var dataString = 'unitprice='+ unitprice+'&units='+ units+'&x='+ x;
            //alert(dataString);
            $.ajax({
                type: "POST",
                url: "Getrowprice.php",
                data: dataString,
                cache: false,
                success: function(html){
                    $('.rowprice_ajax<?=$x;?>').html(html);
                     var grosstotal=0;
                    $(".amount").each(function(){
                         grosstotal += parseFloat($(this).val()||0);
                    });
                  }
            });
        }

        function changeunits<?=$x;?>()
        {  
            var x = <?=$x; ?> ;
            var units=document.getElementById("units<?=$x;?>").value;
            var unitprice=document.getElementById("unitprice<?=$x;?>").value;
            var dataString = 'unitprice='+ unitprice+'&units='+ units+'&x='+ x;
            //alert(dataString);
            $.ajax({
                type: "POST",
                url: "Getrowprice.php",
                data: dataString,
                cache: false,
                success: function(html){
                    $('.rowprice_ajax<?=$x;?>').html(html);
                    var grosstotal=0;
                    $(".amount").each(function(){
                         grosstotal += parseFloat($(this).val()||0);
                    });
                } 
            });
        } 
          /*Material Management Quotes close */

        /*Material Management Purchases */
        function changeunitpricep<?=$x;?>()
        {  
            var x = <?=$x; ?> ;
            var unitsp=document.getElementById("unitsp<?=$x;?>").value;
            var unitpricep=document.getElementById("unitpricep<?=$x;?>").value;
            var dataString = 'unitpricep='+ unitpricep+'&unitsp='+ unitsp+'&x='+ x;
            //alert(dataString);
            $.ajax({
                type: "POST",
                url: "getAmount.php",
                data: dataString,
                cache: false,
                success: function(html){
                    $('.rowpricep_ajax<?=$x;?>').html(html);
                     var grosstotal=0;
                    $(".amount").each(function(){
                         grosstotal += parseFloat($(this).val()||0);
                    });
                  }
            });
        }

        function changeunitsp<?=$x;?>()
        {  
            var x = <?=$x; ?> ;
            var unitsp=document.getElementById("unitsp<?=$x;?>").value;
            var unitpricep=document.getElementById("unitpricep<?=$x;?>").value;
            var dataString = 'unitpricep='+ unitpricep+'&unitsp='+ unitsp+'&x='+ x;
            //alert(dataString);
            $.ajax({
                type: "POST",
                url: "getAmount.php",
                data: dataString,
                cache: false,
                success: function(html){
                    $('.rowpricep_ajax<?=$x;?>').html(html);
                    var grosstotal=0;
                    $(".amount").each(function(){
                         grosstotal += parseFloat($(this).val()||0);
                    });
                } 
            });
        }
          /*Material Management Purchases Close */

            /*Labour Management */

            function changeunitpricelm<?=$x;?>()
        {  
            var x = <?=$x; ?> ;
            var unitslm=document.getElementById("unitslm<?=$x;?>").value;
            var unitpricelm=document.getElementById("unitpricelm<?=$x;?>").value;
            var dataString = 'unitpricelm='+ unitpricelm+'&unitslm='+ unitslm+'&x='+ x;
            //alert(dataString);
            $.ajax({
                type: "POST",
                url: "Getamounts.php",
                data: dataString,
                cache: false,
                success: function(html){
                    $('.rowpricelm_ajax<?=$x;?>').html(html);
                     var grosstotal=0;
                    $(".amount").each(function(){
                         grosstotal += parseFloat($(this).val()||0);
                    });
                  }
            });
        }

        function changeunitslm<?=$x;?>()
        {  
            var x = <?=$x; ?> ;
            var unitslm=document.getElementById("unitslm<?=$x;?>").value;
            var unitpricelm=document.getElementById("unitpricelm<?=$x;?>").value;
            var dataString = 'unitpricelm='+ unitpricelm+'&unitslm='+ unitslm+'&x='+ x;
            //alert(dataString);
            $.ajax({
                type: "POST",
                url: "Getamounts.php",
                data: dataString,
                cache: false,
                success: function(html){
                    $('.rowpricelm_ajax<?=$x;?>').html(html);
                    var grosstotal=0;
                    $(".amount").each(function(){
                         grosstotal += parseFloat($(this).val()||0);
                    });
                } 
            });
        }
/*labour management close*/
<?php } ?>
</script>
