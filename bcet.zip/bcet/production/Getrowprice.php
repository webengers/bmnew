<?PHP
    extract($_REQUEST);
    include('../dbconfig.php');
    $tot=0;
    $tot=$units*$unitprice;
?><label for="" class="col-3 col-form-label"> Amount </label>
<div class="9">
<input type='number' class='form-control rowprice<?=$x; ?> amount' id='rowprice<?=$x; ?>' name='rowprice[]' value='<?php echo $tot; ?>' readonly>
</div>