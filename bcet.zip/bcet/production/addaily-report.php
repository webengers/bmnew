<?php include 'headerpage.php';
   if(isset($proid))
   {  include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>
<!-- Project Name -->
<?php $pr_sql = $conn->query("SELECT * FROM `projects_data` where project_id ='$proid' ");
   if($pr_row = $pr_sql->fetch_object()){ $prname = $pr_row->project_title;  } ?>
<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
<script src='assets/js/jquery.min.js'></script>
<!-- Custom box css -->
<link href="plugins/custombox/css/custombox.min.css" rel="stylesheet">
<!-- Plugins css-->
<link href="plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" />
<link href="plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="plugins/switchery/switchery.min.css">
<link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">
<!-- Jquery filer css -->
<link href="plugins/jquery.filer/css/jquery.filer.css" rel="stylesheet" />
<link href="plugins/jquery.filer/css/themes/jquery.filer-dragdropbox-theme.css" rel="stylesheet" />
<!-- Bootstrap fileupload css -->
<link href="plugins/bootstrap-fileupload/bootstrap-fileupload.css" rel="stylesheet" />
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">Daily Report Management <b><?=$prname;?></b> </h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                     <li class="breadcrumb-item"><a href="#"> Daily Reports </a></li>
                     <li class="breadcrumb-item active">Add Daily Reports</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->
         <!-- Main Content Start-->
         <form action="addaily-Db.php" method="post" enctype="multipart/form-data" id="myForm" role="form">
            <div class="form-group">
               <label>Select Date </label>
               <div>
                  <div class="input-group">
                     <input type="text" class="form-control" name="date" placeholder="dd/mm/yyyy" id="datepicker-autoclose" required>
                     <span class="input-group-addon bg-custom b-0"><i class="mdi mdi-calendar text-white"></i></span>
                  </div>
                  <!-- input-group -->
               </div>
            </div>
            <!-- Material Purchase Div-->        
            <div class="row">
               <div class="col-lg-12">
                  <div class="card-box">
                     <h4 class="header-title m-t-0 m-b-30">Material Management</h4>
                     <ul class="nav nav-tabs">
                        <!-- <li class="nav-item">
                           <a href="#quote" data-toggle="tab" aria-expanded="true" class="nav-link">
                           Quotes
                           </a>
                        </li> -->
                        <li class="nav-item">
                           <a href="#purchase" data-toggle="tab" aria-expanded="false" class="nav-link active">
                           Purchases
                           </a>
                        </li>
                        <!-- <li class="nav-item">
                           <a href="#usage" data-toggle="tab" aria-expanded="false" class="nav-link">
                           Usage
                           </a>
                        </li> -->
                     </ul>
                     <div class="tab-content">
                        <!--<div class="tab-pane fade" id="quote">
                           <div class="row">
                              <div class="card-box">
                                 <a onclick="addMoreRowsm(this.form);"  class="btn btn-success"> Add Another Item <img src="assets/images/add-items-icon.png"/></a><br><br>
                                 <div class="bill"  id="rowCount1">
                                    <div class="form-group row itemname">
                                       <label for="itemname" class="col-3 col-form-label itemname">Item Name</label>
                                       <div class="col-9">
                                          <input type="text" class="form-control itemname" name="itemname[]" id="itemname" placeholder="Item Name">
                                       </div>
                                    </div>
                                    <div class="form-group row categories">
                                       <label for="categories" class="col-3 col-form-label categories">Categories</label>
                                       <div class="col-9">
                                          <input type="text" class="form-control categories" name="categories[]" id="categories" placeholder="categories">
                                       </div>
                                    </div>
                                    <div class="form-group row brand">
                                       <label for="brand" class="col-3 col-form-label brand"> Brand </label>
                                       <div class="col-9">
                                          <input type="text" class="form-control brand" id="brand" name="brand[]" placeholder="Brand">
                                       </div>
                                    </div>
                                    <div class="form-group row qty">
                                       <label for="qty" class="col-3 col-form-label qty"> Qty </label>
                                       <div class="col-9">
                                          <input type="number" class="form-control units1" id="units1" name="units[]" 
                                             value="1" min="1" onchange="changeunits1()" oninput="changeunits1()">
                                       </div>
                                    </div>
                                    <div class="form-group row unitprice_ajax1">
                                       <label for="unitrpice" class="col-3 col-form-label unitprice"> Unit Price </label>
                                       <div class="col-9">
                                          <input type="number" class="form-control unitprice1" id="unitprice1" min="1" name="unitprice[]" onchange="changeunitprice1()" oninput="changeunitprice1()">
                                       </div>
                                    </div>
                                    <div class="form-group row rowprice_ajax1">
                                       <label for="rowprice_ajax1" class="col-3 col-form-label rowprice_ajax1"> Amount </label>
                                       <div class="col-9">
                                          <input type="number" class="form-control rowprice amount1" id="rowprice1" name="rowprice[]" readonly>
                                       </div>
                                    </div>
                                    <div class="form-group row qpic">
                                       <label for="qpic" class="col-3 col-form-label quopic"> Quopic </label>
                                       <div class="col-9">
                                          <input type="file" class="form-control qpic" id="qpic" placeholder="Quotation Pic" name="qpic[]">
                                       </div>
                                    </div>
                                    <div class="form-group row others">
                                       <label for="others" class="col-3 col-form-label others"> Others </label>
                                       <div class="col-9">
                                          <input type="text" name="others[]" class="form-control others" id="others" placeholder="Others">
                                       </div>
                                    </div>
                                    <div class="frow-box1 frow-box1">
                                       <a class="action finput1 removesm"><img src="assets/images/delete.png" alt=""/></a>
                                    </div>
                                 </div>
                                 <br><br>
                                 <div id="addedRowsm" class="bill"></div>
                                 <script type="text/javascript">
                                    var rowCount = 1;
                                    function addMoreRowsm(frm) 
                                    {
                                        rowCount ++;
                                        var recRow = '<div class="obox-row clearfix" id="rowCount'+rowCount+'"><div class="form-group row itemname'+rowCount+'"><label for="itemname" class="col-3 col-form-label itemname">Item Name</label><div class="col-9"><input type="text" class="form-control itemname" name="itemname[]" id="itemname" placeholder="Item Name"></div></div><div class="form-group row categories'+rowCount+'"><label for="categories" class="col-3 col-form-label categories">Categories</label><div class="col-9"><input type="text" class="form-control categories" name="categories[]" id="categories" placeholder="categories"></div></div><div class="form-group row brand'+rowCount+'"><label for="brand" class="col-3 col-form-label brand"> Brand </label><div class="col-9"><input type="text" class="form-control brand" id="brand" name="brand[]" placeholder="Brand"></div></div><div class="form-group row qty'+rowCount+'"><label for="qty" class="col-3 col-form-label qty"> Qty </label><div class="col-9"><input type="number" class="form-control units'+rowCount+'" id="units'+rowCount+'" name="units[]" value="1" min="1" onchange="changeunits'+rowCount+'()" oninput="changeunits'+rowCount+'()"></div></div> <div class="form-group row unitprice_ajax1'+rowCount+'"><label for="unitrpice" class="col-3 col-form-label unitprice"> Unit Price </label><div class="col-9"><input type="number"  class="form-control unitprice'+rowCount+'" id="unitprice'+rowCount+'" min="1" name="unitprice[]" onchange="changeunitprice'+rowCount+'()" oninput="changeunitprice'+rowCount+'()"></div></div><div class="form-group row rowprice_ajax'+rowCount+'"><label for="amount" class="col-3 col-form-label amount"> Amount </label><div class="col-9"><input type="number" class="form-control rowprice'+rowCount+' amount" id="rowprice'+rowCount+'" name="rowprice[]" readonly></div></div><div class="form-group row qpic'+rowCount+'"><label for="qpic" class="col-3 col-form-label quopic"> Quopic </label><div class="col-9"><input type="file" class="form-control qpic" id="qpic" placeholder="Quotation Pic" name="qpic[]"></div></div><div class="form-group row others'+rowCount+'" ><label for="others" class="col-3 col-form-label others"> Others </label><div class="col-9"><input type="text" name="others" class="form-control others" id="others" placeholder="Others"></div></div><div class="frow-box1 frow-box1"><a class="action finput1 removesm" href="javascript:void(0);" onclick="removeRowsm('+rowCount+');"><img src="assets/images/delete.png" alt=""/></a></div>'; 
                                        jQuery('#addedRowsm').append(recRow);
                                        var dataString =  'rowCount='+ rowCount;
                                            $.ajax({
                                            data: dataString,
                                            cache: false,
                                            success: function(html){
                                            $(rowCount+'').html(html);
                                            } 
                                        });
                                    }
                                    function removeRowsm(removeNum) {
                                        jQuery('#rowCount'+removeNum).remove();
                                        rowCount --;
                                    }          
                                 </script>
                              </div>
                              <!--card box close
                           </div>
                           <!--row
                        </div>-->
                        <!--Quotes Div Close-->
                        <div class="tab-pane fade show active" id="purchase">
                           <div class="row">
                              <div class="card-box">
                                 <!-- <a onclick="addMoreRowsp(this.form);"  class="btn btn-success"> Add Another Item <img src="assets/images/add-items-icon.png"/></a> -->
                                 <div class="bill"  id="rowCount1">
                                    <div class="form-group row itemnamep">
                                       <label for="itemname" class="col-3 col-form-label itemnamep">Item Name</label>
                                       <div class="col-9">
                                          <input type="text" class="form-control itemnamep" name="itemnamep[]" id="itemnamep" placeholder="Item Name">
                                       </div>
                                    </div>
                                    <div class="form-group row categoriesp">
                                       <label for="categories" class="col-3 col-form-label categoriesp">Categories</label>
                                       <div class="col-9">
                                          <input type="text" class="form-control categoriesp" name="categoriesp[]" id="categoriesp" placeholder="categories">
                                       </div>
                                    </div>
                                    <div class="form-group row brandp">
                                       <label for="brand" class="col-3 col-form-label brandp"> Brand </label>
                                       <div class="col-9">
                                          <input type="text" class="form-control brandp" id="brandp" name="brandp[]" placeholder="Brand">
                                       </div>
                                    </div>
                                    <div class="form-group row qtyp">
                                       <label for="qty" class="col-3 col-form-label qtyp"> Qty </label>
                                       <div class="col-9">
                                          <input type="number" class="form-control unitsp1" id="unitsp1" name="unitsp[]" value="1" min="1" onchange="changeunitsp1()" oninput="changeunitsp1()">
                                       </div>
                                    </div>
                                    <div class="form-group row unitpricep_ajax1">
                                       <label for="unitrpice" class="col-3 col-form-label unitpricep"> Unit Price </label>
                                       <div class="col-9">
                                          <input type="number" class="form-control unitprice1" id="unitpricep1" min="1" name="unitpricep[]" onchange="changeunitpricep1()" oninput="changeunitpricep1()"> 
                                       </div>
                                    </div>
                                    <div class="form-group row rowpricep">
                                       <label for="amount" class="col-3 col-form-label amountp"> Amount </label>
                                       <div class="col-9 rowpricep_ajax1">
                                          <input type="number" class="form-control rowpricep1 amount" id="rowpricep1" name="rowpricep[]" readonly>
                                       </div>
                                    </div>
                                    <div class="form-group row qpic">
                                       <label for="qpic" class="col-3 col-form-label quopicp"> Purchase pic </label>
                                       <div class="col-9">
                                          <input type="file" class="form-control qpicp" id="qpicp" placeholder="Quotation Pic" name="qpicp[]">
                                       </div>
                                    </div>
                                    <div class="form-group row others">
                                       <label for="others" class="col-3 col-form-label otherp"> Others </label>
                                       <div class="col-9">
                                          <input type="text" name="othersp[]" class="form-control othersp" id="othersp" placeholder="Others">
                                       </div>
                                    </div>
                                    <div class="frow-box1 frow-box1">
                                       <a class="action finput1 removesp"><img src="assets/images/delete.png" alt=""/></a>
                                    </div>
                                    &nbsp;&nbsp;<a onclick="addMoreRowsp(this.form);" class="btn btn-success">Add<img src="assets/images/add-items-icon.png"/></a>
                                 </div>
                                 <br><br>
                                 <div id="addedRowsp" class="bill"></div>
                                 <script type="text/javascript">
                                    var rowCount = 1;
                                    function addMoreRowsp(frm) 
                                    {
                                        rowCount ++;
                                        var recRow = '<div class="obox-row clearfix" id="rowCount'+rowCount+'"><div class="form-group row itemnamep'+rowCount+'"><label for="itemname" class="col-3 col-form-label itemnamep">Item Name</label><div class="col-9"><input type="text" class="form-control itemname" name="itemnamep[]" id="itemnamep" placeholder="Item Name"></div></div><div class="form-group row categoriesp'+rowCount+'"><label for="categories" class="col-3 col-form-label categoriesp">Categories</label><div class="col-9"><input type="text" class="form-control categoriesp" name="categoriesp[]" id="categoriesp" placeholder="categories"></div></div><div class="form-group row brandp'+rowCount+'"><label for="brand" class="col-3 col-form-label brandp"> Brand </label><div class="col-9"><input type="text" class="form-control brandp" id="brandp" name="brandp[]" placeholder="Brand"></div></div><div class="form-group row qtyp'+rowCount+'"><label for="qty" class="col-3 col-form-label qtyp"> Qty </label><div class="col-9"><input type="number" class="form-control unitsp'+rowCount+'" id="unitsp'+rowCount+'" name="unitsp[]" value="1" min="1" onchange="changeunitsp'+rowCount+'()" oninput="changeunitsp'+rowCount+'()"></div></div> <div class="form-group row unitpricep_ajax'+rowCount+'"><label for="unitrpice" class="col-3 col-form-label unitpricep"> Unit Price </label><div class="col-9"><input type="number"  class="form-control unitpricep'+rowCount+'" id="unitpricep'+rowCount+'" min="1" name="unitpricep[]" onchange="changeunitpricep'+rowCount+'()" oninput="changeunitpricep'+rowCount+'()"></div></div><div class="form-group row'+rowCount+'"><label for="amount" class="col-3 col-form-label amountp"> Amount </label><div class="col-9 rowpricep_ajax'+rowCount+'"><input type="number" class="form-control rowpricep'+rowCount+' amount" id="rowpricep'+rowCount+'" name="rowpricep[]" readonly></div></div><div class="form-group row qpicp'+rowCount+'"><label for="qpic" class="col-3 col-form-label qpicp"> Quopic </label><div class="col-9"><input type="file" class="form-control qpicp" id="qpicp" placeholder="Quotation Pic" name="qpicp[]"></div></div><div class="form-group row othersp'+rowCount+'" ><label for="others" class="col-3 col-form-label othersp"> Others </label><div class="col-9"><input type="text" name="othersp" class="form-control othersp" id="othersp" placeholder="Others"></div></div><div class="frow-box1 frow-box1"><a class="action finput1 removesp" href="javascript:void(0);" onclick="removeRowsp('+rowCount+');"><img src="assets/images/delete.png" alt=""/></a></div>&nbsp;&nbsp;<a onclick="addMoreRowsp(this.form);" class="btn btn-success">Add<img src="assets/images/add-items-icon.png"/></a></div><br>'; 
                                        jQuery('#addedRowsp').append(recRow);
                                        var dataString =  'rowCount='+ rowCount;
                                            $.ajax({
                                            data: dataString,
                                            cache: false,
                                            success: function(html){
                                            $(rowCount+'').html(html);
                                            } 
                                        });
                                    }
                                    function removeRowsp(removeNum) {
                                        jQuery('#rowCount'+removeNum).remove();
                                        rowCount --;
                                    }          
                                 </script>
                              </div>
                              <!--card box close-->
                           </div>
                           <!--row-->   
                        </div>
                        <!-- Purchase Div Close-->
                        <!--<div class="tab-pane fade" id="usage">
                              <div class="row">
                                 <div class="card-box">
                                    <a onclick="addMoreRowsu(this.form);"  class="btn btn-success"> Add Another Item <img src="assets/images/add-items-icon.png"/></a><br><br>
                                    <div class="bill"  id="rowCount1">
                                       <div class="form-group row itemnameu">
                                          <label for="amount" class="col-3 col-form-label itemnameu"> Item Name </label>
                                          <div class="col-9">
                                             <input type="text" class="form-control itemnameu" name="itemnameu[]" id="itemnameu" placeholder="Item Name">
                                          </div>
                                       </div>
                                       <div class="form-group row qtyu">
                                          <label for="qtyu" class="col-3 col-form-label qtyu"> Qty </label>
                                          <div class="col-9">
                                             <input type="number" class="form-control qtyu" id="qtyu" placeholder="Quantity" name="qtyu[]">
                                          </div>
                                       </div>
                                       <div class="form-group row usage">
                                          <label for="usage" class="col-3 col-form-label usage"> Usage </label>
                                          <div class="col-9">
                                             <textarea class="form-control finput1 usage" id="Usagefor" rows="4" cols="50" name="usagefor[]"></textarea>
                                          </div>
                                       </div>
                                       <div class="frow-box1 frow-box1">
                                          <a class="action finput1 removesu"><img src="assets/images/delete.png" alt=""/></a>
                                       </div>
                                    </div>
                                    <div id="addedRowsu" class="bill"></div>
                                    <br>
                                    <script type="text/javascript">
                                       var rowCount = 1;
                                       function addMoreRowsu(frm) 
                                       {
                                           rowCount ++;
                                           var recRow = '<div class="obox-row clearfix" id="rowCount'+rowCount+'"><div class="form-group row itemnameu'+rowCount+'"><label for="amount" class="col-3 col-form-label itemnameu"> Item Name </label><div class="col-9"><input type="text" class="form-control itemnameu" name="itemnameu[]" id="itemnameu" placeholder="Item Name"></div></div><div class="form-group row qtyu"><label for="qtyu" class="col-3 col-form-label qtyu"> Qty </label><div class="col-9"><input type="number" class="form-control qtyu'+rowCount+'" id="qtyu'+rowCount+'" name="qtyu[]" value="1" min="1" placeholder="qty"></div></div><div class="form-group row usage'+rowCount+'"><label for="usage" class="col-3 col-form-label usage"> Usage </label><div class="col-9"><textarea class="form-control finput1 usage'+rowCount+'" id="usagefor'+rowCount+'" name="usagefor[]" rows="4" cols="50" placeholder="Usagefor"></textarea></div></div><div class="frow-box1 frow-box1"><a  class="action finput1 removesu" href="javascript:void(0);" onclick="removeRowsu('+rowCount+');"><img src="assets/images/delete.png" alt=""/></a></div></div>'; 
                                           jQuery('#addedRowsu').append(recRow);
                                           var dataString =  'rowCount='+ rowCount;
                                               $.ajax({
                                               data: dataString,
                                               cache: false,
                                               success: function(html){
                                               $(rowCount+'').html(html);
                                               } 
                                           });
                                       }
                                       function removeRowsu(removeNum) {
                                           jQuery('#rowCount'+removeNum).remove();
                                           rowCount --;
                                       }          
                                    </script>
                                    </div> <!--card box close-
                                 </div><!--row--
                        </div>-->
                        <!-- Usage Div Close-->
                     </div><!-- Tab Content-->
                  </div> <!-- Close card-box -->
               </div> <!--col-lg-12-->
            </div>
            <!-- Close Material Div-->
            <!--Labour Managemet start-->
            <div class="row">
               <div class="col-lg-12">
                  <div class="card-box">
                     <h4 class="header-title m-t-0 m-b-30">Labour Management</h4>
                     <ul class="nav nav-tabs">
                        <li class="nav-item">
                           <a href="#inhouse" data-toggle="tab" aria-expanded="true" class="nav-link active">
                           In House
                           </a>
                        </li>
                     </ul>
                     <div class="tab-content">
                        <div class="tab-pane fade show active" id="inhouse">
                           <!-- Inline Form -->
                           <div class="row">
                                 <div class="card-box">
                                     <div class="bill"  id="rowCount1">
                                         <div class="obox-row clearfix">
                                           <div class="form-group row catlabor">
                                                <label for="catlabor" class="col-3 col-form-label catlabor">Labor Category</label>
                                                <div class="col-9">
                                                    <input type="text" class="form-control catlabor" name="catlabor[]" id="catlabor" placeholder="Labor Category">
                                                </div>
                                            </div>
                                            <div class="form-group row unitslm">
                                                <label for="unitslm" class="col-3 col-form-label unitslm">No Of Workers</label>
                                                <div class="col-9">
                                                    <input type="number" class="form-control unitslm1" id="unitslm1" name="unitslm[]" value="1" min="1" onchange="changeunitslm1()" oninput="changeunitslm1()">
                                                </div>
                                            </div>
                                            <div class="form-group row unitpricelm_ajax1">
                                                <label for="brand" class="col-3 col-form-label unitpricelm"> Per Head Amount </label>
                                                <div class="col-9">
                                                   <input type="number"  class="form-control unitpricelm1" id="unitpricelm1" min="1" name="unitpricelm[]" onchange="changeunitpricelm1()" oninput="changeunitpricelm1()">
                                                </div>
                                            </div>

                                            <div class="form-group row rowpricelm">
                                                <label for="qty" class="col-3 col-form-label rowpricelm"> Total Amount </label>
                                                <div class="col-9 rowpricelm_ajax1">
                                                   <input type="number" class="form-control rowpricelm1 amount" id="rowpricelm1" name="rowpricelm[]" readonly>
                                                </div>
                                            </div>
                                            <div class="frow-box1 frow-box1">
                                               <a class="action finput1 removelm"><img src="assets/images/delete.png" alt=""/></a>
                                            </div>
                                            &nbsp;&nbsp;<a onclick="addMoreRowslm(this.form);"  class="btn btn-success"> Add <img src="assets/images/add-items-icon.png"/></a><br>
                                        </div>
                                     </div>
                                     <br><br>
                                      <div id="addedRowslm" class="bill"></div>
                                     <script type="text/javascript">
                                        var rowCount = 1;
                                        function addMoreRowslm(frm) 
                                        {
                                            rowCount ++;
                                            var recRow = '<div class="obox-row clearfix" id="rowCount'+rowCount+'"><div class="form-group row catlabor"> <label for="catlabor" class="col-3 col-form-label catlabor">Labor Category</label><div class="col-9"><input type="text" class="form-control catlabor'+rowCount+'form-control catlabor'+rowCount+'" id="catlabor'+rowCount+'"name="catlabor[]"></div></div><div class="form-group row unitslm"><label for="unitslm" class="col-3 col-form-label unitslm">No Of Workers</label><div class="col-9"><input type="number" class="form-control unitslm'+rowCount+'" id="unitslm'+rowCount+'" name="unitslm[]" value="1" min="1" onchange="changeunitslm'+rowCount+'()" oninput="changeunitslm'+rowCount+'()"></div></div><div class="form-group row unitpricelm unitpricelm_ajax'+rowCount+'"><label for="brand" class="col-3 col-form-label unitpricelm"> Per Head Amount </label><div class="col-9"><input type="number"  class="form-control unitpricelm'+rowCount+'" id="unitpricelm'+rowCount+'" min="1" name="unitpricelm[]" onchange="changeunitpricelm'+rowCount+'()" oninput="changeunitpricelm'+rowCount+'()"></div></div><div class="form-group row rowpricelm'+rowCount+'"> <label for="qty" class="col-3 col-form-label rowpricelm"> Total Amount </label><div class="col-9 rowpricelm_ajax'+rowCount+'"><input type="number" class="form-control rowpricelm'+rowCount+' amount" id="rowpricelm'+rowCount+'" name="rowpricelm[]" readonly></div><div class="frow-box1 frow-box1"><a  class="action finput1 removelm" href="javascript:void(0);" onclick="removeRowlm('+rowCount+');"><img src="assets/images/delete.png" alt=""/></a></div>&nbsp;&nbsp;<a onclick="addMoreRowslm(this.form);" class="btn btn-success"> Add <img src="assets/images/add-items-icon.png"/></a><br></div></div><br><br>'; 
                                            jQuery('#addedRowslm').append(recRow);
                                            var dataString =  'rowCount='+ rowCount;
                                                $.ajax({
                                                data: dataString,
                                                cache: false,
                                                success: function(html){
                                                $(rowCount+'').html(html);
                                                } 
                                            });
                                        }
                                        function removeRowlm(removeNum) {
                                            jQuery('#rowCount'+removeNum).remove();
                                            rowCount --;
                                        }          
                                     </script>
                                 </div><!--card box close-->
                              
                           </div><!-- end row / End Inline form-->
                        </div><!--in house tab close-->
                     </div><!--tab content-->
                  </div><!-- Close card-box -->
               </div> <!--col-lg-12-->
            </div>
            <!--Labour Management End-->
            <!-- Work In Progress -->
            <div class="row">
               <div class="col-lg-12">
                  <div class="card-box">
                     <h4 class="header-title m-t-0 m-b-30">Work In Progress</h4>
                     <ul class="nav nav-tabs">
                        <li class="nav-item">
                           <a href="#winhouse" data-toggle="tab" aria-expanded="true" class="nav-link active">
                           In House
                           </a>
                        </li>
                        <!-- <li class="nav-item">
                           <a href="#wsubcontract" data-toggle="tab" aria-expanded="false" class="nav-link">
                           Sub Contract
                           </a>
                           </li> -->
                     </ul>
                     <div class="tab-content">
                        <div class="tab-pane fade show active" id="winhouse">
                           <!-- Inline Form -->
                           <div class="row">
                              <div class="card-box">
                                 <div class="bill"  id="rowCount1">
                                       <div class="form-group row usageforwip">
                                          <label for="usageforwip" class="col-3 col-form-label usageforwip"> Usage For </label>
                                          <div class="col-9">
                                             <textarea class="form-control usageforwip" id="usageforwip" rows="4" cols="50" name="usageforwip[]"></textarea>
                                          </div>
                                       </div>
                                       <div class="form-group row usagefor">
                                          <label for="usagefor" class="col-3 col-form-label usagefor"> Usage Image </label>
                                          <div class="col-9">
                                             <input type="file" class="form-control usageforwippic" id="usageforwippic" placeholder="Quotation Pic" name="usageforwippic[]">
                                          </div>
                                       </div>
                                       <div class="frow-box1 frow-box1">
                                          <a class="action finput1 removeswinp"><img src="assets/images/delete.png" alt=""/></a>
                                       </div>
                                       
                                       &nbsp;&nbsp;<a onclick="addMoreRowswinp(this.form);" class="btn btn-success"> Add <img src="assets/images/add-items-icon.png"/></a>
                                 </div>
                                    <br><br>
                                    <div id="addedRowswinp" class="bill"></div>
                                     <script type="text/javascript">
                                       var rowCount = 1;
                                       function addMoreRowswinp(frm) 
                                       {
                                        rowCount ++;
                                        var recRow = '<div class="obox-row clearfix" id="rowCount'+rowCount+'"><div class="form-group row usageforwip'+rowCount+'"> <label for="usageforwip" class="col-3 col-form-label usageforwip"> Usage For </label><div class="col-9"><textarea class="form-control usageforwip'+rowCount+'" id="usageforwip'+rowCount+'" name="usageforwip[]" rows="4" cols="50" placeholder="Usagefor"></textarea></div></div><div class="form-group row usagefor usageforwippic"><label for="usagefor" class="col-3 col-form-label usagefor"> Usage Image </label><div class="col-9"><input type="file" class="form-control usageforwippic'+rowCount+'form-control usageforwippic'+rowCount+'" id="usageforwippic'+rowCount+'" name="usageforwippic[]"></div><div class="frow-box1 frow-box1"><a  class="action finput1 removeswinp" href="javascript:void(0);" onclick="removeRowswinp('+rowCount+');"><img src="assets/images/delete.png" alt=""/></a></div>&nbsp;&nbsp;<a onclick="addMoreRowswinp(this.form);"  class="btn btn-success"> Add <img src="assets/images/add-items-icon.png"/></a></div><br><br>'; 
                                        jQuery('#addedRowswinp').append(recRow);
                                        var dataString =  'rowCount='+ rowCount;
                                            $.ajax({
                                            data: dataString,
                                            cache: false,
                                            success: function(html){
                                            $(rowCount+'').html(html);
                                            } 
                                        });
                                    }
                                    function removeRowswinp(removeNum) {
                                        jQuery('#rowCount'+removeNum).remove();
                                        rowCount --;
                                    }          
                                 </script>
                              </div>
                              <!--card box close-->
                           </div>
                           <!--row-->
                        </div>
                        <!--winhouse close-->
                        <!-- <div class="tab-pane fade" id="wsubcontract">
                           <!-- Inline Form -
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="card-box">
                                    <h4 class="m-t-0 header-title"><i class="mdi mdi-plus"></i></h4>
                                    <div class="row">
                                       <div class="col-md-5">
                                          <div class="form-group">
                                             <label for="field-6" class="control-label">Notes </label>
                                             <textarea class="form-control" rows="5"></textarea>
                                          </div>
                                       </div>
                                       <div class="col-md-3">
                                          <div class="form-group">
                                             <label for="field-6" class="control-label">Upload Pics</label>
                                             <input type="file" class="filestyle" data-input="false" data-buttonname="btn-secondary">
                                          </div>
                                       </div>
                                       <div class="col-md-4">
                                          <div class="form-group">
                                             <label for="field-4" class="control-label">No.Of. Workers</label>
                                             <input type="text" class="form-control" id="field-4" placeholder="1">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <! end row / End Inline form-->
                     </div>
                     <!--wsubconant-->
                  </div>
                  <!--tab content-->
               </div>
               <!-- Close card-box -->
            </div>
            <!-- Work In Progress Close-->
            <!-- Payments -->
            <div class="row">
                  <div class="col-lg-12">
                     <div class="card-box">
                        <h4 class="header-title m-t-0 m-b-30">Payments Managements</h4>
                           <ul class="nav nav-tabs">
                            <li class="nav-item">
                              <a href="#payments" data-toggle="tab" aria-expanded="true" class="nav-link active">
                                 Payments
                              </a>
                            </li>
                           </ul>
                        <div class="tab-content">
                           <div class="tab-pane fade show active" id="payments">
                             <div class="row">
                               <div class="card-box">
                                    <div class="bill"  id="rowCount1">
                                       <div class="form-group row payeename">
                                          <label for="payeename" class="col-3 col-form-label payeename">Payee Name</label>
                                           <div class="col-9">
                                              <input type="text" class="form-control payeename" name="payeename[]" id="payeename" placeholder="Item Name">
                                           </div>
                                       </div>
                                       <div class="form-group row whtwrk">
                                          <label for="whtwrk" class="col-3 col-form-label whtwrk">Which Work</label>
                                          <div class="col-9">
                                             <input type="text" class="form-control whtwrk" name="whtwrk[]" id="whtwrk" placeholder="whtwrk">
                                          </div>
                                          </div>
                                       <div class="form-group row amtforpayee">
                                       <label for="amtforpayee" class="col-3 col-form-label amtforpayee"> Amount </label>
                                        <div class="col-9">
                                             <input type="number" class="form-control amtforpayee" id="amtforpayee" name="amtforpayee[]" placeholder="amount">
                                        </div>
                                       </div>
                                    <div class="form-group row imagepayee">
                                       <label for="imagepayee" class="col-3 col-form-label imagepayee"> Image Payee </label>
                                       <div class="col-9">
                                          <input type="file" class="form-control imagepayee" id="imagepayee" placeholder="Image Payee Pic" name="imagepayee[]">
                                       </div>
                                    </div>
                                    <div class="form-group row payeeremarks">
                                       <label for="Remarks" class="col-3 col-form-label payeeremarks"> Remarks </label>
                                       <div class="col-9">
                                          <input type="text" class="form-control payeeremarks" name="payeeremarks[]" id="payeeremarks" placeholder="Remarks" >
                                       </div>
                                    </div>
                                    <div class="frow-box1 frow-box1">
                                       <a class="action finput1 removepm"><img src="assets/images/delete.png" alt=""/></a>
                                    </div>
                                      &nbsp;&nbsp; <a onclick="addMoreRowspm(this.form);"  class="btn btn-success"> Add Another Item <img src="assets/images/add-items-icon.png"/></a><br>
                                    </div>
                                    <br>
                                    <div id="addedRowspm" class="bill"></div>
                                    <script type="text/javascript">
                                       var rowCount = 1;
                                       function addMoreRowspm(frm) 
                                       {
                                           rowCount ++;
                                           var recRow = '<div class="obox-row clearfix" id="rowCount'+rowCount+'"><div class="form-group row payeename'+rowCount+'"><label for="payeename" class="col-3 col-form-label payeename">Payee Name</label><div class="col-9"><input type="text" class="form-control payeename" name="payeename[]" ></div></div><div class="form-group row whtwrk"><label for="whtwrk" class="col-3 col-form-label whtwrk">What Work</label><div class="col-9"><input type="text" class="form-control whtwrk'+rowCount+'" id="whtwrk'+rowCount+'" name="whtwrk[]"></div></div><div class="form-group row amtforpayee'+rowCount+'"><label for="amtforpayee" class="col-3 col-form-label amtforpayee"> Amount </label><div class="col-9"><input type="number" class="form-control amtforpayee'+rowCount+'" id="amtforpayee'+rowCount+'" min="1" name="amtforpayee[]"></div></div><div class="form-group row imagepayee'+rowCount+'"><label for="imagepayee" class="col-3 col-form-label imagepayee"> Image Payee </label><div class="col-9"><input type="file" class="form-control imagepayee'+rowCount+' imagepayee" id="imagepayee'+rowCount+'" name="imagepayee[]" ></div></div><div class="form-group row payeeremarks'+rowCount+'"> <label for="Remarks" class="col-3 col-form-label payeeremarks"> Remarks </label><div class="col-9"><input type="text" class="form-control payeeremarks'+rowCount+' payeeremarks" id="payeeremarks'+rowCount+'" name="payeeremarks[]" ></div></div><div class="frow-box1 frow-box1"><a  class="action finput1 removepm" href="javascript:void(0);" onclick="removeRowpm('+rowCount+');"><img src="assets/images/delete.png" alt=""/></a></div> &nbsp;&nbsp; <a onclick="addMoreRowspm(this.form);"  class="btn btn-success"> Add Another Item <img src="assets/images/add-items-icon.png"/></a><br></div> '; 
                                           jQuery('#addedRowspm').append(recRow);
                                           var dataString =  'rowCount='+ rowCount;
                                               $.ajax({
                                               data: dataString,
                                               cache: false,
                                               success: function(html){
                                               $('#product'+rowCount+'').html(html);
                                               } 
                                           });
                                       }
                                       function removeRowpm(removeNum) {
                                           jQuery('#rowCount'+removeNum).remove();
                                           rowCount --;
                                       }          
                                    </script>
                                 </div><!--card Box-->
                              </div><!--row-->
                             </div><!--close tab panel-->
                           </div> <!-- Close Tab Content-box -->
                        </div>  <!--card box-->
                  </div> <!-- col-lg-12-->
            </div>
            <!-- Payments Close-->
            <!-- Other Information -->
            <div class="row">
                        <div class="col-lg-12">
                            <div class="card-box">
                                <h4 class="header-title m-t-0 m-b-30">Other Information</h4>
                                 <ul class="nav nav-tabs">
                                   <li class="nav-item">
                                        <a href="#notes" data-toggle="tab" aria-expanded="true" class="nav-link active">
                                          Notes
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                       <a href="#photos" data-toggle="tab" aria-expanded="false" class="nav-link">
                                        Upload Photos
                                       </a>
                                    </li>
                                 </ul>
                                 <div class="tab-content">
                                    <div class="tab-pane fade show active" id="notes">
                                       <textarea class="form-control" rows="5" name="otherInformation[]"></textarea>
                                    </div>
                                    <div class="tab-pane fade" id="photos">
                                       <div class="row">
                                          <div class="col-12">
                                             <div class="card-box">
                                                <h4 class="header-title m-t-0">Upload Multiple Images</h4>
                                                   <div class="p-20 p-b-0">
                                                        <div class="form-group clearfix">
                                                            <div class="col-sm-12 padding-left-0 padding-right-0">
                                                               <input type="file" name="files[]" id="filer_input1" multiple="multiple">
                                                             </div>
                                                          </div>
                                                   </div>
                                             </div>
                                          </div>
                                        </div> <!-- end row -->
                                    </div><!-- Photos tab-->
                                 </div> <!-- tab content of images-->
                           </div><!-- Close card-box -->
                        </div><!--col-lg-12-->
            </div><!-- Other Information Close-->
      <!-- Main Content row-->
      <input type="hidden" value="mmqu" name="mmqu">
      <input type="hidden" value="mmpu" name="mmpu">
      <input type="hidden" value="mmusage" name="mmusage">
      <input type="hidden" value="lmin" name="lmin">
      <input type="hidden" value="wrkin" name="wrkin">
      <input type="hidden" value="pmp" name="pmp">
      <input type="hidden" value="oino" name="oino">
      <input type="hidden" value="uplpo" name="uplpo">
      <input type="hidden" value="<?=$aid;?>" name="user_id">
      <input type="hidden" value="<?=$proid;?>" name="project_id">
      <button type="submit" name='submit' value='submit'  class="btn btn-purple waves-effect waves-light pull-right">Submit</button>
      <br>
      </form>
      <br>
   </div>
   <!-- container -->
</div>
<!-- content -->
</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
<script src="plugins/moment/moment.js"></script>
<script src="plugins/timepicker/bootstrap-timepicker.js"></script>
<script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="plugins/select2/js/select2.min.js" type="text/javascript"></script>
<script src="plugins/bootstrap-select/js/bootstrap-select.js" type="text/javascript"></script>
<script src="plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js" type="text/javascript"></script>
<script src="assets/pages/jquery.form-pickers.init.js"></script>
<!-- Jquery filer js -->
<script src="plugins/jquery.filer/js/jquery.filer.min.js"></script>
<!-- Bootstrap fileupload js -->
<script src="plugins/bootstrap-fileupload/bootstrap-fileupload.js"></script>
<!-- page specific js -->
<script src="assets/pages/jquery.fileuploads.init.js"></script>
<script>
   <?php for ($x = 1; $x <= 30; $x++) 
      { ?>
      function changeunitprice<?=$x;?>()
        {  
            var x = <?=$x; ?> ;
            var units=document.getElementById("units<?=$x;?>").value;
            var unitprice=document.getElementById("unitprice<?=$x;?>").value;
            var dataString = 'unitprice='+ unitprice+'&units='+ units+'&x='+ x;
            //alert(dataString);
            $.ajax({
                type: "POST",
                url: "Getrowprice.php",
                data: dataString,
                cache: false,
                success: function(html){
                    $('.rowprice_ajax<?=$x;?>').html(html);
                     var grosstotal=0;
                    $(".amount").each(function(){
                         grosstotal += parseFloat($(this).val()||0);
                    });
                  }
            });
        }
   
        function changeunits<?=$x;?>()
        {  
            var x = <?=$x; ?> ;
            var units=document.getElementById("units<?=$x;?>").value;
            var unitprice=document.getElementById("unitprice<?=$x;?>").value;
            var dataString = 'unitprice='+ unitprice+'&units='+ units+'&x='+ x;
            //alert(dataString);
            $.ajax({
                type: "POST",
                url: "Getrowprice.php",
                data: dataString,
                cache: false,
                success: function(html){
                    $('.rowprice_ajax<?=$x;?>').html(html);
                    var grosstotal=0;
                    $(".amount").each(function(){
                         grosstotal += parseFloat($(this).val()||0);
                    });
                } 
            });
        } 
          /*Material Management Quotes close */
   
        /*Material Management Purchases */
        function changeunitpricep<?=$x;?>()
        {  
            var x = <?=$x; ?> ;
            var unitsp=document.getElementById("unitsp<?=$x;?>").value;
            var unitpricep=document.getElementById("unitpricep<?=$x;?>").value;
            var dataString = 'unitpricep='+ unitpricep+'&unitsp='+ unitsp+'&x='+ x;
            //alert(dataString);
            $.ajax({
                type: "POST",
                url: "getAmount.php",
                data: dataString,
                cache: false,
                success: function(html){
                    $('.rowpricep_ajax<?=$x;?>').html(html);
                     var grosstotal=0;
                    $(".amount").each(function(){
                         grosstotal += parseFloat($(this).val()||0);
                    });
                  }
            });
        }
   
        function changeunitsp<?=$x;?>()
        {  
            var x = <?=$x; ?> ;
            var unitsp=document.getElementById("unitsp<?=$x;?>").value;
            var unitpricep=document.getElementById("unitpricep<?=$x;?>").value;
            var dataString = 'unitpricep='+ unitpricep+'&unitsp='+ unitsp+'&x='+ x;
            //alert(dataString);
            $.ajax({
                type: "POST",
                url: "getAmount.php",
                data: dataString,
                cache: false,
                success: function(html){
                    $('.rowpricep_ajax<?=$x;?>').html(html);
                    var grosstotal=0;
                    $(".amount").each(function(){
                         grosstotal += parseFloat($(this).val()||0);
                    });
                } 
            });
        }
          /*Material Management Purchases Close */
   
            /*Labour Management */
   
            function changeunitpricelm<?=$x;?>()
        {  
            var x = <?=$x; ?> ;
            var unitslm=document.getElementById("unitslm<?=$x;?>").value;
            var unitpricelm=document.getElementById("unitpricelm<?=$x;?>").value;
            var dataString = 'unitpricelm='+ unitpricelm+'&unitslm='+ unitslm+'&x='+ x;
            //alert(dataString);
            $.ajax({
                type: "POST",
                url: "Getamounts.php",
                data: dataString,
                cache: false,
                success: function(html){
                    $('.rowpricelm_ajax<?=$x;?>').html(html);
                     var grosstotal=0;
                    $(".amount").each(function(){
                         grosstotal += parseFloat($(this).val()||0);
                    });
                  }
            });
        }
   
        function changeunitslm<?=$x;?>()
        {  
            var x = <?=$x; ?> ;
            var unitslm=document.getElementById("unitslm<?=$x;?>").value;
            var unitpricelm=document.getElementById("unitpricelm<?=$x;?>").value;
            var dataString = 'unitpricelm='+ unitpricelm+'&unitslm='+ unitslm+'&x='+ x;
            //alert(dataString);
            $.ajax({
                type: "POST",
                url: "Getamounts.php",
                data: dataString,
                cache: false,
                success: function(html){
                    $('.rowpricelm_ajax<?=$x;?>').html(html);
                    var grosstotal=0;
                    $(".amount").each(function(){
                         grosstotal += parseFloat($(this).val()||0);
                    });
                } 
            });
        }
            /*labour management close*/
   
   <?php } ?>
</script>