<?php
session_start();
include ("../dbconfig.php");
extract($_REQUEST);
$aid = $user_id;
$proid= $project_id;
$sql="SELECT * FROM `projects_data` where project_id = '$proid'";
$result = $conn->query($sql);
if ($row = $result->fetch_object()) {
$prname =$row->project_title; }
echo '
<pre>';
print_r($_REQUEST);
echo '</pre>
';
$folder="users/$aid/projects/$prname/";
$upload_path = "$folder/images/";
$dcount = 0;
$valid_formats = array("jpg", "jpeg","JPG", "png","PNG","GIF","gif", "bmp","BMP");
$max_file_size = 1000000; //1mb
$qpic="";
$dimgname="";
$qpicp="";
$dimgnamep="";
$usageforwippic="";
$dimgnamewin="";
$imagepayee="";
$dimgnamepayee="";
$files="";
$dimgnameuplo="";
foreach ($_FILES['qpic']['name'] as $f => $name) 
{    
if ($_FILES['qpic']['error'][$f] == 4)
{
continue; // Skip file if any error found
}        
if ($_FILES['qpic']['error'][$f] == 0)
{            
if ($_FILES['qpic']['size'][$f] > $max_file_size) 
{
$message[] = "$name is too large!.";
continue; // Skip large files
}
elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) )
{
$message[] = "$name is not a valid format";
continue; // Skip invalid file formats
}
else
{ // No error found! Move uploaded files 
if(move_uploaded_file($_FILES["qpic"]["tmp_name"][$f], $upload_path.$name))
{
$dcount++; // Number of successfully uploaded files
$dimgname .= "$name,";
}
}
}
}
if( $dimgname!="")
{    
// Loop $_FILES to execute all files
$qpics = rtrim($dimgname,",");
echo $sql = "UPDATE `quotes_data` SET `quo_pic`='$qpics' WHERE `quo_id` = '$mmqu'";
$result = $conn->query($sql);
}
if(isset($mmqu))
{
$categoriesa = implode(",",$categories);
$itemnam = implode(",", $itemname);
$brands = implode(",", $brand);
$quantitys =implode(",",$units);
$unit_price = implode(",", $unitprice);
$amounts = implode(",",$rowprice);
$other = implode(",",$others);
$sql = "UPDATE `quotes_data` SET `project_id`='$proid',`quo_itemname`='$itemnam',`quo_category`='$categoriesa',`quo_brand`='$brands',`quo_qty`='$quantitys',`quo_rate`='$unit_price',`quo_amount`='$amounts',`quo_others`='$other',`quo_date`=now() WHERE `quo_id` = '$mmqu'";
$result = $conn->query($sql);
$quo_id = $conn->insert_id;
}
/* Material Purchase */
// Loop $_FILES to execute all files
foreach ($_FILES['qpicp']['name'] as $f => $name) 
{    
if ($_FILES['qpicp']['error'][$f] == 4)
{
continue; // Skip file if any error found
}        
if ($_FILES['qpicp']['error'][$f] == 0)
{            
if ($_FILES['qpicp']['size'][$f] > $max_file_size) 
{
$message[] = "$name is too large!.";
continue; // Skip large files
}
elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) )
{
$message[] = "$name is not a valid format";
continue; // Skip invalid file formats
}
else
{ // No error found! Move uploaded files 
if(move_uploaded_file($_FILES["qpicp"]["tmp_name"][$f], $upload_path.$name))
{
$dcount++; // Number of successfully uploaded files
$dimgnamep .= "$name,";
}
}
}
}
if( $dimgnamep!="")
{  
$qpicps = rtrim($dimgnamep,",");
echo $sql = "UPDATE `purchase_data` SET `pur_pic`='$qpicps',`pur_date`=now() WHERE `pur_id` = '$mmpu'";
$result = $conn->query($sql);
}
if(isset($mmpu))
{
$categoriesp = implode(",",$categoriesp);
$itemnameps = implode(",", $itemnamep);
$brandsp = implode(",", $brandp);
$quantityp =implode(",",$unitsp);
$unit_pricep = implode(",", $unitpricep);
$amountsp = implode(",",$rowpricep);
$others = implode(",",$othersp);
$sql = "UPDATE `purchase_data` SET `pur_qu_id`='$quo_id',`project_id`='$proid',`pur_itemname`='$itemnameps',`pur_category`='$categoriesp',`pur_brand`='$brandsp',`pur_qty`='$quantityp',`pur_rate`='$unit_pricep',`pur_amount`='$amountsp',`pur_others`='$others',`pur_status`=1,`pur_date`=now() WHERE `pur_id` = '$mmpu'";
$result = $conn->query($sql);
}
/* Close Material Purchase */
/* Material Usage */
if(isset($mmusage))
{
$qtyus = implode(",",$qtyu);
$itemusage = implode(",",$itemnameu);
$usagefors = implode(",", $usagefor);
$sql = "UPDATE `usage_data` SET `project_id`='$proid',`usage_item_name`='$itemusage',`usage_qty`='$qtyus',`usagefor`='$usagefors',`usage_date`=now() WHERE `usage_id` = '$mmusage'";
$result = $conn->query($sql);
}
/* Close Material Usage */
/* Labor Management */
if(isset($lmin))
{
$catlabours = implode(",",$catlabour);
$noworks = implode(",",$unitslm);
$phas = implode(",", $unitpricelm);
$toamts = implode(",", $rowpricelm);
$sql = "UPDATE `labor_data` SET `project_id`='$proid',`labor_category_labour`='$catlabours',`labor_noofworkers`='$noworks',`labor_perhead_amount`='$phas',`labor_total_amount`='$toamts',`labor_date`=now() WHERE `labor_id` = '$lmin'";
$result = $conn->query($sql);
}
/* Close Labor Management */ 
/* Work In House */
// Loop $_FILES to execute all files
foreach ($_FILES['usageforwippic']['name'] as $f => $name) 
{    
if ($_FILES['usageforwippic']['error'][$f] == 4)
{
continue; // Skip file if any error found
}        
if ($_FILES['usageforwippic']['error'][$f] == 0)
{            
if ($_FILES['usageforwippic']['size'][$f] > $max_file_size) 
{
$message[] = "$name is too large!.";
continue; // Skip large files
}
elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) )
{
$message[] = "$name is not a valid format";
continue; // Skip invalid file formats
}
else
{ // No error found! Move uploaded files 
if(move_uploaded_file($_FILES["usageforwippic"]["tmp_name"][$f], $upload_path.$name))
{
$dcount++; // Number of successfully uploaded files
$dimgnamewin .= "$name,";
}
}
}
}  
if( $dimgnamewin!="")
{  
$qpicpwin = rtrim($dimgnamewin,",");
echo $sql = "UPDATE `workinprogress_inhouse` SET `wipho_invpic`='$qpicpwin',`winpho_date`=now() WHERE `wiphouse_id` = '$wrkin'";
$result = $conn->query($sql);
}
if(isset($wrkin))
{
$usageforwips = implode(",",$usageforwip);
$sql = "UPDATE `workinprogress_inhouse` SET `project_id`='$proid',`wipho_usage`='$usageforwips',`winpho_date`=now() WHERE `wiphouse_id` = '$wrkin'";
$result = $conn->query($sql);
}
/* Close Work In House */
/* Payee Name */
// Loop $_FILES to execute all files
foreach ($_FILES['imagepayee']['name'] as $f => $name) 
{    
if ($_FILES['imagepayee']['error'][$f] == 4)
{
continue; // Skip file if any error found
}        
if ($_FILES['imagepayee']['error'][$f] == 0)
{            
if ($_FILES['imagepayee']['size'][$f] > $max_file_size) 
{
$message[] = "$name is too large!.";
continue; // Skip large files
}
elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) )
{
$message[] = "$name is not a valid format";
continue; // Skip invalid file formats
}
else
{ // No error found! Move uploaded files 
if(move_uploaded_file($_FILES["imagepayee"]["tmp_name"][$f], $upload_path.$name))
{
$dcount++; // Number of successfully uploaded files
$dimgnamepayee .= "$name,";
}
}
}
} 
if( $dimgnamepayee!="")
{   
$qpicppayee = rtrim($dimgnamepayee,",");
$sql = "UPDATE `payments_data` SET `payment_image`='$qpicppayee',`payment_date`='now()' WHERE `payment_id` = '$pmp'";
$result = $conn->query($sql);
}
if(isset($pmp))
{
$payeenamep = implode(",",$payeename);
$whtwrks = implode(",", $whtwrk);
$amtforpayees = implode(",", $amtforpayee);
$payeeremark = implode(",",$payeeremarks);
$sql = "UPDATE `payments_data` SET `project_id`='$proid',`payment_name`='$payeenamep',`payment_whatwork`='$whtwrks',`payment_amount`='$amtforpayees',`payment_remarks`='$payeeremark',`payment_status`='1',`payment_date`=now() WHERE `payment_id` = '$pmp'";
$result = $conn->query($sql);
}
/* Close Payee Name */
/* Other Information */
if(isset($oino))
{
$otherInformations = implode("," ,$otherInformation); 
echo $sql = "UPDATE `other_information` SET `project_id`='$proid',`other_infor_notes`='$otherInformations',`other_information_date`=now() WHERE `other_infor_id`='$oino'";
$result = $conn->query($sql);
}
/* Close Other Information */
/* Multiple Images */
// Loop $_FILES to execute all files
foreach ($_FILES['files']['name'] as $f => $name) 
{    
if ($_FILES['files']['error'][$f] == 4)
{
continue; // Skip file if any error found
}        
if ($_FILES['files']['error'][$f] == 0)
{            
if ($_FILES['files']['size'][$f] > $max_file_size) 
{
$message[] = "$name is too large!.";
continue; // Skip large files
}
elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) )
{
$message[] = "$name is not a valid format";
continue; // Skip invalid file formats
}
else
{ // No error found! Move uploaded files 
if(move_uploaded_file($_FILES["files"]["tmp_name"][$f], $upload_path.$name))
{
$dcount++; // Number of successfully uploaded files
$dimgnameuplo .= "$name,";
}
}
}
}
if( $dimgnameuplo!="")
{     
if(isset($uplpo))
{
$qpicpuplo = rtrim($dimgnameuplo,",");
echo $sql = "UPDATE `upload_photos` SET `project_id`='$proid',`upload_images`='$qpicpuplo',`upload_date`=now() WHERE `upload_id`=$uplpo";
$result = $conn->query($sql);
}
}
/* Close Multiple Images */
echo $conn->error;
if($result == TRUE){
//echo "<script>window.location.assign('view-dailyreport.php?proid=".$proid."');</script>";
}
else{
//echo "<script>window.location.assign('view-dailyreport.php?proid=$proid&&fail=fail');</script>";
}