 <script type="text/javascript">
            $(window).on('load',function(){
            $('#signup-modal').modal('show');
            });
        </script>

        <script type="text/javascript">

        
        $("#mp").click(function(e) {
          $("#myprojects").show();
          $("#addnewprojects").hide();
          $(this).hide();
          $("#anp").show();

        });

        $("#addnewprojects").hide();
        $("#anp").click(function(e) {
          $("#addnewprojects").show();
          $("#myprojects").hide();
          $(this).hide();
          $("#mp").show();

        });
</script>
<!-- Custom Modals -->
                        <!-- Signup modal content -->
                        <div id="signup-modal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="custom-width-modalLabel"  aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>

                                                <div class="modal-body">
                                                    <h2 class="text-uppercase text-center m-b-30">
                                                        <a href="#" class="text-success">
                                                            <span>All Projects</span>
                                                        </a>
                                                    </h2>
                                                    
                                                      &nbsp;&nbsp; <a href="#" id="mp"> <i class="mdi mdi-account md-18"></i> My Projects</a>
                                                      &nbsp;&nbsp; <a href="#" id="anp"> <i class="mdi mdi-plus md-18"></i> Add New Project </a>
                                                        <br>
                                                        <br>
                                                        <br>
                                                        <div class="form-group m-b-25">
                                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                                <a href="#" id="mp"> 
                                                                    <i class="mdi mdi-account md-18"></i> Project Name 
                                                                    <i class="mdi mdi-map-marker"></i>Location of Project 
                                                                </a>

                                                            </div>
                                                        </div>

                                           

                                                    <form class="form-horizontal" action="#" id="addnewprojects">
                                                        <div class="form-group m-b-25">
                                                            <div class="col-xs-12">
                                                                <label for="username">Project Name : </label>
                                                                <input class="form-control" type="text" id="pname" required="">
                                                            </div>
                                                        </div>

                                                        <div class="form-group m-b-25">
                                                            <div class="col-xs-12">
                                                                <label for="password">Project Location </label>
                                                                <input class="form-control" type="text" required="" id="plocation">
                                                            </div>
                                                        </div>

                                                         <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="field-4" class="control-label">Area</label>
                                                                <input type="text" class="form-control" id="field-4" placeholder="Boston">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="field-5" class="control-label">Dimensions</label>
                                                               <select class="selectpicker" data-style="btn-secondary btn-rounded">
                                                                    <option value="SquareFeet">Square Feet </option>
                                                                    <option value="SquareMeter">Square Meter</option>
                                                                    <option value="SquareInch">Square Inch</option>
                                                                    <option value="SquareYard">Square Yard</option>
                                                                    <option value="Acre">Acre</option>
                                                                    <option value="SquareCentimeter">Square Centimeter</option>
                                                                    <option value="Other">Other</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>

                                                        <div class="form-group m-b-25">
                                                            <div class="col-xs-12 col-sm-6 col-md-6">
                                                                <label for="password">Stage Of Project : </label>
                                                                 <select class="selectpicker" data-style="btn-secondary btn-rounded">
                                                                    <option value="Yettostart">Yet to start</option><option value="Structure">Structure</option><option value="Plastering">Plastering</option><option value="Flooring">Flooring</option><option value="Finishing">Finishing</option><option value="Interiors">Interiors</option><option value="Other">Other</option>
                                                                </select>
                                                            </div>
                                                        </div>

                                                        <div class="form-group m-b-25">
                                                            <div class="col-xs-12">
                                                                <label for="password">Site Image : </label>
                                                               <div class="bootstrap-filestyle input-group"><span class="group-span-filestyle " tabindex="0"><label for="filestyle-1" class="btn btn-secondary "><span class="icon-span-filestyle glyphicon glyphicon-folder-open"></span> <span class="buttonText">Choose file</span></label></span></div>
                                                            </div>
                                                        </div>

                                                        <div class="form-group account-btn text-center m-t-10">
                                                            <div class="col-xs-12">
                                                                <button class="btn w-lg btn-rounded btn-lg btn-primary waves-effect waves-light" type="submit">Submit</button>
                                                            </div>
                                                        </div>

                                                    </form>
                                                </div>
                                            </div><!-- /.modal-content -->
                                        </div><!-- /.modal-dialog -->
                            </div><!-- /.modal -->

                             Purchases on <?php 
                                                                            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
                                                                            echo $insertdate = $date->format('d-m-Y H:i:s a'); ?></b> 







                                                                            <table class="table table-hover small-text" id="tb">
                        <tr class="tr-header">
                           <th class="hard_left">Category</th>
                           <th class="pm"> Product Name </th>
                           <th> Qty </th>
                           <th> Brand </th>
                           <th> Unit Price </th>
                           <th> Amount </th>
                           <th> Remarks </th>
                        </tr>
                        <tr>
                           <td class="hard_left select">
                              <input type="text" id="product_name<?=$y;?>" name="category[]" value="Category Name" class="form-control" >
                           </td>
                           <td>
                              <div class="frmSearch">
                                 <input list="search-list<?=$y;?>" id="search-box<?=$y;?>" placeholder="Product Name" class="form-control search-box<?=$y;?>" name="productname[]"/>
                                 <datalist id="search-list<?=$y;?>"></datalist>
                              </div>
                           </td>
                           <td>
                              <input type="number" class="form-control quantity" id="quantity<?=$y;?>" name="quantity" value ="1">
                           </td>
                           <td>
                              <input list="branda-list<?=$y;?>" name="branda[]" id="branda<?=$y;?>" placeholder="brand1" class="form-control branda<?=$y;?>">
                              <datalist id="branda-list<?=$y;?>"></datalist>
                           </td>
                           <td>
                              <input type="number" id="unit_pricea<?=$y;?>" name="unit_pricea[]" class="form-control unit_pricea<?=$y;?>">
                           </td>
                           <td>
                              <input type="text" id="amounta<?=$y;?>" name="amounta[]" class="form-control amounta" readonly>
                           </td>
                           <td>
                            <input type="text" name="brandb[]" id="brandb<?=$y;?>" placeholder="brand2" class="form-control brandb<?=$y;?>">
                              
                           </td>
                        </tr>
                     </table>
               </div>
            </div>
            <div class="col-md-5 col-sm-5 col-xs-5">
            Total Project Cost : 
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
            @ Brand1 <input type='text' id="amount4" class="form-control" name="Brand1"  readonly/>
            <br>
            <button type="submit" formaction="material-quote.php" name="quote1" class="btn btn-success btn-sm pull-left">Quote</button>
            <button type="submit" formaction="material-invoice.php" name="buynow1" class="btn btn-primary btn-sm pull-right">Buy Now</button>


            <div class="row">
            <div class="col-12">
               <div class="card-box">
                  <div class="row">
                     <div class="col-12">
                        <h4 class=" m-t-0 header-title">Project Images</h4>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-12 ">
                        <p class="text-muted m-b-30 font-13">Add captions to your Images easily. </p>
                        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                           <ol class="carousel-indicators">
                              <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                              <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                              <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
                           </ol>

                            

                           <div class="carousel-inner" role="listbox">
                              <div class="carousel-item active">
                              <?php 
                                 foreach($img as $image)
                                 {
                                 echo '<img src="'.$realPath.'/'.$image.'" height="310" width="215" alt="Slider Images">';
                                 } ?>
                              <!-- 

                                 <?php for($i = 0; $i < sizeof($img); $i++) { ?>
                                 <img class="d-block img-fluid" src="<?=$realPath;?>/<?=$img[$i];?>" alt="First slide" />
                                <?php }  ?>
                                 <div class="carousel-caption d-none d-md-block">
                                    <h3 class="text-white">First slide label</h3>
                                    <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                                 </div>
                              </div> -->
                           </div>
                           <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                           <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                           <span class="sr-only">Previous</span>
                           </a>
                           <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                           <span class="carousel-control-next-icon" aria-hidden="true"></span>
                           <span class="sr-only">Next</span>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- Col-12-Close-->
         </div>
         <!-- end row -->
         </div>