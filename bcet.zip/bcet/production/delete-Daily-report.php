<?php include 'headerpage.php';?>
<?php include 'leftside.php';?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">Starter Page</h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Adminox</a></li>
                     <li class="breadcrumb-item"><a href="#">Pages</a></li>
                     <li class="breadcrumb-item active">Starter Page</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div><!-- end row -->

         <!-- Main Contetbt Start-->
         <div class="row">
            <div class="col-lg-12">
               <div class="card-box">





               </div><!--Card-box-->
            </div><!--col-lg-12-->
         </div><!-- Main Content Row Close -->
      </div><!-- container -->
   </div><!-- content -->
</div><!--content Page-->
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>