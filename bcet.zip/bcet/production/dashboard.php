<?php include 'headerpage.php';
if(isset($proid))
{  include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>
<!-- C3 charts css -->
<link href="plugins/c3/c3.min.css" rel="stylesheet" type="text/css"  />
<!-- Sweet Alert -->
<link href="plugins/sweet-alert2/sweetalert2.min.css" rel="stylesheet" type="text/css">
<!-- Slick Slider css -->
<link href="plugins/slick-slider/slick.css" rel="stylesheet" />
<link href="plugins/slick-slider/slick-theme.css" rel="stylesheet" />

<!-- DataTables -->
<link href="plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<!-- Responsive datatable examples -->
<link href="plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">Dashboard</h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Adminox</a></li>
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                     <li class="breadcrumb-item active">Dashboard 1</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->
         <?php $sql="SELECT * FROM `projects_data` where project_id ='$proid' ";
            $result = $conn->query($sql); 
            while ($row = $result->fetch_object()) {
                            $projid =$row->project_id; 
                            $protitle = $row->project_title;
                            $proloca =$row->project_location;
                            $prostart = $row->project_start_date;
                            $proend = $row->project_end_date;
                            $proara = $row->project_area;
                            $prodimen= $row->project_dimensions;
                            $proothers= $row->project_others;
                            $prstages = $row->project_stage;
                            $primages = $row->project_images;
                            $img = explode(",", $primages);
                            $realPath = 'users/'.$aid.'/projects/'.$protitle;
                  } ?>
         <!-- Project Name -->
         <div class="row">
            <div class="col-lg-6 col-md-6">
               <div class="card-box widget-box-two widget-two-custom">
                  <div class="wigdet-two-content">
                     <p class="m-0 text-uppercase font-bold font-secondary text-overflow" title="Statistics"> Project Name  </p>
                     <h2 class="font-600"> <?=$protitle;?>  </h2>
                     <div class="progress m-b-20">
                        <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 10%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"><i class="fa fa inr">0</i></div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- end col -->
            <!-- Project Details -->
            <div class="col-lg-6 col-md-6">
               <div class="card-box widget-box-two widget-two-custom">
                  <div class="wigdet-two-content">
                     <p class="m-0 text-uppercase font-bold font-secondary text-overflow" title="Statistics">Project Location </p>
                     <h2 class="font-600"> <?=$proloca;?> </h2>
                  </div>
               </div>
            </div>
            <!-- end col -->
         </div>
         <!-- end row -->
         <!-- Image Scrolling-->
         <div class="row">
            <div class="col-12">
               <div class="card-box">
                  <h4 class="header-title m-t-0 m-b-15">Project Images Scrolling</h4>
                  <div class="single-item slider ">
                     <?php 
                        foreach($img as $image)
                        { ?>
                        <img src="<?=$realPath;?>/<?=$image;?>" style="height:800px;width:800px !important" alt="Slider Images" class="img-fluid" />
                       <?php } ?>
                  </div>
               </div>
            </div>
            <!-- end col -->
         </div>
         <!-- end row -->
         

        <!-- Material Estimation Chat-->
         <div class="row">
            <div class="col-sm-12 col-xs-12">
               <div class="card-box">
                  <h4 class="header-title m-t-0">Material Estimation</h4>
                  <div class="text-center">
                     <?php $sql1 = "SELECT * FROM `estimation_data` WHERE est_project_id = '$proid'";
                           $result1 = $conn->query($sql1); 
                           if ($row1 = $result1->fetch_object()) { 
                           echo $estimation = $row1->est_amount; } ?> 
                     <div class="row">
                        <div class="col-4">
                           <div class="m-t-20 m-b-20">
                              <h4 class="m-b-10"></h4>
                              <p class="text-uppercase m-b-5 font-13 font-600"> Total Cost Of Project </p>
                           
                           </div>
                        </div>
                        <div class="col-4">
                           <div class="m-t-20 m-b-20">
                              <h4 class="m-b-10"></h4>
                              <p class="text-uppercase m-b-5 font-13 font-600">Outgoing Amounts</p>
                              
                           </div>
                        </div>
                        <div class="col-4">
                           <div class="m-t-20 m-b-20">
                              <h4 class="m-b-10"></h4>
                              <p class="text-uppercase m-b-5 font-13 font-600">Total Balance</p>
                              
                           </div>
                        </div>
                     </div>
                   
                  </div>
                  <!--close text center-->
                  <div id="pie-chart"></div>
               </div>
               <!--Card Box-->
            </div>
            <!--col-sm-12-->
         </div>
         <!--Materila Estimation Chart Close-->
         <!-- Daily Reports-->
         <div class="row">
            <div class="col-sm-12 col-xs-12">
               <div class="card-box">
                  <h4 class="m-t-0 header-title"><b>Daily Reports</b></h4>
                  <div class="table-responsive">
                     <table class="table table-hover m-0 table-actions-bar">
                        <thead>
                           <tr>
                              <th>Material</th>
                              <th>Labor</th>
                              <th>Work In Progress</th>
                              <th>Other Remarks</th>
                              <th>Action</th>
                           </tr>
                        </thead>
                        <tbody>
                           <tr>
                              <td>
                                 <h5 class="m-b-0 m-t-0 font-600">Cement</h5>
                              </td>
                              <td>
                                 <i class="mdi mdi-map-marker text-primary"></i> 15
                              </td>
                              <td>
                                 <i class="mdi mdi-clock text-success"></i> Full Time
                              </td>
                              <td>
                                 <i class="mdi mdi-currency-usd text-warning"></i> Nothing
                              </td>
                              <td>
                                 <a href="#" class="table-action-btn"><i class="mdi mdi-pencil"></i></a>
                                 <a href="#" class="table-action-btn"><i class="mdi mdi-close"></i></a>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                     <!-- Close the Table -->
                  </div>
               </div>
            </div>
         </div>
         <!-- End Daily Reports-->
         <!--To Do List Page-->
         <div class="row">
            <div class="col-sm-12 col-xs-12">
               <div class="card-box">
                  <h4 class="m-t-0 header-title"><b>To Do Things</b></h4>
                  <p class="text-muted font-14 m-b-20">
                     Your awesome text goes here.
                  </p>
                  <ul class="nav nav-tabs">
                     <li class="nav-item">
                        <a href="#due" data-toggle="tab" aria-expanded="true" class="nav-link active">
                        Due
                        </a>
                     </li>
                     <li class="nav-item">
                        <a href="#completed" data-toggle="tab" aria-expanded="false" class="nav-link">
                        Completed
                        </a>
                     </li>
                     <li class="nav-item">
                        <a href="#canceled" data-toggle="tab" aria-expanded="false" class="nav-link">
                        Canceled
                        </a>
                     </li>
                  </ul>
                  <div class="tab-content">
                     <div class="tab-pane fade show active" id="due">
                        <!-- Inline Form -->
                        <div class="table-responsive">
                           <table id="datatable" class="table table-bordered">
                              <thead>
                                 <tr>
                                    <th>Sl.No</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Subject</th>
                                    <th>Description</th>
                                    <th>Due Date</th>
                                    <th>Due Time</th>
                                 </tr>
                              </thead>

                              <?php $sql="SELECT * FROM `todolist_data` where project_id = '$proid' and todo_status = 0 ";
                                 $result = $conn->query($sql);
                                 $count=$result->num_rows;
                                 if ($count > 0) {
                                 $x=1;
                              while ($row = $result->fetch_object()) {
                                     $toid =$row->todo_id; ?>

                              <tbody>
                                 <tr>
                                    <td>
                                       <h5 class="m-b-0 m-t-0 font-600"><?=$x;?></h5>
                                    </td>
                                    <td>
                                       <h5 class="m-b-0 m-t-0 font-600"> <?=$row->todo_date;?></h5>
                                    </td>
                                    <td>
                                       <h5 class="m-b-0 m-t-0 font-600"><?=$row->todo_time;?> </h5>
                                    </td>
                                    <td>
                                       <i class="mdi mdi-map-marker text-primary"></i> <?=$row->todo_subject;?>
                                    </td>
                                    <td>
                                       <?=$row->todo_description;?>
                                    </td>
                                    <td>
                                      <h5 class="m-b-0 m-t-0 font-600"> <?=$row->due_todo_date;?></h5>
                                    </td>
                                     <td>
                                      <h5 class="m-b-0 m-t-0 font-600"> <?=$row->due_todo_time;?></h5>
                                    </td>
                                    
                                 </tr>
                                 <?php $x++;  }  } else { echo 'No Data Found'; }  ?>
                              </tbody>
                           </table>
                           <!-- Close the Table -->
                        </div>
                        <!-- end row / End Inline form-->  
                     </div>
                     <!--winhouse close-->
                     <div class="tab-pane fade" id="completed">
                        <!-- Inline Form -->
                        <div class="table-responsive">
                           <table id="datatable1" class="table table-bordered">
                              <thead>
                                 <tr>
                                    <th>Sl.No</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Subject</th>
                                    <th>Description</th>
                                    <th>Due Date</th>
                                    <th>Due Time</th>
                                 </tr>
                              </thead>
                              
                              <tbody>
                                 <?php  $sql="SELECT * FROM `todolist_data` where project_id = '$proid' and todo_status = 1 ";
                                 $result = $conn->query($sql);
                                  $count=$result->num_rows;
                                 if ($count > 0) {
                                 $x=1;
                              while ($row = $result->fetch_object()) {
                                     $toid =$row->todo_id; ?>
                                 <tr>
                                    <td>
                                       <h5 class="m-b-0 m-t-0 font-600"><?=$x;?></h5>
                                    </td>
                                    <td>
                                       <h5 class="m-b-0 m-t-0 font-600"> <?=$row->todo_date;?></h5>
                                    </td>
                                    <td>
                                       <h5 class="m-b-0 m-t-0 font-600"><?=$row->todo_time;?> </h5>
                                    </td>
                                    <td>
                                       <i class="mdi mdi-map-marker text-primary"></i> <?=$row->todo_subject;?>
                                    </td>
                                    <td>
                                       <?=$row->todo_description;?>
                                    </td>
                                    <td>
                                      <h5 class="m-b-0 m-t-0 font-600"> <?=$row->due_todo_date;?></h5>
                                    </td>
                                     <td>
                                      <h5 class="m-b-0 m-t-0 font-600"> <?=$row->due_todo_time;?></h5>
                                    </td>
                                    
                                 </tr>
                                 <?php $x++;  }  } else { echo 'No Data Found' ; }  ?>
                              </tbody>
                           </table>
                           <!-- Close the Table -->
                        </div>
                        <!-- end row / End Inline form-->
                     </div>
                     <!--wsubconant-->
                     <div class="tab-pane fade" id="canceled">
                        <!-- Inline Form -->
                        <div class="table-responsive">
                           <table id="datatable2" class="table table-bordered">
                              <thead>
                                 <tr>
                                    <th>Sl.No</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Subject</th>
                                    <th>Description</th>
                                    <th>Due Date</th>
                                    <th>Due Time</th>
                                 </tr>
                              </thead>
                             <?php $sql="SELECT * FROM `todolist_data` where project_id = '$proid' and todo_status = 2 ";
                                 $result = $conn->query($sql);
                                 $count=$result->num_rows;
                                 if ($count > 0) {
                                 $x=1;
                              while ($row = $result->fetch_object()) {
                                     $toid =$row->todo_id; ?>

                              <tbody>
                                 <tr>
                                    <td>
                                       <h5 class="m-b-0 m-t-0 font-600"><?=$x;?></h5>
                                    </td>
                                    <td>
                                       <h5 class="m-b-0 m-t-0 font-600"> <?=$row->todo_date;?></h5>
                                    </td>
                                    <td>
                                       <h5 class="m-b-0 m-t-0 font-600"><?=$row->todo_time;?> </h5>
                                    </td>
                                    <td>
                                       <i class="mdi mdi-map-marker text-primary"></i> <?=$row->todo_subject;?>
                                    </td>
                                    <td>
                                       <?=$row->todo_description;?>
                                    </td>
                                    <td>
                                      <h5 class="m-b-0 m-t-0 font-600"> <?=$row->due_todo_date;?></h5>
                                    </td>
                                     <td>
                                      <h5 class="m-b-0 m-t-0 font-600"> <?=$row->due_todo_time;?></h5>
                                    </td>
                                    
                                 </tr>
                                 <?php $x++;  }  }  else { echo 'No Data Found' ; } ?>
                              </tbody>
                           </table>
                           <!-- Close the Table -->
                        </div>
                        <!-- end row / End Inline form-->
                     </div>
                  </div>
                  <!--tab content-->
                  <!-- <div class="table-responsive">
                     <table class="table table-hover m-0 table-actions-bar">
                        <thead>
                           <tr>
                              <th>Sl.No</th>
                              <th>Date</th>
                              <th>Time</th>
                              <th>Subject</th>
                              <th>Description</th>
                              <th>Due Date</th>
                              <th>Action</th>
                           </tr>
                        </thead>
                        <tbody>
                           <tr>
                              <td>
                                 <h5 class="m-b-0 m-t-0 font-600">1</h5>
                                 
                              </td>
                              <td>
                                 <h5 class="m-b-0 m-t-0 font-600">Today Date</h5>
                                 
                              </td>
                              <td>
                                 <h5 class="m-b-0 m-t-0 font-600">Time </h5>
                                 
                              </td>
                              <td>
                                 <i class="mdi mdi-map-marker text-primary"></i> TO Meet Mr.Mark
                              </td>
                              <td>
                                 <i class="mdi mdi-clock text-success"></i> 8.30 Am
                              </td>
                              <td>
                                 <i class="mdi mdi-currency-usd text-warning"></i> Due Date
                              </td>
                              <td>
                                 <a href="#" class="table-action-btn"><i class="mdi mdi-pencil"></i></a>
                                 <a href="#" class="table-action-btn"><i class="mdi mdi-close"></i></a>
                              </td>
                           </tr>
                          
                        </tbody>
                     </table> Close the Table 
                     </div> -->
               </div>
            </div>
         </div>
         <!-- To do Row Close-->
      </div>
      <!--- end row -->
   </div>
   <!-- container -->
</div>
<!-- content -->
</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
<!--C3 Chart-->
<script type="text/javascript" src="plugins/d3/d3.min.js"></script>
<script type="text/javascript" src="plugins/c3/c3.min.js"></script>
<script src="assets/pages/jquery.c3-chart.init.js"></script>
<script src="assets/js/jquery.slimscroll.js"></script>
<!-- Slick Slider js -->
<script src="plugins/slick-slider/slick.min.js" type="text/javascript"></script>
<script src="assets/pages/jquery.slider.init.js"></script>
<!--datatables-->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Responsive examples -->
<script src="plugins/datatables/dataTables.responsive.min.js"></script>
<script src="plugins/datatables/responsive.bootstrap4.min.js"></script>
<script type="text/javascript">
   $(document).ready(function() {
       $('#datatable').DataTable();
   } );

   $(document).ready(function() {
       $('#datatable1').DataTable();
   } );

   $(document).ready(function() {
       $('#datatable2').DataTable();
   } );
</script>