<?PHP
    extract($_REQUEST);
    include('../dbconfig.php');
    $tot=0;
    $tot=$unitsp*$unitpricep;
?>
<div class="9">
<input type='number' class='form-control rowpricep<?=$x;?>amount' id='rowpricep<?=$x; ?>' name='rowpricep[]' value='<?php echo $tot; ?>' readonly></div>