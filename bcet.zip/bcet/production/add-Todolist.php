<?php
session_start();
include("../dbconfig.php");
$aid= $_SESSION["aid"];
$proid = $_SESSION["proid"];
extract($_REQUEST);

if(isset($addtodo))
{

 $sql = "INSERT INTO `todolist_data`(`todo_id`, `project_id`, `todo_date`, `todo_time`, `due_todo_date`, `due_todo_time`, `todo_subject`, `todo_description`,`todo_status`) VALUES (NULL,'$proid', '$date', '$time','$datedue','$duetime','$subject','$tododescription',0)";
$result = $conn->query($sql);
echo $conn->error;
if($result === TRUE){
echo "<script>window.location.assign('to-do-list.php?proid=$proid&&added=success');</script>";
}
else{
	echo "<script>window.location.assign('to-do-list.php?proid=$proid&&failure=fail');</script>";
}
}


if(isset($edittodo))
{
$sqle = "UPDATE `todolist_data` SET `project_id`='$proid',`todo_date`= '$todate',`todo_time`='$totime',`due_todo_date`='$duedateedit',`due_todo_time`='$editduetime',`todo_subject`='$editsubject',`todo_description`='$editdescription',`todo_status`='$dostatus' WHERE `todo_id` = '$eid'";
$resulte = $conn->query($sqle);
echo $conn->error;
if($resulte === TRUE){
echo "<script>window.location.assign('view-todo.php?proid=$proid&&update=success');</script>";
}
else{
	echo "<script>window.location.assign('view-todo.php?proid=$proid&&upfail=fail');</script>";
}
}


if (isset($del))
    {
     $queryde = "DELETE FROM `todolist_data` where todo_id='$del'";
     $conn->query($queryde);

    if ($conn->query($queryde) === TRUE)
    {   
        echo "<script>window.location.assign('view-todo.php?proid=$proid&&deleted=sucess')</script>";
    }
    else
    {
    echo "<script>window.location.assign('view-todo.php?proid=$proid&&delete=error')</script>";
    }
}


if(isset($status))
{
    if($status == 1)
    {
       $sql ="UPDATE `users` SET `status` = 0 WHERE `user_id` = $sid" or die(mysqli_error());
       if ($conn->query($sql) === TRUE) 
       {
           echo "<script>window.location.assign('view-todo.php?proid=$proid&&deact=sucess')</script>";
       }
       else 
       {
          echo "<script>window.location.assign('view-todo.php?proid=$proid&&err=error')</script>";
                    //echo "Error: " . $sql . "<br>" . $con->error;
       }
    }
    else
    {
        $sql ="UPDATE `users` SET `status` = 1 WHERE `user_id` = $sid" or die(mysqli_error());
        if ($conn->query($sql) === TRUE) 
        {
           echo "<script>window.location.assign('view-todo.php?act=sucess')</script>";
        }
        else
        {        
          echo "<script>window.location.assign('view-todo.php?err=error')</script>";
           // echo "Error: " . $sql . "<br>" . $con->error;
        }
    }
}