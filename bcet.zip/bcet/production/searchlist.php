<?php
require_once("../dbconfig.php");
$db_handle = new DBController();
if(!empty($_POST["keyword"])) {
$query ="SELECT * FROM tbl_products WHERE product_name like '" . $_POST["keyword"] . "%' ORDER BY product_name LIMIT 0,6";
$result = $db_handle->runQuery($query);
if(!empty($result)) {
?>
<ul id="country-list">
<?php
foreach($result as $country) {
?>
<option value="<?php echo $country["product_name"]; ?>"><?php echo $country["product_name"]; ?></option>
<?php } ?>
</ul>
<?php } } ?>
<?php 

	if(isset($_POST['amount'])) {
		 $query ="SELECT * FROM tbl_products WHERE product_name = '" . $_POST["amount"] . "'";
        $result = $db_handle->runQuery($query);
        $output;
        foreach ($result as $value) {
        	# code...
        	$output = $value['discount_price'];  
        }
        echo $output; 
        } ?>
