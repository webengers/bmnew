<?php include 'headerpage.php'; ?> 
<?php if($_SESSION["proid"] == '$proid')
{ ?>
<?php include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } {
  # code...
} ?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">Dashboard</h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Adminox</a></li>
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                     <li class="breadcrumb-item active">Dashboard 1</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div><!-- end row -->
         
        <div id="signup-modal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="custom-width-modalLabel"  aria-hidden="true" style="display: none;">
            <div class="modal-dialog">
              <div class="modal-content">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                      <div class="modal-body">
                          <h2 class="text-center m-b-30">
                               <span>Please Select Your Projects  </span>
                                 <?php
                                    require_once("../dbconfig.php");
                                    extract($_REQUEST);
                                    $sql="SELECT * FROM `projects_data` where customer_id = $aid ";
                                    $result = $conn->query($sql);
                                    $count=$result->num_rows;
                                    if ($count > 0) {
                                    while ($row = $result->fetch_object()) {
                                           $proid =$row->project_id; 
                                          $prname= $row->project_title;
                                          $_SESSION["proid"] = $proid; ?>
                              <p><a href="dashboard.php?proid=<?=$proid;?>" class="text-success"><?=$prname;?> </a></p>
                            <?php } } ?>
                          </h2>
                      </div><!--modal-body-->
              </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!--model-signup-->
      </div><!--- end row -->
   </div><!-- container -->
</div><!-- content -->
</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
 <script type="text/javascript">
            $(window).on('load',function(){
            $('#signup-modal').modal('show');
            });
        </script>