<?php include 'headerpage.php';
if(isset($proid))
{  include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>
<link href="plugins/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
<link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">
<link href="plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" />
<link href="plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">Stock Details <b><?=$proid;?></b></h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                  
                     <li class="breadcrumb-item active">Stock</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->
         <!-- Main Contetbt Start-->
         <div class="row">
            <div class="col-sm-12">
               <div class="card-box">
                  <div class="row">
                     <div class="col-sm-8">
                        <div class="form-group">
                           <label>Date Range</label>
                           <div>
                              <div class="input-daterange input-group" id="date-range">
                                 <input type="text" class="form-control" name="start" />
                                 <span class="input-group-addon bg-custom text-white b-0">to</span>
                                 <input type="text" class="form-control" name="end" />
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="form-group">
                           <label>Categories</label>
                           <select class="selectpicker" data-style="btn-secondary btn-rounded">
                              <option>Mustard</option>
                              <option>Ketchup</option>
                              <option>Relish</option>
                           </select>
                        </div>
                        <!-- form group-->
                     </div>
                     <!--col-sm-4-->
                  </div>
                  <div class="row">
                     <div class="col-sm-12">
                        <div class="card-box">
                           <h4 class="m-t-0 header-title">Stock</h4>
                           <table class="table table-bordered">
                              <thead>
                                 <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Category Name</th>
                                    <th>Purchase</th>
                                    <th>Issues</th>
                                    <th>Closing</th>
                                    <th>Remarks</th>
                                 </tr>
                              </thead>
                              <tbody>
                                 <tr>
                                    <th scope="row">1</th>
                                    <td>Date format</td>
                                    <td>Steel</td>
                                    <td>25</td>
                                    <td>12</td>
                                    <td>13</td>
                                    <td>for wall</td>
                                 </tr>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
                  <!-- end row -->
               </div>
               <!-- row close-->
            </div>
            <!--Card-box-->
         </div>
         <!--col-lg-12-->
      </div>
      <!-- Main Content Row Close -->
   </div>
   <!-- container -->
</div>
<!-- content -->
</div><!--content Page-->
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
<!-- plugin js -->
<script src="plugins/moment/moment.js"></script>
<script src="plugins/timepicker/bootstrap-timepicker.js"></script>
<script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="plugins/clockpicker/js/bootstrap-clockpicker.min.js"></script>
<script src="plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="plugins/select2/js/select2.min.js" type="text/javascript"></script>
<script src="plugins/bootstrap-select/js/bootstrap-select.js" type="text/javascript"></script>
<!-- Init js -->
<script src="assets/pages/jquery.form-pickers.init.js"></script>