<?php include 'headerpage.php';
if(isset($proid))
{  include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>

<!-- Project Name -->
<?php $pr_sql = $conn->query("SELECT * FROM `projects_data` where project_id ='$proid' ");
if($pr_row = $pr_sql->fetch_object()){ $prname = $pr_row->project_title;  } ?>
<!-- Plugins css -->
<link href="plugins/timepicker/bootstrap-timepicker.min.css" rel="stylesheet">
<link href="plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">
<link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">
<link href="plugins/clockpicker/css/bootstrap-clockpicker.min.css" rel="stylesheet">
<link href="plugins/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
<link href="plugins/custombox/css/custombox.min.css" rel="stylesheet">
      <!-- Plugins css-->
      <link href="plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" />
      <link href="plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
      <link rel="stylesheet" href="plugins/switchery/switchery.min.css">

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
   <!-- Start content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box">
                  <h4 class="page-title float-left">EDIT To Do Page <?=$prname;?> </h4>
                  <ol class="breadcrumb float-right">
                     <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                     <li class="breadcrumb-item active">To Do List Edit Page</li>
                  </ol>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
         <!-- end row -->
         <?php
            if(isset($added)){ ?>
         <div class="alert alert-success alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            To-do Details Updated Successfully.
         </div>
         <?php }
            ?>
         <?php
            if(isset($failure)){ ?>
         <div class="alert alert-danger alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            To-do Details  not Updated yet please try again later.
         </div>
         <?php }
            ?>
         <?php $sql="SELECT * FROM `todolist_data` where todo_id ='$todoid' ";
               $result = $conn->query($sql); 
               while ($row = $result->fetch_object()) {
                               $toid =$row->todo_id; 
                               $todate = $row->todo_date;
                               $totime =$row->todo_time;
                               $tosub = $row->todo_subject;
                               $todes = $row->todo_description;
                               $duedate = $row->due_todo_date;
                               $duetime= $row->due_todo_time;
                               $todostaus = $row->todo_status; } ?>


         <!-- Main Contetbt Start-->
         <div class="row">
            <div class="col-sm-12">
               <div class="card-box">
                  <form class="form-horizontal" action="add-Todolist.php" id="todolist" method="post">
                     <input type="hidden" name="edittodo">
                     <input type="hidden" name="eid" value="<?=$toid;?>">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">
                              <label>Date</label>
                              <div>
                                 <div class="input-group">
                                    <input type="text" name="todate" value="<?=$todate;?>" class="form-control" placeholder="dd/mm/yyyy" id="datepicker-autoclose">
                                    <span class="input-group-addon bg-custom b-0"><i class="mdi mdi-calendar text-white"></i></span>
                                 </div>
                                 <!-- input-group -->
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <label>Time</label>
                              <div>
                                 <div class="input-group">
                                    <input id="timepicker" name="totime" value="<?=$totime;?>" type="text" class="form-control">
                                    <span class="input-group-addon"><i class="mdi mdi-clock"></i></span>
                                 </div>
                                 <!-- input-group -->
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">
                              <label for="field-5" class="control-label">Subject</label>
                              <input type="text" name="editsubject" value="<?=$tosub;?>" class="form-control" id="field-4" placeholder="Name Of Content">
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <label>Description</label>
                              <textarea id="textarea" class="form-control" name="editdescription" maxlength="225" rows="3" placeholder="This textarea has a limit of 225 chars."><?=$todes;?></textarea>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-4">
                           <div class="form-group">
                              <label>Due Date</label>
                              <div>
                                 <div class="input-group">
                                    <input type="text" name="duedateedit" value="<?=$duedate;?> " class="form-control" placeholder="dd/mm/yyyy" id="datepicker-autoclose">
                                    <span class="input-group-addon bg-custom b-0"><i class="mdi mdi-calendar text-white"></i></span>
                                 </div>
                                 <!-- input-group -->
                              </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <div class="form-group">
                              <label>Due Time</label>
                              <div>
                                 <div class="input-group">
                                    <input id="timepicker3" name="editduetime" value="<?=$duetime;?>" type="text" class="form-control">
                                    <span class="input-group-addon"><i class="mdi mdi-clock"></i></span>
                                 </div>
                                 <!-- input-group -->
                              </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <div class="form-group">
                              <label>To Do Status</label>
                              <select class="selectpicker" name="dostatus" data-style="btn-secondary btn-rounded" id="dostatus">
                                 <option value="<?=$todostaus;?>">
                                  <?php if ($todostaus == 0) { echo 'Due'; }
                                           else   { echo 'Completed'; } ?> </option>
                                 <option value="0">Due</option>
                                 <option value="1">Completed </option>
                                 <option value="2">Canceled</option>
                              </select>
                           </div>
                        </div>
                     </div>
                     <div class="form-group account-btn text-center m-t-10">
                        <div class="col-xs-12">
                           <button class="btn w-lg btn-rounded btn-lg btn-primary waves-effect waves-light" name="edittodo" type="submit">Update</button>
                        </div>
                     </div>
                  </form>
               </div>
               <!--Card-box-->
            </div>
            <!--col-lg-12-->
         </div>
         <!-- Main Content Row Close -->
      </div>
      <!-- container -->
   </div>
   <!-- content -->
</div>
<!--content Page-->
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php'; ?>
<script>
   $(document).ready(function(){
     var date_input=$('input[name="duedateedit"]'); //our date input has the name "date"
     var container=$('#todolist form').length>0 ? $('#todolist form').parent() : "body";
     var options={
       format: 'dd/mm/yyyy',
       container: container,
       todayHighlight: true,
       autoclose: true,
     };
     date_input.datepicker(options);
   });
</script>
<!-- plugin js -->
<script src="plugins/moment/moment.js"></script>
<script src="plugins/timepicker/bootstrap-timepicker.js"></script>
<script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="plugins/clockpicker/js/bootstrap-clockpicker.min.js"></script>
<script src="plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="plugins/bootstrap-maxlength/bootstrap-maxlength.min.js" type="text/javascript"></script>
<script src="plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js" type="text/javascript"></script>
<script src="plugins/select2/js/select2.min.js" type="text/javascript"></script>
<script src="plugins/bootstrap-select/js/bootstrap-select.js" type="text/javascript"></script>
<script src="plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js" type="text/javascript"></script>

<!-- Init js -->
<script src="assets/pages/jquery.form-pickers.init.js"></script>
<script type="text/javascript" src="assets/pages/jquery.form-advanced.init.js"></script>