<?php
   session_start();
   include("../dbconfig.php");
   extract($_REQUEST);
   $email= $_SESSION["email"];
   $name = $_SESSION["username"];
   $aid = $_SESSION["aid"];
   //echo '<pre>' . print_r($_SESSION, TRUE) . '</pre>';
   //$role = $_SESSION["role"];
   $timeout = 100; // Set timeout minutes
   //$logout_redirect_url = "../index.php"; // Set logout URL
   $timeout = $timeout * 60; // Converts minutes to seconds
   if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
    if ($elapsed_time >= $timeout) {
        session_destroy();
      echo "<script>window.location.assign('../index.php')</script>";
    }
    else
   {
     $_SESSION['start_time'] = time();
    }
   }
   
   if(!isset($_SESSION['email']))
   {
   header("location:../index.php");
   }
   ?>
   

<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Building Budget Controlling App</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
      <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
      <meta content="Coderthemes" name="author" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <!-- App favicon 
         <link rel="shortcut icon" href="assets/images/favicon.ico">-->
      
      <!-- App css -->
      <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
      <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
      <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css" />
      <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
      <script src="assets/js/modernizr.min.js"></script>
   </head>
   <body>
      <!-- Begin page -->
      <div id="wrapper">
      <!-- Top Bar Start -->
      <div class="topbar">
   
         
         <!-- LOGO -->
         <div class="topbar-left">
            <a href="index.php" class="logo">
            <span>
            <img src="assets/images/logo.png" alt="" height="25">
            </span>
            <i>
            <img src="assets/images/logo_sm.png" alt="" height="28">
            </i>
            </a>
         </div>
         <nav class="navbar-custom">
            <ul class="list-inline float-right mb-0">
               <li class="list-inline-item dropdown notification-list">
                  <a href="add-Newproject.php" title="Add New Project">
                  <i class="dripicons-plus noti-icon2"></i>
                  </a>
               </li>
               <li class="list-inline-item dropdown notification-list">
                  <a class="nav-link dropdown-toggle arrow-none waves-light waves-effect" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false" title="Location">
                  <i class="dripicons-location noti-icon"></i> 
                  </a>
               </li>
               <li class="list-inline-item dropdown notification-list">
                  <a class="nav-link dropdown-toggle waves-effect waves-light nav-user" data-toggle="dropdown" href="#" role="button"
                     aria-haspopup="false" aria-expanded="false">
                      <?php $sql ="SELECT  * from customers where customer_id = $aid";
                      $result = $conn->query($sql);
                      if($row = $result->fetch_assoc())
                      { 
                           $pic = $row['customer_profile_pic']; ?>
                      <?php if(!empty($pic)) {  ?>
                      <img src="users/<?=$aid;?>/<?=$pic;?>" alt="user" class="rounded-circle">
                     <?php }  else { ?>
                        <img src="assets/images/users/avatar-1.jpg" alt="user" class="rounded-circle">
                    <?php }  } ?>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right profile-dropdown " aria-labelledby="Preview">
                     <!-- item-->
                     <div class="dropdown-item noti-title">
                        <h5 class="text-overflow"><small>Welcome !&nbsp;&nbsp;<?=$name;?></small> </h5>
                     </div>
                     <!-- item-->
                     <a href="profile.php" class="dropdown-item notify-item">
                     <i class="mdi mdi-account-circle"></i> <span>Profile</span>
                     </a>
                     <a href="cpass.php" class="dropdown-item notify-item" > 
                     <i class="mdi mdi-account-circle"></i> <span> Change Password </span>
                     </a>
                     <!-- item-->
                     <a href="logout.php" class="dropdown-item notify-item">
                     <i class="mdi mdi-power"></i> <span>Logout</span>
                     </a>
                  </div>
               </li>
            </ul>
            <ul class="list-inline menu-left mb-0">
               <li class="float-left">
                  <button class="button-menu-mobile open-left waves-light waves-effect">
                  <i class="dripicons-menu"></i>
                  </button>
               </li>
               <li class="hide-phone app-search">
                  <form role="search" class="">
                     <input type="text" placeholder="Search..." class="form-control">
                     <a href=""><i class="fa fa-search"></i></a>
                  </form>
               </li>
            </ul>
         </nav>
      </div>
      <!-- Top Bar End -->
      <style>
         .noti-icon2 {
         font-size: 30px !important;
         padding: 0 12px;
         vertical-align: middle;
         color: rgba(255, 255, 255, 0.8);
         }
      </style>

  