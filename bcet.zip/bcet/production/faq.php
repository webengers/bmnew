<?php include 'headerpage.php';
$projectid = $_SESSION["proid"];
$prname = $_SESSION["prname"];
if( $projectid == $proid)
{ include 'leftside.php'; } else { ?> <?php include 'leftmenu.php'; } ?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
<!-- Start content -->
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="page-title-box">
               <h4 class="page-title float-left">FAQ</h4>
               <ol class="breadcrumb float-right">
                  <li class="breadcrumb-item"><a href="#">Main Menu</a></li>
                  <li class="breadcrumb-item"><a href="#">Help/ Contact Us</a></li>
                  <li class="breadcrumb-item active">FAQ</li>
               </ol>
               <div class="clearfix"></div>
            </div>
         </div>
      </div>
      <!-- end row -->
      <div class="row">
         <div class="col-sm-12">
            <div class="card-box">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="text-center">
                        <h3 class="font-600">Frequently Asked Questions</h3>
                        <!-- <p class="text-muted"> Nisi praesentium similique totam odio obcaecati, reprehenderit,
                           dignissimos rem temporibus ea inventore alias!<br/> Beatae animi nemo ea
                           tempora, temporibus laborum facilis ut!
                        </p> -->
                        <!-- <button type="button" class="btn btn-primary waves-effect waves-light m-t-10">Email us your question</button> -->
                     </div>
                  </div>
                  <!-- end col 12 -->
                  <br><br>
                  <div id="accordion" role="tablist" aria-multiselectable="true" class="m-b-20">
                     <div class="card">
                        <div class="card-header" role="tab" id="headingOne">
                           <h5 class="mb-0 mt-0">
                              <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                              Collapsible Group Item #1
                              </a>
                           </h5>
                        </div>
                        <div id="collapseOne" class="collapse show" role="tabpanel" aria-labelledby="headingOne">
                           <div class="card-block">
                              Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                           </div>
                        </div>
                     </div>
                     <div class="card">
                        <div class="card-header" role="tab" id="headingTwo">
                           <h5 class="mb-0 mt-0">
                              <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                              Collapsible Group Item #2
                              </a>
                           </h5>
                        </div>
                        <div id="collapseTwo" class="collapse" role="tabpanel" aria-labelledby="headingTwo">
                           <div class="card-block">
                              Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                           </div>
                        </div>
                     </div>
                     <div class="card">
                        <div class="card-header" role="tab" id="headingThree">
                           <h5 class="mb-0 mt-0">
                              <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                              Collapsible Group Item #3
                              </a>
                           </h5>
                        </div>
                        <div id="collapseThree" class="collapse" role="tabpanel" aria-labelledby="headingThree">
                           <div class="card-block">
                              Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                           </div>
                        </div>
                     </div>
                  </div><!--acoridation-->
              <!-- end col -->
            </div>
            <!-- end row -->
         </div>
         <!-- container -->
      </div>
      <!-- content -->
   </div>
   <!-- ============================================================== -->
   <!-- End Right content here -->
   <!-- ============================================================== -->
</div>
<!-- END wrapper -->
<?php include 'footerpage.php';?>