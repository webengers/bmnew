$(function() {
	'use strict';

    // Signup form
    $('#signup').validate({
        rules: {
            pass: {
                required: true
            },
            email: {
                required: true,
                email: true
            }
        },
        messages: {
            pass: {
                required: "Please enter your password",
                minlength: "Your password must consist of at least 8 characters"
            },
            email: {
                required: "Please enter your email address"
            }
        },

     });
    	
	// Trial signup form
    $('#trial').validate({
        rules: {
            name: {
                required: true,
                minlength: 2
            },
            email: {
                required: true,
                email: true
            },
            phone: {
                required: true,
                minlength: 10
            },
            pin: {
                required: true,
                minlength: 6
            },
             pass: {
                required: true,
                minlength: 8
            }
        },
        messages: {
            name: {
                required: "Please enter your name",
                minlength: "Your name must consist of at least 2 characters"
            },
            email: {
                required: "Please enter your email address"
            },
            phone: {
                required: "Please enter your email address"
            },
            pin: {
                required: "Please enter your pin code"
            },
            pass: {
                required: "Please enter your Password"
            }
        },
    });

});